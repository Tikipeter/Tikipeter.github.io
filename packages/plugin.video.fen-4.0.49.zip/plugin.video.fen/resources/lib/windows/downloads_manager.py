# -*- coding: utf-8 -*-
import json
from windows.base_window import BaseDialog
from modules.kodi_utils import confirm_dialog, ok_dialog, list_dialog
# from modules.kodi_utils import logger

class DownloadsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2500
		self.closed = False
		self.position = 0
		self.active_downloads = None
		self.queued_downloads = None

	def onInit(self):
		self.update_downloads()
		self.setFocusId(self.window_id)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			return self.close()
		else:
			if action in self.context_actions or action in self.selection_actions: return self.set_status(self.get_listitem(self.window_id))

	def set_running_properties(self):
		active = json.loads(self.get_home_property('active_downloads') or '[]')
		queued = json.loads(self.get_home_property('queued_downloads') or '[]')
		try:
			if len(queued) != len(self.queued_downloads): self.reset_window(self.window_id)
			elif len(active) != len(self.active_downloads): self.reset_window(self.window_id)
		except: pass
		self.all_tracked_downloads = active + queued
		self.setProperty('active', str(len(active)))
		self.setProperty('queued', str(len(queued)))
		self.setProperty('speed_limit', self.get_home_property('speed_limit') or '0')
		total_bps = 0.0
		for item_id in active:
			status = self.get_home_property('%s.download_status' % item_id)
			if status == 'paused': continue
			try: total_bps += float(self.get_home_property('%s.speed' % item_id) or 0.0)
			except: pass
		self.setProperty('overall_speed', self.format_speed(total_bps))
		self.active_downloads = active
		self.queued_downloads = queued

	def sync_item_properties(self, listitem, item_id):
		if item_id in self.active_downloads:
			status = self.get_home_property('%s.download_status' % item_id)
			listitem.setProperty('percent', self.get_home_property('%s.percent' % item_id))
			listitem.setProperty('progress', self.get_home_property('%s.progress' % item_id))
			listitem.setProperty('eta', self.get_home_property('%s.eta' % item_id))
			listitem.setProperty('status', status)
			if status == 'paused': formatted_speed = self.format_speed(0.0)
			else:
				try: formatted_speed = self.format_speed(float(self.get_home_property('%s.speed' % item_id) or '0.0'))
				except: formatted_speed = self.format_speed(0.0)
			listitem.setProperty('speed', formatted_speed)
		else:
			listitem.setProperty('percent', '0')
			listitem.setProperty('status', 'queued')

	def update_downloads(self):
		try:
			self.set_running_properties()
			control = self.get_control(self.window_id)
			container_size = control.size()
			visible_item_ids = set()
			for index in range(container_size):
				item_id = self.get_listitem_by_index(index, control).getProperty('item_id')
				if item_id: visible_item_ids.add(item_id)
			for index in range(container_size - 1, -1, -1):
				listitem = self.get_listitem_by_index(index, control)
				item_id = listitem.getProperty('item_id')
				percent = self.get_home_property('%s.percent' % item_id)
				self.sync_item_properties(listitem, item_id)
			for item_id in self.all_tracked_downloads:
				if item_id not in visible_item_ids:
					listitem = self.make_listitem()
					listitem.setProperty('item_id', item_id)
					listitem.setProperty('name', item_id.replace('.', ' ').replace('_', ' '))
					self.sync_item_properties(listitem, item_id)
					control.addItem(listitem)
		except: pass

	def monitor(self):
		while not self.closed:
			self.update_downloads()
			if not self.active_downloads and not self.queued_downloads: break
			self.sleep(1000)
		try: self.setProperty('overall_speed', self.format_speed(0.0))
		except: pass

	def set_status(self, list_item):
		all_items = []
		item_id = list_item.getProperty('item_id')
		status = self.get_home_property('%s.download_status' % item_id)
		if status == 'queued': all_items.append({'line1': 'Full Filename', 'value': 'filename'})
		elif status == 'paused': all_items.append({'line1': 'Resume Download', 'value': 'unpaused'})
		else: all_items.append({'line1': 'Pause Download', 'value': 'paused'})
		all_items.append({'line1': 'Cancel Download', 'value': 'cancelled'})
		all_items.append({'line1': 'Fulll Filename', 'value': 'filename'})
		all_items.append({'line1': 'Settings', 'value': 'settings'})
		kwargs = {'heading': 'Download Settings', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = list_dialog(**kwargs)
		if choice == None: return
		status_choice = choice['value']
		if status_choice == 'filename': return ok_dialog(text=list_item.getProperty('name'))
		if status_choice == 'cancelled' and not confirm_dialog(): return
		if status_choice in ('paused', 'unpaused', 'cancelled'): return self.set_home_property('%s.download_status' % item_id, status_choice)
		if status_choice == 'settings':
			all_items = [{'line1': 'Set Max Download Speed', 'line2': 'Currently: [B]%s[/B]' % '%sMbps' % self.get_setting('fen.download.max_speed'), 'value': 'max_speed'},
						{'line1': 'Set Max Active Downloads', 'line2': 'Currently: [B]%s[/B]' % '%s Concurrent' % self.get_setting('fen.download.max_active'), 'value': 'max_active'}]
			kwargs = {'heading': 'Download Settings', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
			choice = list_dialog(**kwargs)
			if choice == None: return
			status_choice = choice['value']
			from caches.settings_cache import set_numeric
			set_numeric({'setting_id': 'download.%s' % status_choice})

	def format_speed(self, bps):
		bits_per_second = bps * 8
		mbps = bits_per_second / 1_000_000
		return '%.2f Mbps' % mbps
