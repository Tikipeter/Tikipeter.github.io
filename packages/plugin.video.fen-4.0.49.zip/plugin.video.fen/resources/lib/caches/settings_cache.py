# -*- coding: utf-8 -*-
import os, json
from modules import kodi_utils, meta_lists
from caches.base_cache import open_db
# logger = kodi_utils.logger

class SettingsCache:
	def get(self, setting_id):
		try:
			setting_id = setting_id.replace('fen.', '')
			with open_db('settings_db') as dbcon: setting_value = dbcon.execute('SELECT setting_value from settings WHERE setting_id = ?', (setting_id,)).fetchone()[0]
			self.set_memory_cache(setting_id, setting_value)
		except: setting_value = None
		return setting_value

	def remove_setting(self, setting_id):
		with open_db('settings_db') as dbcon: dbcon.execute('DELETE FROM settings WHERE setting_id = ?', (setting_id,))

	def get_many(self, settings_list):
		try:
			with open_db('settings_db') as dbcon: results = dict(dbcon.execute('SELECT setting_id, setting_value FROM settings WHERE setting_id in (%s)' \
													% (', '.join('?' for _ in settings_list)), settings_list).fetchall())
			return results
		except: results = {}
		return results

	def get_all(self, return_dict=True):
		try:
			with open_db('settings_db') as dbcon: all_settings = dbcon.execute('SELECT setting_id, setting_value FROM settings').fetchall()
			if return_dict: all_settings = dict(all_settings)
		except: all_settings = {} if return_dict else []
		return all_settings

	def set(self, setting_id, setting_value=None):
		setting_info = default_setting_values(setting_id)
		setting_type, setting_default = setting_info['setting_type'], setting_info['setting_default']
		if setting_value is None: setting_value = setting_default
		with open_db('settings_db') as dbcon:
			dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (setting_id, setting_type, setting_default, setting_value))
			if setting_type == 'action' and 'settings_options' in setting_info:
				name_setting_id = '%s_name' % setting_id
				name_setting_value = setting_info['settings_options'][setting_value]
				dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (name_setting_id, 'name', '', name_setting_value))
		self.set_memory_cache(setting_id, setting_value)
		if setting_type == 'action' and 'settings_options' in setting_info: self.set_memory_cache(name_setting_id, name_setting_value)

	def set_many(self, settings_list):
		with open_db('settings_db') as dbcon: dbcon.executemany('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', settings_list)
		for item in settings_list: self.set_memory_cache(item[0], item[3] or item[2])

	def set_many_memory_cache(self, settings_list):
		for item in settings_list: self.set_memory_cache(item[0], item[1])

	def set_memory_cache(self, setting_id, setting_value):
		kodi_utils.set_property('fen.%s' % setting_id, setting_value)

	def delete_memory_cache(self, setting_id):
		clear_property('fen.%s' % setting_id)

	def setting_info(self, setting_id):
		return [i for i in default_settings() if i['setting_id'] == setting_id][0]

	def clean_database(self):
		try:
			with open_db('settings_db') as dbcon: dbcon.execute('VACUUM')
			return True
		except: return False

settings_cache = SettingsCache()

def get_setting(setting_id, fallback=''):
	return kodi_utils.get_property(setting_id) or settings_cache.get(setting_id) or fallback

def set_setting(setting_id, value):
	settings_cache.set(setting_id, value)

def set_many_settings(settings_list):
	process_list = []
	for item in settings_list:
		setting_id, setting_value = item
		defaults = default_setting_values(setting_id)
		setting_type, setting_default = defaults['setting_type'], defaults['setting_default']
		process_list.append((setting_id, setting_type, setting_default, setting_value))
	settings_cache.set_many(process_list)

def get_many(settings_list):
	return settings_cache.get_many(settings_list)

def sync_settings(params={}):
	silent = params.get('silent', 'true') == 'true'
	memory_list = []
	memory_list_append = memory_list.append
	cache_list = []
	cache_list_append = cache_list.append
	currentsettings = settings_cache.get_all()
	d_settings = default_settings()
	defaultsettings_ids = [i['setting_id'] for i in d_settings]
	defaultsettings_names = [i['setting_id'] for i in d_settings if 'settings_options' in i]
	defaultsettings_ids.extend(['%s_name' % i for i in defaultsettings_names])
	c_settings = currentsettings.items()
	try:
		obsoletesettings_ids = [k for k, v in c_settings if not k in defaultsettings_ids]
		if obsoletesettings_ids:
			for item in obsoletesettings_ids: settings_cache.remove_setting(item)
			settings_cache.clean_database()
	except: pass
	if currentsettings:
		for k, v  in c_settings: settings_cache.set_memory_cache(k, v)
	for item in d_settings:
		setting_id = item['setting_id']
		if setting_id in currentsettings: continue
		setting_type = item['setting_type']
		setting_default = item['setting_default']
		setting_value = setting_default
		if setting_type == 'action' and 'settings_options' in item:
			name_default = item['settings_options'][setting_default]
			memory_list_append(('%s_name' % setting_id, name_default))
		cache_list_append((setting_id, setting_type, setting_default, setting_value))
	if cache_list: settings_cache.set_many(cache_list)
	if memory_list: settings_cache.set_many_memory_cache(memory_list)
	if not silent: kodi_utils.notification('Settings Cache Remade')

def set_default(setting_ids):
	if not isinstance(setting_ids, list): setting_ids = [setting_ids]
	if not kodi_utils.confirm_dialog(text='This will restore the default setting.[CR][CR]Are You Sure?', ok_label='Yes', cancel_label='No', default_control=11): return
	for setting_id in setting_ids:
		try: set_setting(setting_id, default_setting_values(setting_id)['setting_default'])
		except: pass

def set_boolean(params):
	boolean_dict = {'true': 'false', 'false': 'true'}
	setting = params['setting_id']
	set_setting(setting, boolean_dict[get_setting('fen.%s' % setting)])

def set_string(params):
	current_value = get_setting('fen.%s' % params['setting_id'])
	current_value = current_value.replace('empty_setting', '')
	new_value = kodi_utils.kodi_dialog().input('', defaultt=current_value)
	if not new_value and not kodi_utils.confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11): return set_string(params)
	set_setting(params['setting_id'], new_value or 'empty_setting')

def set_numeric(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	values_get = setting_values.get
	min_value, max_value = int(values_get('min_value', '0')), int(values_get('max_value', '100000000000000'))
	negative_included = any((n < 0 for n in [min_value, max_value]))
	multiplier = None
	if negative_included:
		all_items = [{'name': 'Positive(+)', 'value': 1}, {'name': 'Negative(-)', 'value': -1}]
		kwargs = {'heading': 'Will this be a positive or negative number?', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice: multiplier = choice['value']
	new_value = kodi_utils.kodi_dialog().input('Range [B]%s - %s[/B].' % (min_value, max_value), type=1)
	if not new_value: return
	if multiplier: new_value = str(int(float(new_value) * multiplier))
	if int(new_value) < min_value or int(new_value) > max_value:
		kodi_utils.ok_dialog(text='Please Choose Between the Range [B]%s - %s[/B].' % (min_value, max_value))
		return set_numeric(params)
	set_setting(setting_id, new_value)

def set_from_list(params):
	setting_id = params['setting_id']
	settings_options = default_setting_values(setting_id)['settings_options']
	all_items = [{'line1': v, 'value': k} for k, v in settings_options.items()]
	kwargs = {'heading': 'Settings', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	set_setting(setting_id, choice['value'])

def set_path(params):
	setting_id = params['setting_id']
	browse_mode = int(default_setting_values(setting_id)['browse_mode'])
	new_value = kodi_utils.kodi_dialog().browse(browse_mode, '', '', defaultt=get_setting('fen.%s' % setting_id))
	set_setting(setting_id, new_value)

def set_folder_path(params):
	setting_id = params['setting_id']
	current_setting = get_setting('fen.%s' % setting_id)
	if current_setting not in (None, 'None', ''):
		if kodi_utils.confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11):
			return set_setting(setting_id, 'None')
	return set_path(params)

def restore_setting_default(params):
	silent = params.get('silent', 'false') == 'true'
	if not silent and not kodi_utils.confirm_dialog(): return
	try:
		setting_id = params['setting_id']
		setting_default = default_setting_values(setting_id)['setting_default']
		set_setting(setting_id, setting_default)
	except:
		if not silent: kodi_utils.ok_dialog(text='Error restoring default setting')

def default_extras_list(params):
	from windows.base_window import ExtrasUtils
	set_default(['extras.order', 'extras.enabled', 'extras.enabled_name'])
	ExtrasUtils().run()

def default_context_menu(params):
	set_default(['context_menu.order', 'context_menu.enabled', 'context_menu.enabled_name'])

def set_default_folder(params):
	setting_id = params['setting_id']
	set_default(['%s.display_name' % setting_id, '%s.movies_directory' % setting_id, '%s.tv_shows_directory' % setting_id])

def default_setting_values(setting_id):
	if 'fen.' in setting_id: setting_id = setting_id.replace('fen.', '')
	return next((i for i in default_settings() if i['setting_id'] == setting_id), None)

def default_settings(include_hidden=True):
	if include_hidden: return visible_settings() + hidden_settings()
	return visible_settings()

def visible_settings():
	return [
#===============================================================================#
#====================================GENERAL====================================#
#===============================================================================#
#==================== General
{'setting_id': 'default_addon_fanart', 'setting_type': 'path', 'setting_default': kodi_utils.addon_fanart(), 'browse_mode': '2'},
{'setting_id': 'limit_concurrent_threads', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'max_threads', 'setting_type': 'action', 'setting_default': '20', 'min_value': '10', 'max_value': '20'},
#==================== Manage Updates
{'setting_id': 'update.action', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Prompt', '1': 'Automatic', '2': 'Notification', '3': 'Off'}},
{'setting_id': 'update.delay', 'setting_type': 'action', 'setting_default': '10', 'min_value': '10', 'max_value': '300'},
{'setting_id': 'update.username', 'setting_type': 'string', 'setting_default': 'Tikipeter'},
#==================== Window Theme
{'setting_id': 'window_theme', 'setting_type': 'string', 'setting_default': 'CC1F2020'},
{'setting_id': 'window_theme_opacity', 'setting_type': 'string', 'setting_default': 'CC'},
#==================== UTC Time Offset
{'setting_id': 'datetime.offset', 'setting_type': 'action', 'setting_default': '0', 'min_value': '-15', 'max_value': '15'},


#================================================================================#
#====================================FEATURES====================================#
#================================================================================#
#==================== Extras
{'setting_id': 'extras.enabled', 'setting_type': 'string', 'setting_default': meta_lists.extras_defaults()},
{'setting_id': 'extras.order', 'setting_type': 'string', 'setting_default': meta_lists.extras_defaults()},
{'setting_id': 'extras_buttons_movie.enabled', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_defaults('movie')},
{'setting_id': 'extras_buttons_movie.order', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_defaults('movie')},
{'setting_id': 'extras_buttons_tvshow.enabled', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_defaults('tvshow')},
{'setting_id': 'extras_buttons_tvshow.order', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_defaults('tvshow')},
{'setting_id': 'extras.enable_extra_ratings', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'extras.image_provider_default', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'none': 'None', 'tmdb': 'TMDb', 'imdb': 'IMDb'}},
{'setting_id': 'people.image_provider_default', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'none': 'None', 'tmdb': 'TMDb', 'imdb': 'IMDb',
'easynews': 'Easynews'}},
{'setting_id': 'extras.enable_item_ratings', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Special Open Actions
{'setting_id': 'media_open_action_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras', '2': 'Open Movie Set', '3': 'Both'}},
{'setting_id': 'media_open_action_tvshow', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras'}},


#==================================================================================#
#====================================CONTENT=======================================#
#==================================================================================#
#==================== General
{'setting_id': 'paginate.lists', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Within Addon Only', '2': 'Widgets Only', '3': 'Both'}},
{'setting_id': 'paginate.limit_addon', 'setting_type': 'action', 'setting_default': '20'},
{'setting_id': 'paginate.limit_widgets', 'setting_type': 'action', 'setting_default': '20'},
{'setting_id': 'trailers.service_order', 'setting_type': 'string', 'setting_default': 'Youtube, IMDb'},
{'setting_id': 'use_viewtypes', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Context Menu
{'setting_id': 'context_menu.enabled', 'setting_type': 'string', 'setting_default': meta_lists.context_menu_defaults()},
{'setting_id': 'context_menu.order', 'setting_type': 'string', 'setting_default': meta_lists.context_menu_defaults()},
#==================== Contents Sort Order For Watched Progress
{'setting_id': 'sort.progress', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
{'setting_id': 'sort.watched', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
#==================== Single Episode Lists
{'setting_id': 'paginate.single_lists', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'paginate.limit_single_lists', 'setting_type': 'action', 'setting_default': '10'},
{'setting_id': 'single_ep_display', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TITLE: SxE - EPISODE', '1': 'SxE - EPISODE', '2': 'EPISODE'}},
{'setting_id': 'single_ep_display_widget', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'TITLE: SxE - EPISODE', '1': 'SxE - EPISODE', '2': 'EPISODE'}},
{'setting_id': 'nextep.include_favorites', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Widgets
{'setting_id': 'widget_refresh_timer', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'widget_refresh_notification', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'widget_hide_next_page', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== RPDb Ratings Posters
{'setting_id': 'rpdb_enabled', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Movies', '2': 'TV Shows', '3': 'Both'}},
{'setting_id': 'rpdb_format', 'setting_type': 'string', 'setting_default': ''},


#=====================================================================================#
#====================================META ACCOUNTS====================================#
#=====================================================================================#
#==================== Fen Online
{'setting_id': 'fen_online.user_active', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'fen_online.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '15', 'max_value': '600'},
{'setting_id': 'fen_online.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== TMDb API
{'setting_id': 'tmdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== OMDb
{'setting_id': 'omdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== RPDb
{'setting_id': 'rpdb_api', 'setting_type': 'string', 'setting_default': 't0-free-rpdb'},
#==================== Trakt
{'setting_id': 'trakt.client', 'setting_type': 'string', 'setting_default': 'KviOtXWfvA2c-N8mLHLsoiFJqdsDLpG9upnEBtSXQO0'},


#=====================================================================================#
#====================================STREAMING ACCOUNTS===============================#
#=====================================================================================#
#==================== External
{'setting_id': 'provider.external', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.name', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== Premiumize
{'setting_id': 'pm.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'pm.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.premiumize.me', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== Off Cloud
{'setting_id': 'oc.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'oc.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'oc.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.offcloud', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.oc_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'oc_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.oc_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'oc.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== TorBox
{'setting_id': 'tb.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tb.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'store_resolved_to_cloud.torbox', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tb_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tb.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== Easynews
{'setting_id': 'provider.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews_user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews_password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.filter_lang', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.lang_filters', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'check.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'en.priority', 'setting_type': 'action', 'setting_default': '7', 'min_value': '1', 'max_value': '10'},
#=========+========== Folders
{'setting_id': 'provider.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.folders_ignore_filters', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.priority', 'setting_type': 'action', 'setting_default': '6', 'min_value': '1', 'max_value': '10'},


#===============================================================================#
#====================================RESULTS====================================#
#===============================================================================#
#==================== General
{'setting_id': 'results.timeout', 'setting_type': 'action', 'setting_default': '20', 'min_value': '1'},
{'setting_id': 'results.sort_order', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'Quality, Provider, Size',
'1': 'Quality, Size, Provider', '2': 'Provider, Quality, Size', '3': 'Provider, Size, Quality', '4': 'Size, Quality, Provider', '5': 'Size, Provider, Quality'}},
{'setting_id': 'results.rescrape_status', 'setting_type': 'action', 'setting_default': '2', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'results.rescrape_enabled', 'setting_type': 'string', 'setting_default': meta_lists.rescrape_defaults()},
{'setting_id': 'results.rescrape_order', 'setting_type': 'string', 'setting_default': meta_lists.rescrape_defaults()},
#==================== Filtering
{'setting_id': 'results.filter_size', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.line_speed', 'setting_type': 'action', 'setting_default': '25', 'min_value': '1'},
{'setting_id': 'results.movie_size_max', 'setting_type': 'action', 'setting_default': '10000', 'min_value': '1'},
{'setting_id': 'results.episode_size_max', 'setting_type': 'action', 'setting_default': '3000', 'min_value': '1'},
{'setting_id': 'results.movie_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.episode_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.size_unknown', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'results.include.unknown.size', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'filters.sort_to_top', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Source Select', '2': 'Autoplay', '3': 'Both'}},
{'setting_id': 'filters.enabled', 'setting_type': 'string', 'setting_default': meta_lists.filters_defaults()},
{'setting_id': 'filters.order', 'setting_type': 'string', 'setting_default': meta_lists.filters_defaults()},
{'setting_id': 'filters.included', 'setting_type': 'string', 'setting_default': meta_lists.filters_defaults()},
#==================== Results Color Highlights
{'setting_id': 'highlight.type', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Provider', '1': 'Quality', '2': 'Single Color'}},
{'setting_id': 'provider.easynews_highlight', 'setting_type': 'string', 'setting_default': 'FF00B3B2'},
{'setting_id': 'provider.debrid_cloud_highlight', 'setting_type': 'string', 'setting_default': 'FF7A01CC'},
{'setting_id': 'provider.folders_highlight', 'setting_type': 'string', 'setting_default': 'FFB36B00'},
{'setting_id': 'provider.pm_highlight', 'setting_type': 'string', 'setting_default': 'FFFF3300'},
{'setting_id': 'provider.ad_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'provider.oc_highlight', 'setting_type': 'string', 'setting_default': 'FF008EB2'},
{'setting_id': 'provider.tb_highlight', 'setting_type': 'string', 'setting_default': 'FF01662A'},
{'setting_id': 'scraper_4k_highlight', 'setting_type': 'string', 'setting_default': 'FFFF00FE'},
{'setting_id': 'scraper_1080p_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'scraper_720p_highlight', 'setting_type': 'string', 'setting_default': 'FF3C9900'},
{'setting_id': 'scraper_SD_highlight', 'setting_type': 'string', 'setting_default': 'FF0166FF'},
{'setting_id': 'scraper_single_highlight', 'setting_type': 'string', 'setting_default': 'FF008EB2'},


#===============================================================================#
#===================================PLAYBACK====================================#
#===============================================================================#
#==================== Playback Movies
{'setting_id': 'auto_play_movie', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'auto_resume_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
{'setting_id': 'stinger_alert.show', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Playback Episodes
{'setting_id': 'auto_play_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_next_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'skip_episode_intros', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Skip Intro', '2': 'Skip Recap', '3': 'Skip Both'}},
{'setting_id': 'auto_resume_episode', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
#==================== Playback Utilities
{'setting_id': 'playback.limit_resolve', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_percent', 'setting_type': 'action', 'setting_default': '50', 'min_value': '1', 'max_value': '100'},


#===============================================================================#
#===================================DOWNLOADS===================================#
#===============================================================================#
#==================== Downloads
{'setting_id': 'download.max_speed', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '200'},
{'setting_id': 'download.max_active', 'setting_type': 'action', 'setting_default': '2', 'min_value': '0', 'max_value': '5'},
{'setting_id': 'movie_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.fen/Movies Downloads/', 'browse_mode': '0'},
{'setting_id': 'tvshow_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.fen/TV Show Downloads/', 'browse_mode': '0'},
{'setting_id': 'premium_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.fen/Premium Downloads/', 'browse_mode': '0'},
{'setting_id': 'image_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.fen/Image Downloads/', 'browse_mode': '0'}
]

def hidden_settings():
	return [
#=========================================================================================#
#======================================HIDDEN=============================================#
#=========================================================================================#
{'setting_id': 'extras.enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.extras_display_defaults()},
{'setting_id': 'context_menu.enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.context_menu_display_defaults()},
{'setting_id': 'results.rescrape_enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.rescrape_display_defaults()},
{'setting_id': 'filters.enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.filters_display_defaults()},
{'setting_id': 'filters.included_name', 'setting_type': 'string', 'setting_default': meta_lists.filters_display_defaults()},
{'setting_id': 'extras_buttons_movie.enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_display_defaults('movie')},
{'setting_id': 'extras_buttons_tvshow.enabled_name', 'setting_type': 'string', 'setting_default': meta_lists.extras_button_display_defaults('tvshow')},
{'setting_id': 'fen_online.url', 'setting_type': 'string', 'setting_default': 'https://fen-history-default-rtdb.firebaseio.com'},
{'setting_id': 'fen_online.user_code', 'setting_type': 'action', 'setting_default': 'empty_setting'},
{'setting_id': 'fen_online.user_pin', 'setting_type': 'action', 'setting_default': 'empty_setting'},
{'setting_id': 'fen_online.user_hex', 'setting_type': 'action', 'setting_default': 'empty_setting'},
{'setting_id': 'fen_online.crypto_key_hex', 'setting_type': 'action', 'setting_default': 'empty_setting'},
{'setting_id': 'widget_refresh_timer_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'rpdb_format_name', 'setting_type': 'string', 'setting_default': 'Default'},
{'setting_id': 'window_theme_contrast', 'setting_type': 'string', 'setting_default': 'FF4a4347'},
{'setting_id': 'window_theme_name', 'setting_type': 'string', 'setting_default': 'Dark'},
{'setting_id': 'window_theme_opacity_name', 'setting_type': 'string', 'setting_default': '80%'},
{'setting_id': 'external_scraper.module', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'folder1.display_name', 'setting_type': 'string', 'setting_default': 'Folder 1'},
{'setting_id': 'folder1.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder1.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.display_name', 'setting_type': 'string', 'setting_default': 'Folder 2'},
{'setting_id': 'folder2.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.display_name', 'setting_type': 'string', 'setting_default': 'Folder 3'},
{'setting_id': 'folder3.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.display_name', 'setting_type': 'string', 'setting_default': 'Folder 4'},
{'setting_id': 'folder4.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.display_name', 'setting_type': 'string', 'setting_default': 'Folder 5'},
{'setting_id': 'folder5.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'view.main', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.movies', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.tvshows', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.seasons', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes_single', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.premium', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'fen_online.sync_timestamp_watched_db', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'fen_online.sync_timestamp_personal_lists_db', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'fen_online.sync_timestamp_favorites_db', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'fen_online.sync_timestamp_settings_db', 'setting_type': 'string', 'setting_default': '0'}
	]
