# -*- coding: utf-8 -*-
import json
import random
import string
import requests
from caches.base_cache import get_timestamp
from caches.settings_cache import get_setting, set_setting
from modules.utils import chunks
from modules import kodi_utils
logger = kodi_utils.logger

fen_online_url = 'https://fen-history-default-rtdb.firebaseio.com/'
key_test = (None, 'empty_setting', '')

def build_key(media_type, media_id, season, episode):
	media_id = str(media_id).replace('.', '_').replace('/', '_')
	if media_type == 'movie': return '%s_%s' % (media_type, media_id)
	else: return '%s_%s_%s_%s' % (media_type, media_id, season, episode)

def create_profile():
	max_attempts = 3
	assign_own_key = kodi_utils.confirm_dialog(heading='Fen Online Sync',
									text='You need a 6-character User Key[CR]Do you want to assign it yourself or allow Fen to assign a random string?',
									ok_label='Assign', cancel_label='Random', default_control=11)
	if assign_own_key is None: return
	if assign_own_key:
		for attempts in range(1, max_attempts + 1):
			remaining = max_attempts - attempts
			user_code = kodi_utils.kodi_dialog().input('Enter your 6-character User Code')
			if user_code in (None, ''): return False
			user_code = user_code.upper()
			if len(user_code) != 6 or not user_code.isalnum():
				if remaining == 0: return
				if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
										'Use exactly 6 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
										ok_label='Retry', cancel_label='Cancel', default_control=10): return
			else: break
	else: user_code = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
	write_key = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(24))
	try:
		kodi_utils.show_busy_dialog()
		response = requests.get('%s/users/%s.json' % (fen_online_url, user_code), timeout=10)
		if response.status_code == 200:
			if response.json() is None:
				initial_request = requests.put('%s/users/%s.json' % (fen_online_url, user_code), json={'write_key': write_key, 'watched': {}, 'progress': {}}, timeout=10)
				if initial_request.status_code == 200:
					set_setting('fen_online.user_code', user_code)
					set_setting('fen_online.write_key', write_key)
					set_setting('fen_online.last_sync', str(get_timestamp()))
					set_setting('watched_indicators', '1')
					kodi_utils.hide_busy_dialog()
					kodi_utils.ok_dialog('Sync Key Generation', ('Success![CR]Your new User Code is [B]%s[/B]'
									'[CR]You need this key for access, so keep it safe[CR]This key cannot be recovered if lost' % user_code))
					if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Sync your current local data to this new account?', default_control=10): watched_full_push_sync()
			elif assign_own_key:
				kodi_utils.hide_busy_dialog()
				if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text='[B]%s[/B] key is already taken[CR][CR]Try a different key?' % user_code): return
		kodi_utils.hide_busy_dialog()
	except: kodi_utils.hide_busy_dialog()

def connect_device():
	user_code = kodi_utils.kodi_dialog().input('Enter your 6-character User Code')
	if user_code in (None, ''): return
	user_code = user_code.upper()
	if len(user_code) != 6 or not user_code.isalnum():
		if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Please enter your 6-character key', ok_label='Retry', cancel_label='Cancel', default_control=10): return
		return connect_device()
	try:
		kodi_utils.show_busy_dialog()
		response = requests.get('%s/users/%s.json' % (fen_online_url, user_code), timeout=10)
		if response.status_code == 200:
			data = response.json()
			if 'write_key' in data:
				set_setting('fen_online.user_code', user_code)
				set_setting('fen_online.write_key', data['write_key'])
				set_setting('fen_online.last_sync', str(get_timestamp()))
				set_setting('watched_indicators', '1')
				sync_success = watched_full_pull_sync()
				if sync_success: kodi_utils.ok_dialog('Fen Online Sync', 'Success![CR]This device is connected to User Code [B]%s[/B]' % user_code)
				else: kodi_utils.ok_dialog('Fen Online Sync', 'Invalid code or profile does not exist')
		kodi_utils.hide_busy_dialog()
		return True
	except Exception as e:
		kodi_utils.hide_busy_dialog()
		kodi_utils.ok_dialog('Fen Online Sync', 'Error Connecting Device:[CR][CR]%s' % str(e))
		kodi_utils.logger('error connect_device', str(e))
	return False

def revoke_account():
	if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Remove Authorization for this Device?', ok_label='Yes', cancel_label='No', default_control=10):
		set_setting('fen_online.user_code', 'empty_setting')
		set_setting('fen_online.write_key', 'empty_setting')
		set_setting('fen_online.last_sync', '0')
		set_setting('watched_indicators', '0')

def delete_account():
	user_code, write_key = get_setting('fen.fen_online.user_code'), get_setting('fen.fen_online.write_key')
	if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Delete this account: [B]%s[/B][CR]and all data?' % user_code, ok_label='Yes', cancel_label='No', default_control=11):
		if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='[COLOR red][B]CAUTION!![/B][/COLOR][CR][CR]Are you sure?[CR][CR]All online data will be forever deleted',
						ok_label='Yes', cancel_label='No', default_control=11):
			if user_code in key_test or write_key in key_test: return kodi_utils.ok_dialog('Fen Online Sync', 'There was an error removing account[CR][CR]Please contact dev directly')
			text = ''
			url = '%s/users/%s.json' % (fen_online_url, user_code)
			kodi_utils.show_busy_dialog()
			try:
				response = requests.delete(url, timeout=10)
				if response.status_code == 200:
					text = 'Successfully deleted account and all associated sync data'
					set_setting('fen_online.user_code', 'empty_setting')
					set_setting('fen_online.write_key', 'empty_setting')
					set_setting('fen_online.last_sync', '0')
					set_setting('watched_indicators', '0')
				else: text = 'Deletion failed: %s: %s' % (response.status_code, response.text)
			except Exception as e: text = 'Deletion failed: %s' % str(e)
			kodi_utils.hide_busy_dialog()
			if text: kodi_utils.ok_dialog('Fen Online Sync', text)

def watched_status_mark(media_type, media_id, action, title, last_played, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	item_key = build_key(media_type, media_id, season, episode)
	url = '%s/users/%s/watched/%s.json' % (fen_online_url, user_code, item_key)
	payload = {'media_type': media_type, 'media_id': media_id, 'last_updated': last_updated}
	if action == 'mark_as_watched': payload.update({'title': title, 'last_played': last_played})
	else: payload['deleted'] = True
	if media_type == 'episode': payload.update({'season': season, 'episode': episode})
	try:
		response = requests.put(url, json=payload, timeout=10)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error watched_status_mark', str(e))
	return False

def set_bookmark(media_type, media_id, resume_point, curr_time, last_played, title, last_updated, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	item_key = build_key(media_type, media_id, season, episode)
	url = '%s/users/%s/progress/%s.json' % (fen_online_url, user_code, item_key)
	payload = {'media_type': media_type, 'media_id': media_id, 'season': season, 'episode': episode, 'title': title, 'resume_point': resume_point,
				'curr_time': curr_time, 'last_played': last_played, 'last_updated': last_updated}
	try:
		response = requests.put(url, json=payload, timeout=10)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error set_bookmark', str(e))
	return False

def erase_bookmark(media_type, media_id, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	item_key = build_key(media_type, media_id, season, episode)
	url = '%s/users/%s/progress/%s.json' % (fen_online_url, user_code, item_key)
	payload = {'media_type': media_type, 'media_id': media_id, 'deleted': True, 'last_updated': last_updated}
	if media_type == 'episode': payload.update({'season': season, 'episode': episode})
	try:
		response = requests.put(url, json=payload, timeout=10)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error erase_bookmark', str(e))
	return False

def watched_sync_many(table_name, action, media_to_sync, chunk_limit=100):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	session = kodi_utils.make_session()
	url = '%s/users/%s/%s.json' % (fen_online_url, user_code, table_name)
	success = True
	try:
		for chunk in chunks(media_to_sync, chunk_limit):
			payload = {}
			for ep in chunk:
				media_type, media_id, season, episode = ep[0], ep[1], ep[2], ep[3]
				item_key = build_key(media_type, media_id, season, episode)
				payload[item_key] = {'media_type': media_type, 'media_id': media_id, 'season': season, 'episode': episode}
				if action in ('mark_as_watched', 'add'): payload[item_key].update({'last_played': ep[4], 'title': ep[5], 'last_updated': ep[6]})
				else: payload[item_key].update({'deleted': True, 'last_updated': last_updated})
			try:
				response = session.patch(url, json=payload, timeout=30)
				if response.status_code != 200: success = False
			except: success = False
	finally: session.close()
	return success

def watched_full_pull_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	url = '%s/users/%s.json' % (fen_online_url, user_code)
	try:
		response = requests.get(url, timeout=20)
		if response.status_code != 200: return None
		data = response.json()
	except: return None
	if not data: data = {}
	try:
		dbcon = watched_status.get_database()
		dbcon.execute('DELETE FROM progress')
		dbcon.execute('DELETE FROM watched')
		dbcon.execute('VACUUM')
	except: return kodi_utils.notification('Error resetting local sync storage')
	progress = data.get('progress', {})
	progress_deletes = []
	for _, item in progress.items():
		if not isinstance(item, dict): continue
		tmdb_id = item.get('media_id') or item.get('tmdb_id')
		if item.get('deleted') in (True, 'True', 'true'): progress_deletes.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', '')))
		else: watched_status.set_bookmark(item, no_sync=True)
	if progress_deletes: watched_status.batch_erase_bookmark(progress_deletes, action='clear', no_sync=True)
	watched = data.get('watched', {})
	watched_inserts, watched_deletes = [], []
	for _, item in watched.items():
		if not isinstance(item, dict): continue
		tmdb_id = item.get('media_id') or item.get('tmdb_id')
		if item.get('deleted') in (True, 'True', 'true'): watched_deletes.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', '')))
		else: watched_inserts.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', ''),
									item.get('last_played') or watched_status.get_last_played_value(), item.get('title', 'Unknown'),
									item.get('last_updated') or get_timestamp()))
	if watched_inserts: watched_status.batch_watched_status_mark(watched_inserts, action='mark_as_watched', no_sync=True)
	if watched_deletes: watched_status.batch_watched_status_mark(watched_deletes, action='mark_as_unwatched', no_sync=True)
	return True

def watched_full_push_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	dbcon = watched_status.get_database()
	progress_payload, watched_payload = {}, {}
	try:
		cursor = dbcon.execute('SELECT db_type, media_id, season, episode, resume_point, curr_time, last_played, title, last_updated FROM progress')
		for row in cursor.fetchall():
			_key = build_key(row[0], row[1], row[2], row[3])
			progress_payload[_key] = {'media_type': row[0], 'media_id': row[1], 'season': row[2] or '', 'episode': row[3] or '',
										'resume_point': float(row[4]) if row[4] else 0.0, 'curr_time': float(row[5]) if row[5] else 0.0,
										'last_played': row[6] or '', 'title': row[7] or 'Unknown', 'last_updated': int(row[8]) if row[8] else 0}
		cursor = dbcon.execute('SELECT db_type, media_id, season, episode, last_played, title, last_updated FROM watched')
		for row in cursor.fetchall():
			_key = build_key(row[0], row[1], row[2], row[3])
			watched_payload[_key] = {'media_type': row[0], 'media_id': row[1], 'season': row[2] or '', 'episode': row[3] or '',
									'last_played': row[4] or '', 'title': row[5] or 'Unknown', 'last_updated': int(row[6]) if row[6] else 0}
		if not any([watched_payload, progress_payload]): return
	except Exception as e: return kodi_utils.logger('error watched_full_push_sync extraction', str(e))
	try:
		url = '%s/users/%s.json' % (fen_online_url, user_code)
		response = requests.patch(url, json={'progress': progress_payload, 'watched': watched_payload}, timeout=20)
	except Exception as e: kodi_utils.logger('error watched_full_push_sync network', str(e))

def watched_regular_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return 'Skipping Sync No User Code'
	try: last_sync_time = int(get_setting('fen.fen_online.last_sync', '0'))
	except ValueError: last_sync_time = 0
	current_sync_time = get_timestamp()
	has_changes = False
	try:
		for table_name in ['progress', 'watched']:
			url = '%s/users/%s/%s.json' % (fen_online_url, user_code, table_name)
			try:
				url = '%s/users/%s/%s.json?orderBy="last_updated"&startAt=%s' % (fen_online_url, user_code, table_name, last_sync_time + 1)
				response = requests.get(url, timeout=30)
				if response.status_code != 200: continue
				data = response.json()
			except Exception as e:
				kodi_utils.logger('error watched_regular_sync network %s' % table_name, str(e))
				continue
			if not data: continue
			has_changes, inserts, deletes = True, [], []
			for _, item in data.items():
				if not isinstance(item, dict): continue
				media_type = item.get('media_type')
				tmdb_id = item.get('media_id') or item.get('tmdb_id')
				season = item.get('season', '')
				episode = item.get('episode', '')
				if item.get('deleted') in (True, 'True', 'true'): deletes.append((media_type, tmdb_id, season, episode))
				else:
					if table_name == 'progress': watched_status.set_bookmark(item, no_sync=True)
					else: inserts.append((media_type, tmdb_id, season, episode, item.get('last_played') or watched_status.get_last_played_value(),
											item.get('title', 'Unknown'),item.get('last_updated') or current_sync_time))
			if table_name == 'progress' and deletes: watched_status.batch_erase_bookmark(deletes, action='clear', no_sync=True)
			elif table_name == 'watched':
				if inserts: watched_status.batch_watched_status_mark(inserts, action='mark_as_watched', no_sync=True)
				if deletes: watched_status.batch_watched_status_mark(deletes, action='mark_as_unwatched', no_sync=True)
		set_setting('fen_online.last_sync', str(current_sync_time))
	except Exception as e: return 'Failed!! Error: %s' % str(e)
	return 'Success! Watched Data Synced' if has_changes else 'Success! No Watched Data Sync'

def access_user_key():
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return kodi_utils.ok_dialog('Fen Online Sync', 'No User Code is Available')
	import time
	expires_in = 20
	start, time_passed = time.time(), 0
	content = 'Current User Code:[CR][B]%s[/B]' % user_code
	progressDialog = kodi_utils.progress_dialog('Fen Online Sync', kodi_utils.get_icon('firebase'))
	progressDialog.update(content, 100)
	while not progressDialog.iscanceled() and time_passed < expires_in:
		time_passed = time.time() - start
		progress = int(100 * (expires_in - time_passed) / float(expires_in))
		progress = max(0, min(100, progress))
		progressDialog.update(content, progress)
		kodi_utils.sleep(1000)
	try: progressDialog.close()
	except: pass
	return

def watched_purge_old_entries(max_hours=168):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	cutoff_timestamp = get_timestamp(offset=-max_hours)
	success = True
	session = kodi_utils.make_session()
	for table_name in ['watched', 'progress']:
		url = '%s/users/%s/%s.json?orderBy="last_updated"&endAt=%s' % (fen_online_url, user_code, table_name, cutoff_timestamp)
		try:
			response = session.get(url, timeout=30)
			if response.status_code != 200:
				success = False
				continue
			data = response.json()
			if not isinstance(data, dict): continue
			payload = {key: None for key, val in data.items() if isinstance(val, dict) and val.get('deleted') is True}
			if not payload: continue
			patch_url = '%s/users/%s/%s.json' % (fen_online_url, user_code, table_name)
			response = session.patch(patch_url, json=payload, timeout=30)
			if response.status_code != 200: success = False
		except: success = False
	session.close()
	return success

def sync_personal_lists():
	import json
	import ast
	import sqlite3
	from caches.base_cache import connect_database
	dbcon = connect_database('personal_lists_db')
	dbcon.row_factory = sqlite3.Row
	all_lists = dbcon.execute('SELECT id, name, contents, total, created, sort_order, updated FROM personal_lists').fetchall()
	all_lists = [dict(row) for row in all_lists]
	logger('all_lists', all_lists)
	for item in all_lists:
		content = json.loads(item['contents'])
		logger('content', content)
	return
	# from indexers.personal_lists import get_all_personal_lists, get_personal_list
	# all_personal_lists = get_all_personal_lists()
	# logger('all_personal_lists', all_personal_lists)
	# for item in all_personal_lists:
	# 	details = get_personal_list({'list_id': item['list_id']})
	# 	logger('details', details)

