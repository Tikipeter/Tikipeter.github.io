# -*- coding: utf-8 -*-
import json
import uuid
from caches.base_cache import connect_database, get_timestamp
from modules.kodi_utils import logger

class PersonalListsCache:
	def make_list(self, list_name, sort_order):
		try:
			time_stamp = get_timestamp()
			uuid_id = str(uuid.uuid4())
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('INSERT OR REPLACE INTO personal_lists (id, name, contents, total, created, sort_order, updated) VALUES (?, ?, ?, ?, ?, ?, ?)',
						(uuid_id, list_name, json.dumps([]), 0, time_stamp, sort_order, time_stamp))
			return uuid_id
		except: return None

	def delete_list(self, list_id):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('DELETE FROM personal_lists WHERE id=?', (list_id,))
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_list_contents(self, list_id):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET contents=?, total=? WHERE id=?', (json.dumps([]), '0', list_id))
			return True
		except: return False

	def update_single_detail(self, set_prop, new_value, list_id):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET %s=? WHERE id=?' % set_prop, (new_value, list_id))
		except: pass

	def get_lists(self):
		try:
			dbcon = connect_database('personal_lists_db')
			all_lists = dbcon.execute('SELECT id, name, total, created, sort_order, updated FROM personal_lists').fetchall()
			return [{'list_id': str(i[0]), 'name': str(i[1]), 'total': i[2], 'created_at': i[3], 'sort_order': i[4], 'updated': i[5]} for i in all_lists]
		except: return []

	def get_list(self, list_id, dbcon=None):
		content = []
		try:
			if not dbcon: dbcon = connect_database('personal_lists_db')
			content = json.loads(dbcon.execute('SELECT contents FROM personal_lists WHERE id=?', (list_id,)).fetchone()[0])
		except: pass
		return content

	def add_remove_list_item(self, list_id, action, new_contents):
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_id, dbcon=dbcon)
			if action == 'add':
				if [str(i['media_id']) for i in contents if str(new_contents['media_id']) == str(i['media_id'])]: return 'Item Already in List'
				command = 'UPDATE personal_lists SET contents=?, total=total+1, updated=? WHERE id=?'
				contents.append(new_contents)
			else:
				if not [str(i['media_id']) for i in contents if str(new_contents) == str(i['media_id'])]: return 'Item Not in List'
				command = 'UPDATE personal_lists SET contents=?, total=total-1, updated=? WHERE id=?'
				contents = [i for i in contents if not str(i['media_id']) == str(new_contents)]
			dbcon.execute(command, (json.dumps(contents), get_timestamp(), list_id))
			return 'Success'
		except: return 'Error'

personal_lists_cache = PersonalListsCache()
