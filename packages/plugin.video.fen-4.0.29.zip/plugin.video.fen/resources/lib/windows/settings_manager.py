# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
# from modules.kodi_utils import logger

class SettingsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.menu_focus, self.submenu_focus = kwargs.get('menu_focus', 0), kwargs.get('submenu_focus', None)

	def onInit(self):
		self.set_delayed_position_focus(2000, int(self.menu_focus), render_delay=25)
		if self.submenu_focus: self.set_delayed_position_focus(2100, int(self.submenu_focus), render_delay=25)

	def run(self):
		self.doModal()
		self.clearProperties()

class SettingsManagerFolders(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
