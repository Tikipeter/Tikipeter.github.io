# -*- coding: utf-8 -*-
import functools
import threading
from apis import fen_online_api
from caches.base_cache import database_locations
from modules.settings import fen_online_user_active
from modules.kodi_utils import last_modified_time_for_file
from modules.kodi_utils import logger

def single_sync(db_name, table_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			db_location = database_locations(db_name)
			start_timestamp = last_modified_time_for_file(db_location)
			result = func(*args, **kwargs)
			end_timestamp = last_modified_time_for_file(db_location)
			if not fen_online_user_active(): return result
			if start_timestamp != end_timestamp:
				try: threading.Thread(target=fen_online_api.push_single, args=(db_name, table_name), kwargs={'timestamp': end_timestamp}).start()
				except Exception as e: logger('error decorator', str(e))
			return result
		return wrapper
	return decorator