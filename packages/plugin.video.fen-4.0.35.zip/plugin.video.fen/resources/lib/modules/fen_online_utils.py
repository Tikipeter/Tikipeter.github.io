# -*- coding: utf-8 -*-
import functools
from apis import fen_online_api
from modules.settings import fen_online_user_active
# from modules.kodi_utils import logger

def personal_lists_sync(method_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			sync_data = func(*args, **kwargs)
			if not fen_online_user_active(): return sync_data
			if sync_data and not isinstance(sync_data, (str, bool)):
				_method = getattr(fen_online_api, method_name)
				if isinstance(sync_data, dict): _method(**sync_data)
				elif isinstance(sync_data, (tuple, list)): _method(*sync_data)
			return sync_data
		return wrapper
	return decorator

def watched_sync_single_item(method_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			no_sync = kwargs.get('no_sync')
			sync_data = func(*args, **kwargs)
			if not fen_online_user_active(): return sync_data
			if no_sync: return sync_data
			if sync_data:
				_method = getattr(fen_online_api, method_name)
				if isinstance(sync_data, dict): _method(**sync_data)
				elif isinstance(sync_data, (tuple, list)): _method(*sync_data)
			return sync_data
		return wrapper
	return decorator

def watched_sync_batch_items(table_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			no_sync = kwargs.get('no_sync')
			action = kwargs.get('action') or (args[1] if len(args) > 1 else None)
			action = 'remove' if action in ('mark_as_unwatched', 'remove') else action
			sync_data = func(*args, **kwargs)
			if not fen_online_user_active(): return sync_data
			if no_sync: return sync_data
			if sync_data: fen_online_api.watched_sync_many(table_name, action, sync_data)
			return sync_data
		return wrapper
	return decorator
