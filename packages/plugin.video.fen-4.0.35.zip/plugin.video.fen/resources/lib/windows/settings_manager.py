# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from modules.kodi_utils import logger

import xbmc
class SettingsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.menu_focus, self.submenu_focus = kwargs.get('menu_focus', 0), kwargs.get('submenu_focus', None)

	def onInit(self):
		self.set_delayed_position_focus(2000, int(self.menu_focus), render_delay=25)
		if self.submenu_focus: self.set_delayed_position_focus(2100, int(self.submenu_focus), render_delay=25)

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		if action in self.context_actions:
			setting_id = xbmc.getInfoLabel('ListItem.Property(setting_id)')
			if not setting_id: return
			from caches.settings_cache import set_default
			set_default(setting_id)

class SettingsManagerFolders(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
