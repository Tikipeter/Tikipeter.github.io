# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl
from modules.router import routing
# from modules.kodi_utils import logger

params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
routing(params)
if params.get('is_widget') == 'true': sys.exit(1)
