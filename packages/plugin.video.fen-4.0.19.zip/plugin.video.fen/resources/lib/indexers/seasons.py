# -*- coding: utf-8 -*-
import sys
from modules import kodi_utils, settings
from modules.metadata import tvshow_meta
from modules.utils import get_datetime, adjust_premiered_date, TaskPool
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season
# logger = kodi_utils.logger

def build_season_list(params):
	def _process():
		total_aired_eps, episode_count = meta_get('total_aired_eps'), 0
		for item in season_data:
			try:
				cm = []
				cm_append = cm.append
				cm_extend = cm.extend
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_special = season_number == 0
				title = item_get('name', None) or 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or '2050'
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				plot = overview or show_plot
				unaired = aired_eps == 0
				if unaired or season_special:
					progress, playcount, total_watched, total_unwatched = 0, 0, 0, aired_eps
					if unaired: title = '[COLOR red][I]%s[/I][/COLOR]' % title
					else: title = 'Specials'
				else:
					if season_number < total_seasons:
						episode_count += aired_eps
					else: aired_eps = total_aired_eps - episode_count
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = 0 if progress == 100 else progress
				url = build_main_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number})
				cm_extend([
				('[B]Extras[/B]', 'RunPlugin(%s)' % build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow'})),
				('[B]More Info[/B]', 'RunPlugin(%s)' % build_url({'mode': 'media_info_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id})),
				('[B]Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster})),
				('[B]Browse More[/B]', 'RunPlugin(%s)' % build_url({'mode': 'browse_more_choice', 'media_type': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster}))])
				if not unaired and not season_special and not progress == 100:
						cm_append(('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_watched',
															'title': show_title, 'tmdb_id': tmdb_id, 'season': season_number})))
				if progress:
					cm_append(('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_unwatched',
														'title': show_title, 'tmdb_id': tmdb_id, 'season': season_number})))
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress)})
				if is_external:
					cm_extend([('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'})),
							('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))])
				info_tag = listitem.getVideoInfoTag()
				info_tag.setMediaType('season')
				info_tag.setTitle(title)
				info_tag.setOriginalTitle(orig_title)
				info_tag.setTvShowTitle(show_title)
				info_tag.setIMDBNumber(imdb_id)
				info_tag.setSeason(season_number)
				info_tag.setPlot(plot)
				info_tag.setDuration(episode_run_time)
				info_tag.setPlaycount(playcount)
				info_tag.setGenres(genre)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id})
				info_tag.setTvShowStatus(status)
				info_tag.setFirstAired(premiered)
				info_tag.setStudios(studio)
				info_tag.setYear(int(year))
				info_tag.setRating(rating)
				info_tag.setVotes(votes)
				info_tag.setMpaa(mpaa)
				info_tag.setCountries(country)
				info_tag.setTrailer(trailer)
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				listitem.setLabel(title)
				listitem.setArt({'poster': poster, 'season.poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo, 'landscape': show_landscape, 'thumb': thumb,
								'icon': show_landscape, 'tvshow.poster': poster, 'tvshow.clearlogo': show_clearlogo})
				listitem.addContextMenuItems(cm)
				yield (url, listitem, True)
			except: pass
	kodi_actor, make_listitem = kodi_utils.kodi_actor(), kodi_utils.make_listitem
	build_url, build_main_url = kodi_utils.build_url, kodi_utils.build_main_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	adjust_hours = settings.date_offset()
	current_date = get_datetime()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), current_date)
	meta_get = meta.get
	tmdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, rating, genre = str(tmdb_id), meta_get('rating'), meta_get('genre')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	mpaa, votes, trailer, studio, country = meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons')
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
	custom_order = params.get('custom_order', None)
	if custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database())
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	kodi_utils.add_items(handle, list_items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, show_title)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.seasons', 'seasons', is_external)

def single_seasons(seasons_list):
	season_results = []
	threads = TaskPool().tasks(lambda x: season_results.append(build_season_list(x)), seasons_list, min(len(seasons_list), settings.max_threads()))
	[i.join() for i in threads]
	return [i for i in season_results if i]
