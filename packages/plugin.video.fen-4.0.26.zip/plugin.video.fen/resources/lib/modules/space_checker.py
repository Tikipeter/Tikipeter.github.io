# -*- coding: utf-8 -*-
# import os
# import sys
# import shutil
# import ctypes
# from modules.kodi_utils import make_legal_filename, translate_path
# # from modules.kodi_utils import logger

# # Help needed from AI to get correct calls per OS

# def get_available_space(target_path):
# 	target_path = make_legal_filename(target_path)
# 	translated_path = translate_path(target_path)
# 	if any(target_path.lower().startswith(proto) for proto in ['smb://', 'nfs://', 'dav://', 'ftp://']): return _check_network_space_fallback(translated_path)
# 	try: return shutil.disk_usage(translated_path).free
# 	except: return _posix_vs_windows_space_fallback(translated_path)

# def _check_network_space_fallback(translated_path):
# 	try:
# 		if not any(translated_path.lower().startswith(p) for p in ['smb://', 'nfs://']): return shutil.disk_usage(translated_path).free
# 	except: pass
# 	return None

# def _posix_vs_windows_space_fallback(path):
# 	if sys.platform == 'win32' or os.name == 'nt':
# 		try:
# 			free_bytes = ctypes.c_ulonglong(0)
# 			total_bytes = ctypes.c_ulonglong(0)
# 			success = ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(path), ctypes.byref(free_bytes), ctypes.byref(total_bytes), None)
# 			return free_bytes.value if success else None
# 		except: return None
# 	else:
# 		try:
# 			st = os.statvfs(path)
# 			return st.f_bavail * st.f_frsize
# 		except: return None
import os
import sys
import shutil
import ctypes
from modules.kodi_utils import make_legal_filename, translate_path
# from modules.kodi_utils import logger

# Help needed from AI to get correct calls per OS

def get_available_space(target_path):
	target_path = make_legal_filename(target_path)
	translated_path = translate_path(target_path)
	if any(target_path.lower().startswith(proto) for proto in ['smb://', 'nfs://', 'dav://', 'ftp://']): return _check_network_space_fallback(translated_path)
	try:
		space = shutil.disk_usage(translated_path).free
		if space > 0: return space
	except: pass
	return _posix_vs_windows_space_fallback(translated_path)

def _check_network_space_fallback(translated_path):
	try: 
		space = shutil.disk_usage(translated_path).free
		return space if space > 0 else None
	except: return None

def _posix_vs_windows_space_fallback(path):
	if sys.platform == 'win32' or os.name == 'nt':
		try:
			if ':' in path and not path.endswith('\\'): path += '\\'
			free_avail = ctypes.c_ulonglong(0)
			success = ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(path), ctypes.byref(free_avail), None, None)
			return free_avail.value if success else None
		except: return None
	else:
		try:
			st = os.statvfs(path)
			space = st.f_bavail * st.f_frsize
			return space if space > 0 else None
		except: return None


