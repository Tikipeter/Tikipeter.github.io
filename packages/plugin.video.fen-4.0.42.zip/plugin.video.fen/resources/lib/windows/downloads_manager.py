# -*- coding: utf-8 -*-
import json
from windows.base_window import BaseDialog
from modules.kodi_utils import select_dialog, confirm_dialog, ok_dialog
# from modules.kodi_utils import logger

class DownloadsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2500
		self.closed = False
		self.position = 0

	def onInit(self):
		self.update_downloads()
		self.setFocusId(self.window_id)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			return self.close()
		else:
			if action in self.context_actions or action in self.selection_actions: return self.set_status(self.get_listitem(self.window_id))

	def set_running_properties(self):
		active = json.loads(self.get_home_property('active_downloads') or '[]')
		queued = json.loads(self.get_home_property('queued_downloads') or '[]')
		self.all_tracked_downloads = active + queued
		self.setProperty('active', str(len(active)))
		self.setProperty('queued', str(len(queued)))
		self.setProperty('speed_limit', self.get_home_property('speed_limit') or '0')
		self.active_downloads = active
		self.queued_downloads = queued


	def sync_item_properties(self, listitem, item_id):
		listitem.setProperty('image', self.get_home_property('%s.image' % item_id))
		if item_id in self.active_downloads:
			listitem.setProperty('percent', self.get_home_property('%s.percent' % item_id))
			listitem.setProperty('speed', self.get_home_property('%s.speed' % item_id))
			listitem.setProperty('eta', self.get_home_property('%s.eta' % item_id))
			listitem.setProperty('status', self.get_home_property('%s.download_status' % item_id))
		else:
			listitem.setProperty('percent', '0')
			listitem.setProperty('status', 'queued')

	def update_downloads(self):
		try:
			self.set_running_properties()
			control = self.get_control(self.window_id)
			container_size = control.size()
			visible_item_ids = set()
			for index in range(container_size):
				item_id = self.get_listitem_by_index(index, control).getProperty('item_id')
				if item_id: visible_item_ids.add(item_id)
			for index in range(container_size - 1, -1, -1):
				listitem = self.get_listitem_by_index(index, control)
				item_id = listitem.getProperty('item_id')
				percent = self.get_home_property('%s.percent' % item_id)
				if percent == '100' or item_id not in self.all_tracked_downloads:
					control.removeItem(index)
					continue
				self.sync_item_properties(listitem, item_id)
			for item_id in self.all_tracked_downloads:
				if item_id not in visible_item_ids:
					listitem = self.make_listitem()
					listitem.setProperty('item_id', item_id)
					listitem.setProperty('name', item_id.replace('.', ' ').replace('_', ' '))
					self.sync_item_properties(listitem, item_id)
					control.addItem(listitem)
		except: pass

	def monitor(self):
		while not self.closed:
			if not self.active_downloads and not self.queued_downloads: break
			self.sleep(1000)
			self.update_downloads()

	def set_status(self, list_item):
		choices = []
		item_id = list_item.getProperty('item_id')
		status = self.get_home_property('%s.download_status' % item_id)
		if status == 'queued': choices.append(('Full Filename', 'filename'))
		elif status == 'paused': choices.append(('Resume Download', 'unpaused'))
		else: choices.append(('Pause Download', 'paused'))
		choices.append(('Cancel Download', 'cancelled'))
		choices.append(('Full Filename', 'filename'))
		choices.append(('Settings', 'settings'))
		list_items = [{'line1': i[0]} for i in choices]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		status_choice = select_dialog([i[1] for i in choices], **kwargs)
		if status_choice == None: return
		if status_choice == 'filename': return ok_dialog(text=list_item.getProperty('name'))
		if status_choice == 'cancelled' and not confirm_dialog(): return
		if status_choice in ('paused', 'unpaused', 'cancelled'): return self.set_home_property('%s.download_status' % item_id, status_choice)
		if status_choice == 'settings':
			choices = [('Set Max Download Speed', 'max_speed'), ('Set Max Active Downloads', 'max_active')]
			list_items = [{'line1': i[0]} for i in choices]
			kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
			status_choice = select_dialog([i[1] for i in choices], **kwargs)
			if status_choice == None: return
			from caches.settings_cache import set_numeric
			set_numeric({'setting_id': 'download.%s' % status_choice})
