# -*- coding: utf-8 -*-
import os
import sys
import shutil
import ctypes
from modules.kodi_utils import make_legal_filename, translate_path
# from modules.kodi_utils import logger

# Help needed from AI to get correct calls per OS

def get_available_space(target_path):
	target_path = make_legal_filename(target_path)
	translated_path = translate_path(target_path)
	if any(target_path.lower().startswith(proto) for proto in ['smb://', 'nfs://', 'dav://', 'ftp://']): return _check_network_space_fallback(translated_path)
	try: return shutil.disk_usage(translated_path).free
	except: return _posix_vs_windows_space_fallback(translated_path)

def _check_network_space_fallback(translated_path):
	try:
		if not any(translated_path.lower().startswith(p) for p in ['smb://', 'nfs://']): return shutil.disk_usage(translated_path).free
	except: pass
	return None

def _posix_vs_windows_space_fallback(path):
	if sys.platform == 'win32' or os.name == 'nt':
		try:
			free_bytes = ctypes.c_ulonglong(0)
			total_bytes = ctypes.c_ulonglong(0)
			success = ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(path), ctypes.byref(free_bytes), ctypes.byref(total_bytes), None)
			return free_bytes.value if success else None
		except: return None
	else:
		try:
			st = os.statvfs(path)
			return st.f_bavail * st.f_frsize
		except: return None

