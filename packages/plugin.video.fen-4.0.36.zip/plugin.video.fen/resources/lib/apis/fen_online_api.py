# -*- coding: utf-8 -*-
import os
import zlib
import json
import base64
import string
import secrets
import hashlib
import sqlite3
from caches.base_cache import database_locations, connect_database, check_databases_integrity, get_timestamp
from caches.settings_cache import get_setting, set_many_settings
from modules.utils import chacha20_crypt
from modules import kodi_utils

logger = kodi_utils.logger
base_url = '%s/users/%s/%s.json'
key_test = (None, 'empty_setting', '')
all_dbs = [('watched_db', 'watched'), ('watched_db', 'progress'), ('watched_db', 'watched_status'), ('personal_lists_db', 'personal_lists'),
			('favorites_db', 'favorites'), ('settings_db', 'settings')]
registration_key = 'AueurtnEUUEnnfl193847cPP48vnjh'

def create_profile():
	max_attempts = 3
	assign_own_key = kodi_utils.confirm_dialog(heading='Fen Online Sync',
									text='You need a 6-10 character User Code[CR]Do you want to assign it yourself or allow Fen to assign a random string?',
									ok_label='Assign', cancel_label='Random', default_control=11)
	if assign_own_key is None: return
	if assign_own_key:
		for attempts in range(1, max_attempts + 1):
			remaining = max_attempts - attempts
			user_code = kodi_utils.kodi_dialog().input(heading='Enter a 6-10 character User Code')
			if user_code in (None, ''): return False
			user_code = user_code.upper().strip()
			if (not 6 <= len(user_code) <= 10) or not user_code.isalnum():
				if remaining == 0: return
				if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
										'Use 6-10 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
										ok_label='Retry', cancel_label='Cancel', default_control=10): return
			else: break
	else: user_code = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_pin = kodi_utils.kodi_dialog().numeric(0, 'Enter a 4-digit PIN')
		if user_pin in (None, ''): return False
		if len(user_pin) != 4 or not user_pin.isdigit():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Numbers (0-9)[CR][CR]'
									'Use exactly 4 Numbers[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	user_hex, crypto_key_hex = make_user_keys(user_code, user_pin)
	success = create_account(user_hex)
	if success:
		set_many_settings([('fen_online.user_code', user_code), ('fen_online.user_pin', user_pin), ('fen_online.user_hex', user_hex),
							('fen_online.crypto_key_hex', crypto_key_hex)])
		full_push()
		kodi_utils.ok_dialog('Fen Online Sync', ('Success![CR]Your new User Code is [B]%s[/B][CR]Your new User PIN is [B]%s[/B]'
						'[CR]You need these for access, so keep them safe[CR]They cannot be recovered if lost' % (user_code, user_pin)))
	else: kodi_utils.ok_dialog('Fen Online Sync', 'FAILED![CR]There was an error creating your account[CR][CR]Please try again')

def connect_device():
	if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Connecting to a current Fen Online Account will mean that your local data '
		'will be overwritten with the data from the Fen Online account. This includes if there is no data currently online. Consider this before continuing'),
		ok_label='Continue', cancel_label='Cancel', default_control=11): return
	max_attempts = 3
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_code = kodi_utils.kodi_dialog().input(heading='Enter your 6-10 character User Code')
		if user_code in (None, ''): return False
		user_code = user_code.upper().strip()
		if (not 6 <= len(user_code) <= 10) or not user_code.isalnum():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
									'Use 6-10 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_pin = kodi_utils.kodi_dialog().numeric(0, 'Enter your 4-digit PIN')
		if user_pin in (None, ''): return False
		if len(user_pin) != 4 or not user_pin.isdigit():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Numbers (0-9)[CR][CR]'
									'Use exactly 4 Numbers[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	kodi_utils.show_busy_dialog()
	user_hex, crypto_key_hex = make_user_keys(user_code, user_pin)
	response = make_call('GET', '', user_hex, show_busy=True)
	if response.status_code == 200:
		full_data = response.json()
		set_many_settings([('fen_online.user_code', user_code), ('fen_online.user_pin', user_pin), ('fen_online.user_hex', user_hex),
							('fen_online.crypto_key_hex', crypto_key_hex)])
		full_pull(full_data=full_data)
	kodi_utils.hide_busy_dialog()

def revoke_account():
	from modules import watched_status
	if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Remove Authorization for this Device?', ok_label='Yes', cancel_label='No', default_control=10):
		user_hex = get_setting('fen.fen_online.user_hex')
		deletion_payload = {'watched': None, 'progress': None, 'settings': None, 'personal_lists': None, 'favorites': None, 'watched_status': None, 'last_updated_data': None}
		response = make_call('PATCH', '', get_setting('fen.fen_online.user_hex'), data=deletion_payload, show_busy=True)
		set_many_settings([('fen_online.user_code', 'empty_setting'), ('fen_online.user_pin', 'empty_setting'), ('fen_online.user_hex', 'empty_setting'),
							('fen_online.crypto_key_hex', 'empty_setting')])
		kodi_utils.set_property('fen_online.last_sync', str(get_timestamp()))

def full_push():
	user_hex, crypto_key_hex = get_setting('fen.fen_online.user_hex'), get_setting('fen.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	kodi_utils.show_busy_dialog()
	try:
		payload = {}
		for db_name, table_name in all_dbs:
			try:
				data_dict_list = process_rows(db_name, table_name)
				timestamp = kodi_utils.last_modified_time_for_file(database_locations(db_name))
				payload[table_name] = encrypt_data(data_dict_list, crypto_key_hex)
				payload['last_updated_data/%s' % table_name] = timestamp
			except Exception as e: logger('full push payload adds error', str(e))
		response = make_call('PATCH', '', user_hex, data=payload)
	except Exception as e: logger('full push main error', str(e))
	kodi_utils.hide_busy_dialog()
	kodi_utils.set_property('fen_online.last_sync', str(get_timestamp()))

def full_pull(full_data=None):
	user_hex, crypto_key_hex = get_setting('fen.fen_online.user_hex'), get_setting('fen.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	if full_data == None:
		response = make_call('GET', '', user_hex)
		if response.status_code == 200: full_data = response.json()
	if not full_data: return
	last_updated_data = full_data.get('last_updated_data', {})
	for db_name, table_name in all_dbs:
		try:
			encrypted_string = full_data.get(table_name)
			if encrypted_string in (None, 'null', ''): continue
			try: data_dict_list = decrypt_data(encrypted_string, crypto_key_hex)
			except: continue
			if not data_dict_list: continue
			online_timestamp = last_updated_data.get(table_name) or get_timestamp()
			success = write_to_sql(db_name, table_name, online_timestamp, data_dict_list)
		except Exception as e: logger('full pull main error', str(e))
	kodi_utils.set_property('fen_online.last_sync', str(get_timestamp()))

def push_single(db_name, table_name, user_hex=None, crypto_key_hex=None, session=None, timestamp=None):
	if not user_hex: user_hex, crypto_key_hex = get_setting('fen.fen_online.user_hex'), get_setting('fen.fen_online.crypto_key_hex')
	if not timestamp: timestamp = kodi_utils.last_modified_time_for_file(database_locations(db_name))
	data_dict_list = process_rows(db_name, table_name)
	payload = {table_name: encrypt_data(data_dict_list, crypto_key_hex), 'last_updated_data/%s' % table_name: timestamp}
	response = make_call('PATCH', '', user_hex, data=payload, session=session)
	return response

def pull_single(db_name, table_name, timestamp, user_hex=None, crypto_key_hex=None, session=None):
	if not user_hex: user_hex, crypto_key_hex = get_setting('fen.fen_online.user_hex'), get_setting('fen.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	response = make_call('GET', table_name, user_hex, session=session)
	if response.status_code != 200: return None
	encrypted_string = response.json()
	if encrypted_string in (None, 'null', ''): return None
	try: data_dict_list = decrypt_data(encrypted_string, crypto_key_hex)
	except: return None
	if not data_dict_list: return None
	success = write_to_sql(db_name, table_name, timestamp, data_dict_list)
	if not success: return None
	return response

def run_sync():
	user_hex, crypto_key_hex = get_setting('fen.fen_online.user_hex'), get_setting('fen.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return None
	session = kodi_utils.make_session()
	response = make_call('GET', 'last_updated_data', user_hex, session=session)
	if response.status_code != 200: return None
	last_updated_data = response.json()
	payload = {}
	for db_name, table_name in all_dbs:
		online_timestamp = int(last_updated_data.get(table_name, '0'))
		local_timestamp = kodi_utils.last_modified_time_for_file(database_locations(db_name))
		if online_timestamp > local_timestamp:
			logger('Fen Online Sync: Run Sync: %s' % table_name, 'get online data')
			pull_single(db_name, table_name, online_timestamp, user_hex=user_hex, crypto_key_hex=crypto_key_hex, session=session)
		elif local_timestamp > online_timestamp:
			logger('Fen Online Sync: Run Sync send online data: %s' % table_name, (online_timestamp, local_timestamp))
			data_dict_list = process_rows(db_name, table_name)
			payload[table_name] = encrypt_data(data_dict_list, crypto_key_hex)
			payload['last_updated_data/%s' % table_name] = local_timestamp
		else: logger('Fen Online Sync: Run Sync: %s' % table_name, 'no change')
	if payload: response = make_call('PATCH', '', user_hex, data=payload, session=session)
	session.close()
	kodi_utils.set_property('fen_online.last_sync', str(get_timestamp()))
	return response

def access_user_code():
	user_code, user_pin = get_setting('fen.fen_online.user_code'), get_setting('fen.fen_online.user_pin')
	if user_code in key_test: return kodi_utils.ok_dialog('Fen Online Sync', 'No User Code is Available')
	expires_in = 20
	start, time_passed = get_timestamp(), 0
	content = 'User Code: [B]%s[/B][CR]User Pin: [B]%s[/B]' % (user_code, user_pin)
	progressDialog = kodi_utils.progress_dialog('Fen Online Sync', kodi_utils.get_icon('firebase'))
	progressDialog.update(content, 100)
	while not progressDialog.iscanceled() and time_passed < expires_in:
		time_passed = get_timestamp() - start
		progress = int(100 * (expires_in - time_passed) / float(expires_in))
		progress = max(0, min(100, progress))
		progressDialog.update(content, progress)
		kodi_utils.sleep(1000)
	try: progressDialog.close()
	except: pass
	return

def delete_current_data(db_name, table_name, dbcon=None):
	if dbcon is None: dbcon = connect_database(db_name)
	dbcon.execute('DELETE FROM %s' % table_name)
	dbcon.execute('VACUUM')

def make_sql_inserts(data_dict_list):
	columns = list(data_dict_list[0].keys())
	columns_str = ', '.join(columns)
	placeholders_str = ', '.join(['?'] * len(columns))
	data_tuples = [tuple(row[col] for col in columns) for row in data_dict_list]
	return columns_str, placeholders_str, data_tuples

def write_to_sql(db_name, table_name, timestamp, data_dict_list):
	check_databases_integrity(silent=True)
	dbcon = connect_database(db_name)
	delete_current_data(db_name, table_name, dbcon=dbcon)
	try: columns_str, placeholders_str, data_tuples = make_sql_inserts(data_dict_list)
	except: return False
	query = 'INSERT OR REPLACE INTO %s (%s) VALUES (%s)' % (table_name, columns_str, placeholders_str)
	result = dbcon.executemany(query, data_tuples)
	dbcon.close()
	os.utime(database_locations(db_name), (timestamp, timestamp))
	logger('Pull Sync Status', 'Inserted %s rows from %s tuples.' % (result.rowcount, len(data_dict_list)))
	return result.rowcount == len(data_dict_list)

def make_call(method, url, user_hex, session=None, data=None, timeout=10, show_busy=False):
	if show_busy: kodi_utils.show_busy_dialog()
	if not session:
		session = kodi_utils.make_session()
		close_session = True
	else: close_session = False
	user_url = get_setting('fen.fen_online.url', 'https://fen-history-default-rtdb.firebaseio.com')
	url = base_url % (user_url, user_hex, url)
	try: response = session.request(method=method.upper(), url=url, json=data, timeout=timeout)
	except Exception as e:
		logger('make_call Error', str(e))
		response = None
	if close_session: session.close()
	if show_busy: kodi_utils.hide_busy_dialog()
	return response

def create_account(user_hex, session=None):
	if not session: session = kodi_utils.make_session()
	try:
		user_url = get_setting('fen.fen_online.url', 'https://fen-history-default-rtdb.firebaseio.com')
		target_url = user_url + '/registration_open.json'
		response = session.request(method='GET', url=target_url)
		if response.status_code != 200 or response.json() != True:
			logger('Registration failed', 'Server registrations are currently closed')
			return False
	except: return False
	try:
		response = make_call('PUT', 'profile', user_hex, session=session, data={'activated': True, 'registration_key': registration_key})
		if response.status_code == 200: return True			
		else:
			logger('Registration failed with server status', response.status_code)
			return False
	except Exception as e:
		logger('Exception during profile upload', str(e))
		return False

def make_user_keys(user_code, user_pin):
	credentials = '%s::%s' % (user_code, user_pin)
	credentials = credentials.encode('utf-8')
	folder_salt = b'Kodi_Fen_Folder_Salt_2026'
	user_hex = hashlib.pbkdf2_hmac(hash_name='sha256', password=credentials, salt=folder_salt, iterations=100000).hex()
	crypto_salt = b"Kodi_Fen_Crypto_Salt_2026"
	crypto_key_hex = hashlib.pbkdf2_hmac(hash_name='sha256', password=credentials, salt=crypto_salt, iterations=100000).hex()
	return user_hex, crypto_key_hex

def encrypt_data(data_dict, crypto_key_hex):
	key_bytes = bytes.fromhex(crypto_key_hex)
	json_bytes = json.dumps(data_dict).encode('utf-8')
	compressed_bytes = zlib.compress(json_bytes, level=9)
	nonce = os.urandom(12)
	ciphertext = chacha20_crypt(compressed_bytes, key_bytes, nonce)
	return base64.b64encode(nonce + ciphertext).decode('utf-8')

def decrypt_data(base64_string, crypto_key_hex):
	key_bytes = bytes.fromhex(crypto_key_hex)
	raw_bytes = base64.b64decode(base64_string.encode('utf-8'))
	nonce = raw_bytes[:12]
	ciphertext = raw_bytes[12:]
	compressed_bytes = chacha20_crypt(ciphertext, key_bytes, nonce)
	json_bytes = zlib.decompress(compressed_bytes)
	return json.loads(json_bytes.decode('utf-8'))

def process_rows(db_path, table_name):
	try:
		dbcon = connect_database(db_path)
		dbcon.row_factory = sqlite3.Row
		local_rows = dbcon.execute('SELECT * FROM %s' % table_name).fetchall()
		return [dict(row) for row in local_rows]
	except: return []
