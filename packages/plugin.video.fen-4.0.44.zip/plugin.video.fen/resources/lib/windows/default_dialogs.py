# -*- coding: utf-8 -*-
import os
import json
import copy
from urllib.parse import parse_qsl, unquote
from windows.base_window import BaseDialog
from modules import kodi_utils
# logger = kodi_utils.logger

class Select(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.control_id = None
		self.window_id = 2025
		self.kwargs = kwargs
		self.enumerate = self.kwargs.get('enumerate', 'false')
		self.multi_choice = self.kwargs.get('multi_choice', 'false')
		self.multi_line = self.kwargs.get('multi_line', 'false')
		self.preselect = self.kwargs.get('preselect', [])
		self.items = json.loads(self.kwargs['items'])
		self.heading = self.kwargs.get('heading', '')
		self.narrow_window = self.kwargs.get('narrow_window', 'false')
		self.set_focus = self.kwargs.get('set_focus', None)
		self.item_list = []
		self.chosen_indexes = []
		self.selected = None
		self.set_properties()
		self.make_menu()

	def onInit(self):
		self.add_items(self.window_id, self.item_list)
		if self.preselect:
			if len(self.preselect) == len(self.item_list): self.setProperty('select_button', 'deselect_all')
			for index in self.preselect:
				self.item_list[index].setProperty('check_status', 'checked')
				self.chosen_indexes.append(index)
		self.setFocusId(self.window_id)
		if self.set_focus is not None: self.select_item(self.window_id, self.set_focus)

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected

	def onClick(self, controlID):
		self.control_id = None
		if controlID in (10, 11, 12, 13):
			if controlID == 10:
				self.selected = sorted(self.chosen_indexes)
				self.close()
			elif controlID == 11:
				self.close()
			elif controlID in (12, 13):
				item_list_indexes = list(range(0, len(self.item_list)))
				if controlID == 12: status, select_property, self.chosen_indexes = 'checked', 'deselect_all', item_list_indexes
				else: status, select_property, self.chosen_indexes = '', 'select_all', []
				for index in item_list_indexes: self.item_list[index].setProperty('check_status', status)
				self.setProperty('select_button', select_property)
				try: self.setFocusId(10)
				except: pass
		else: self.control_id = controlID

	def onAction(self, action):
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.selection_actions:
			if not self.control_id: return
			position = self.get_position(self.window_id)
			if self.multi_choice == 'true':
				if chosen_listitem.getProperty('check_status') == 'checked':
					chosen_listitem.setProperty('check_status', '')
					self.chosen_indexes.remove(position)
				else:
					chosen_listitem.setProperty('check_status', 'checked')
					self.chosen_indexes.append(position)
			else:
				self.selected = position
				return self.close()
		elif action in self.context_actions or action in self.closing_actions: return self.close()

	def make_menu(self):
		def builder():
			enum = self.enumerate == 'true'
			for count, item in enumerate(self.items, 1):
				listitem = self.make_listitem()
				if enum: line1 = '%02d. %s' % (count, item['line1'])
				else: line1 = item['line1']
				if 'line2' in item: line2 = item['line2']
				else: line2 = ''
				if 'icon' in item: listitem.setProperty('icon', item['icon'])
				else: listitem.setProperty('icon', '')
				listitem.setProperty('line1', line1)
				listitem.setProperty('line2', line2)
				yield listitem
		self.item_list = list(builder())

	def set_properties(self):
		self.setProperty('multi_choice', self.multi_choice)
		self.setProperty('multi_line', self.multi_line)
		self.setProperty('select_button', 'select_all')
		self.setProperty('heading', self.heading)
		self.setProperty('narrow_window', self.narrow_window)

class Confirm(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs['ok_label']
		self.cancel_label = kwargs['cancel_label']
		self.text = kwargs['text']
		self.heading = kwargs['heading']
		self.default_control = kwargs['default_control']
		self.selected = None
		self.set_properties()

	def onInit(self):
		self.setFocusId(self.default_control)

	def run(self):
		self.doModal()
		return self.selected

	def onClick(self, controlID):
		self.selected = {10: True, 11: False}[controlID]
		self.close()

	def onAction(self, action):
		if action in self.closing_actions: self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('cancel_label', self.cancel_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)

class OK(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs.get('ok_label')
		self.text = kwargs['text']
		self.heading = kwargs['heading']
		self.set_properties()

	def onInit(self):
		self.setFocusId(10)

	def run(self):
		self.doModal()

	def onClick(self, controlID):
		self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)

class ListEditor(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2025
		self.kwargs = kwargs
		self.all_items = copy.deepcopy(self.kwargs['all_items'])
		self.enumerate = self.kwargs.get('enumerate', 'false') == 'true'
		self.active_enabled = self.kwargs.get('active_enabled')
		self.listitem_preface = self.kwargs.get('listitem_preface')
		self.heading = self.kwargs.get('heading', '')
		self.mode = self.kwargs.get('mode', 'default')
		self.focus = 302 if self.mode == 'move' else 303
		self.item_list = []
		self.chosen_indexes = []
		self.selected = None
		self.set_properties()
		self.make_menu()

	def onInit(self):
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.focus)

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.all_items

	def onClick(self, controlId):
		position = self.get_position(self.window_id)
		if position < 0: return
		if controlId == 300: self.add_item(position)
		if controlId == 301: self.move_item(position, direction=-1)
		elif controlId == 302: self.move_item(position, direction=1)
		elif controlId == 303: self.toggle_item(position)
		else: return

	def make_menu(self):
		def builder():
			for count, item in enumerate(self.all_items, 1):
				listitem = self.make_listitem()
				if self.listitem_preface: name = self.listitem_preface + item['name']
				else: name = item['name']
				if self.enumerate: name = '%02d. %s' % (count, name)
				if 'enabled' in item: listitem.setProperty('enabled', 'true' if item['enabled'] else 'false')
				listitem.setProperty('name', name)
				yield listitem
		self.enforce_active_enabled()
		self.item_list = list(builder())

	def enforce_active_enabled(self):
		if self.active_enabled == None: return
		for index, item in enumerate(self.all_items): item['enabled'] = index < self.active_enabled

	def set_properties(self):
		self.setProperty('heading', self.heading)
		self.setProperty('mode', self.mode)

	def toggle_item(self, position):
		self.all_items[position]['enabled'] = not self.all_items[position]['enabled']
		self.refresh_menu()

	def move_item(self, position, direction):
		total_items = len(self.all_items)
		if total_items <= 1: return
		target = (position + direction) % total_items
		moving_item = self.all_items.pop(position)
		self.all_items.insert(target, moving_item)
		for index, item in enumerate(self.all_items): item['position'] = index
		self.refresh_menu(new_focus=target)

	def refresh_menu(self, new_focus=None):
		if new_focus is None: new_focus = self.get_position(self.window_id)
		self.make_menu()
		self.reset_window(self.window_id)
		self.add_items(self.window_id, self.item_list)
		self.select_item(self.window_id, new_focus)

	def add_item(self, position):
		target = position + 1
		browsed_result = self._path_browser()
		if browsed_result == None: return
		menu_item = self._get_menu_item(browsed_result['file'])
		name, icon = browsed_result['label'], self._get_icon_var(browsed_result['thumbnail'])
		menu_name = self._get_external_name_input(name) or name
		icon_choice = self._icon_select(default_icon=icon)
		menu_item.update({'name': menu_name, 'iconImage': icon_choice, 'enabled': True, 'position': target})
		self.all_items.insert(target, menu_item)
		self.refresh_menu()

	def _path_browser(self, label='', file='plugin://plugin.video.fen?mode=navigator.main&full_list=true', thumbnail=''):
		kodi_utils.show_busy_dialog()
		results = kodi_utils.jsonrpc_get_directory(file)
		kodi_utils.hide_busy_dialog()
		list_items, function_items = [], []
		if file != 'plugin://plugin.video.fen?mode=navigator.main&full_list=true':
			list_items.append({'line1': 'Use [B]%s[/B] As Path' % label, 'icon': thumbnail})
			function_items.append(json.dumps({'label': label, 'file': file, 'thumbnail': thumbnail}))
		list_items.extend([{'line1': '%s >>' % i['label'], 'icon': i['thumbnail']} for i in results])
		function_items.extend([json.dumps({'label': i['label'], 'file': '%s%s' % (i['file'], '&full_list=true') if 'navigator.main' in i['file'] else i['file'],
								'thumbnail': i['thumbnail']}) for i in results])
		kwargs = {'items': json.dumps(list_items)}
		choice = kodi_utils.select_dialog(function_items, **kwargs)
		if choice == None: return None
		choice = json.loads(choice)
		if choice['file'] == file: return choice
		else: return self._path_browser(**choice)

	def _get_menu_item(self, path):
		return dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

	def _get_icon_var(self, icon_path):
		try:
			all_icons = kodi_utils.get_all_icons()
			icon_value = unquote(icon_path)
			icon_value = os.path.basename(os.path.normpath(icon_value))
			icon_value = icon_value.replace('.png/', '').replace('.png', '')
			icon_var = [i for i in all_icons if i == icon_value][0]
		except: icon_var = 'folder'
		return icon_var

	def _icon_select(self, default_icon=''):
		if default_icon.startswith('http') or 'plugin.video.fen' in default_icon: return default_icon
		all_icons = kodi_utils.get_all_icons()
		if default_icon:
			try:
				all_icons.remove(default_icon)
				all_icons.insert(0, default_icon)
			except: pass
			list_items = [{'line1': i if i != default_icon else '%s (default)' % default_icon, 'icon': kodi_utils.get_icon(i)} for i in all_icons]
		else: list_items = [{'line1': i, 'icon': kodi_utils.get_icon(i)} for i in all_icons]
		kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Icon'}
		icon_choice = kodi_utils.select_dialog(all_icons, **kwargs) or default_icon or 'folder'
		return icon_choice

	def _get_external_name_input(self, current_name):
		new_name = kodi_utils.kodi_dialog().input('', defaultt=current_name)
		if new_name == current_name: return None
		return new_name
