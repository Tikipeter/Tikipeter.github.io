# -*- coding: utf-8 -*-
import os
import sys
import ssl
import json
import time
import requests
import collections
from threading import Thread
from urllib.request import Request, urlopen
from urllib.parse import parse_qsl, urlparse, unquote
from modules import kodi_utils
from modules.sources import Sources
from modules.space_checker import get_available_space
from modules.settings import download_speed_limit, download_concurrent_limit, download_directory
from modules.source_utils import clean_title
from modules.utils import clean_file_name, normalize
# logger = kodi_utils.logger

def runner(params):
	action = params.get('action')
	if action == 'image':
		for item in ('thumb_url', 'image_url'):
			image_params = params
			image_params['url'] = params.pop(item)
			image_params['media_type'] = item
			Downloader(image_params).run()
	elif action == 'meta.pack':
		from modules.source_utils import find_season_in_release_title
		provider = params['provider']
		try:
			debrid_files = Sources().debridPacks(provider, params['name'], params['magnet_url'], params['info_hash'], download=True)
			pack_choices = [dict(params, **{'pack_files':item}) for item in debrid_files]
			icon = {'Premiumize.me': 'premiumize', 'Torbox': 'torbox', 'Offcloud': 'offcloud'}[provider]
		except: return kodi_utils.notification('No URL found for Download. Pick another Source.')
		default_icon = kodi_utils.get_icon(icon)
		chosen_list = select_pack_item(pack_choices, default_icon)
		if not chosen_list: return
		down_object = Downloader({})
		down_object.content = sum([i['pack_files']['size'] for i in chosen_list])
		down_object.down_folder = download_directory('episode')
		down_object.final_name = clean_file_name(json.loads(chosen_list[0].get('source')).get('name'))
		proceed = down_object.check_available_space()
		if not proceed: return kodi_utils.notification('Cancelled', 2500)
		show_package = json.loads(params['source']).get('package') == 'show'
		meta  = json.loads(chosen_list[0].get('meta'))
		image = meta.get('poster') or kodi_utils.get_icon('box_office')
		default_name = '%s (%s)' % (clean_file_name(get_title(meta)), get_year(meta))
		default_foldername = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
		multi_downloads = []
		multi_downloads_append = multi_downloads.append
		kodi_utils.notification('Multi File Pack Download Started...', 3000, image)
		for item in chosen_list:
			if show_package:
				season = find_season_in_release_title(item['pack_files']['filename'])
				if season:
					meta['season'] = season
					item['meta'] = json.dumps(meta)
					item['default_foldername'] = default_foldername
			Thread(target=Downloader(item).run).start()
			kodi_utils.sleep(1500)
	else: Thread(target=Downloader(params).run).start()

def select_pack_item(pack_choices, icon):
	list_items = [{'line1': '%.2f GB | %s' % (float(item['pack_files']['size'])/1073741824, clean_file_name(item['pack_files']['filename']).upper()), 'icon': icon} \
				for item in pack_choices]
	heading = 'Choose Files to Download - %s' % clean_file_name(json.loads(pack_choices[0].get('source')).get('name'))
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'enumerate': 'true', 'multi_choice': 'true', 'preselect': [i for i in range(len(list_items))]}
	return kodi_utils.select_dialog(pack_choices, **kwargs)

def get_title(meta):
	title = meta.get('custom_title', None) or meta.get('english_title') or meta.get('title')	
	return title

def get_year(meta):
	return meta.get('custom_year', None) or meta.get('year')

def get_season(meta):
		season = meta.get('custom_season', None) or meta.get('season')
		return int(season) if season else None

class Downloader:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get

	def run(self):
		self.download_prep()
		if not self.action == 'meta.pack': kodi_utils.show_busy_dialog()
		self.get_url_and_headers()
		if self.url in (None, 'None', ''): return self.return_notification(_notification='No URL found for Download. Pick another Source')
		self.get_filename()
		self.get_extension()
		if not self.download_check(): return self.return_notification(_ok_dialog='Failed')
		self.get_download_folder()
		if not self.confirm_download(): return self.return_notification(_notification='Cancelled')
		if not self.get_destination_folder(): return self.return_notification(_notification='Cancelled')
		self.download_runner()

	def download_prep(self):
		if 'meta' in self.params:
			self.meta = json.loads(self.params_get('meta'))
			self.meta_get = self.meta.get
			self.media_type = self.meta_get('media_type')
			self.title = clean_file_name(get_title(self.meta))
			self.year = get_year(self.meta)
			self.season = get_season(self.meta)
			self.image = self.meta_get('poster') or kodi_utils.get_icon('box_office')
			self.name = self.params_get('name')
		else:
			self.meta, self.name, self.year, self.season = None, None, None, None
			self.media_type = self.params_get('media_type')
			self.title = clean_file_name(self.params_get('name'))
			self.image = self.params_get('image')
		self.provider = self.params_get('provider')
		self.action = self.params_get('action')
		self.source = self.params_get('source')
		self.final_name = None

	def download_runner(self):
		self.final_destination = os.path.join(self.final_destination, self.final_name + self.extension)
		if self.media_type in ('image_url', 'thumb_url'): return self.start_download_image()
		self.set_image_property()
		while True:
			active_downloads = self.get_active_downloads()
			queued_downloads = self.get_queued_downloads()
			max_downloads = download_concurrent_limit()
			if len(active_downloads) < 2:
				self.remove_queued_download(queued_downloads)
				self.add_active_download(active_downloads)
				return self.start_download()
			elif self.final_name not in queued_downloads:
				self.add_queued_downloads(queued_downloads)
			kodi_utils.sleep(2000)

	def get_active_downloads(self):
		return json.loads(kodi_utils.get_property('fen.active_downloads') or '[]')

	def get_queued_downloads(self):
		return json.loads(kodi_utils.get_property('fen.queued_downloads') or '[]')

	def add_active_download(self, active_downloads):
		active_downloads.append(self.final_name)
		kodi_utils.set_property('fen.active_downloads', json.dumps(active_downloads))

	def add_queued_downloads(self, queued_downloads):
		queued_downloads.append(self.final_name)
		kodi_utils.set_property('fen.queued_downloads', json.dumps(queued_downloads))

	def remove_active_download(self):
		kodi_utils.set_property('fen.%s.percent' % self.final_name, '')
		kodi_utils.set_property('fen.%s.speed' % self.final_name, '')
		kodi_utils.set_property('fen.%s.eta' % self.final_name, '')
		kodi_utils.set_property('fen.%s.image' % self.final_name, '')
		active_downloads = self.get_active_downloads()
		try: active_downloads.remove(self.final_name)
		except: pass
		if active_downloads: kodi_utils.set_property('fen.active_downloads', json.dumps(active_downloads))
		else: self.clear_active_downloads()

	def remove_queued_download(self, queued_downloads):
		if self.action == 'image': return
		try: queued_downloads.remove(self.final_name)
		except: pass
		if queued_downloads: kodi_utils.set_property('fen.queued_downloads', json.dumps(queued_downloads))
		else: self.clear_queued_downloads()

	def clear_active_downloads(self):
		kodi_utils.clear_property('fen.active_downloads')

	def clear_queued_downloads(self):
		kodi_utils.clear_property('fen.queued_downloads')

	def check_status(self):
		status = kodi_utils.get_property('fen.download_status.%s' % self.final_name)
		if status in ('unpaused', 'cancelled'): kodi_utils.clear_property('fen.download_status.%s' % self.final_name)
		return status

	def get_url_and_headers(self):
		url = self.params_get('url')
		if url in (None, 'None', ''):
			if self.action == 'meta.single':
				try:
					source = json.loads(self.source)
					if source.get('scrape_provider', '') == 'easynews': source['url_dl'] = source['down_url']
					url = Sources().resolve_sources(source, meta=self.meta)
					if 'torbox' in url:
						from apis.torbox_api import TorBoxAPI
						url = TorBoxAPI().add_headers_to_url(url)
				except: pass
			elif self.action == 'meta.pack':
				url = self.params_get('pack_files')['link']
				if self.provider == 'Premiumize.me':
					from apis.premiumize_api import PremiumizeAPI
					url = PremiumizeAPI().add_headers_to_url(url)
				elif self.provider == 'TorBox':
					from apis.torbox_api import TorBoxAPI
					torbox = TorBoxAPI()
					url = torbox.unrestrict_link(url)
					url = torbox.add_headers_to_url(url)
		else:
			if self.action.startswith('cloud'):
				if '_direct' in self.action:
					url = self.params_get('url')
				elif 'premiumize' in self.action:
					from apis.premiumize_api import PremiumizeAPI
					url = PremiumizeAPI().add_headers_to_url(url)
				elif 'torbox' in self.action:
					from apis.torbox_api import TorBoxAPI
					from indexers.torbox import resolve_tb
					url = resolve_tb(self.params)
					url = TorBoxAPI().add_headers_to_url(url)
				elif 'easynews' in self.action:
					from indexers.easynews import resolve_easynews
					url = resolve_easynews(self.params)
		try: headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
		except: headers = dict('')
		try: url = url.split('|')[0]
		except: pass
		self.url = url
		self.headers = headers

	def get_download_folder(self):
		self.down_folder = download_directory(self.media_type)
		if self.media_type == 'thumb_url': self.down_folder = os.path.join(self.down_folder, '.thumbs')
		for level in ['../../../..', '../../..', '../..', '..']:
			try: kodi_utils.make_directory(os.path.abspath(os.path.join(self.down_folder, level)))
			except: pass

	def get_destination_folder(self):
		if self.action == 'image':
			self.final_destination = self.down_folder
		elif self.action in ('meta.single', 'meta.pack'):
			default_name = '%s (%s)' % (self.title, self.year)
			if self.action == 'meta.single': folder_rootname = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
			else: folder_rootname = self.params_get('default_foldername', default_name)
			if not folder_rootname: return False
			if self.media_type == 'episode':
				inter = os.path.join(self.down_folder, folder_rootname)
				kodi_utils.make_directory(inter)
				self.final_destination = os.path.join(inter, 'Season %02d' %  int(self.season))
			else: self.final_destination = os.path.join(self.down_folder, folder_rootname)
		else: self.final_destination = self.down_folder
		kodi_utils.make_directory(self.final_destination)
		return True

	def get_filename(self):
		if self.final_name: final_name = self.final_name
		elif self.action == 'meta.pack':
			name = self.params_get('pack_files')['filename']
			final_name = os.path.splitext(urlparse(name).path)[0].split('/')[-1]
		elif self.action == 'image':
			final_name = self.title
		else:
			name_url = unquote(self.url)
			file_name = clean_title(name_url.split('/')[-1])
			if clean_title(self.title).lower() in file_name.lower():
				final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
			else:
				try: final_name = self.name.translate(None, r'\/:*?"<>|').strip('.')
				except: final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
		self.final_name = normalize(final_name)

	def get_extension(self):
		if self.action == 'archive':
			ext = 'zip'
		elif self.action == 'image':
			ext = os.path.splitext(urlparse(self.url).path)[1][1:]
			if not ext in kodi_utils.image_extensions(): ext = 'jpg'
		else:
			ext = os.path.splitext(urlparse(self.url).path)[1][1:]
			if not ext in kodi_utils.video_extensions(): ext = 'mp4'
		ext = '.%s' % ext
		self.extension = ext

	def download_check(self):
		if self.media_type in ('image_url', 'thumb_url'): return True
		self.resp = self.get_response()
		if not self.resp: return False
		self.content = int(self.resp.headers.get('Content-Length', 0))
		accept_ranges = self.resp.headers.get('Accept-Ranges', '').lower()
		self.resumable = 'bytes' in accept_ranges
		if self.content < 1:
			self.resp.close()
			return False
		self.size = 1024 * 1024
		if self.content < self.size: 
			self.size = self.content
		kodi_utils.hide_busy_dialog()
		return True

	def get_response(self, size=0):
		try:
			headers = self.headers.copy()
			if size > 0: headers['Range'] = 'bytes=%s-' % int(size)
			resp = requests.get(self.url, headers=headers, timeout=30, stream=True)
			if resp.status_code in (200, 206): return resp
			return None
		except: return None

	def start_download(self):
		total, errors, resume = 0, 0, 0
		last_reported_percent = -1
		interval_start_time = time.time()
		interval_bytes = 0
		try:
			speed_limit = download_speed_limit()
			limit_mbps = float(speed_limit) if speed_limit else 0
			max_bytes_per_sec = (limit_mbps * 1_000_000) / 8 if limit_mbps > 0 else 0
		except: max_bytes_per_sec = 0
		f = kodi_utils.open_file(self.final_destination, 'wb')
		while True:
			try:
				for chunk in self.resp.iter_content(chunk_size=self.size):
					if chunk:
						f.write(chunk)
						total += len(chunk)
						interval_bytes += len(chunk) 
						errors = 0
						if max_bytes_per_sec > 0:
							ideal_duration = len(chunk) / max_bytes_per_sec
							if ideal_duration > 0.5:
								ideal_duration = 0.5
							if ideal_duration > 0.001:
								time.sleep(ideal_duration)
					current_time = time.time()
					elapsed_interval = current_time - interval_start_time
					if elapsed_interval >= 1.0:
						speed_bps = interval_bytes / elapsed_interval
						bytes_left = max(0, self.content - total)
						eta_string = self.format_eta(bytes_left, speed_bps)
						speed_string = self.format_speed(speed_bps)
						self.set_speed_property(speed_string)
						self.set_eta_property(eta_string)
						interval_start_time = current_time
						interval_bytes = 0
						percent = min(round(float(total) * 100 / self.content), 100)
						status = self.check_status()
						try:
							speed_limit = download_speed_limit()
							limit_mbps = float(speed_limit) if speed_limit else 0
							max_bytes_per_sec = (limit_mbps * 1_000_000) / 8 if limit_mbps > 0 else 0
						except: max_bytes_per_sec = 0
						kodi_utils.set_property('fen.speed_limit', '%sMbps' % speed_limit if max_bytes_per_sec != 0 else 'Unlimited')
					while status == 'paused':
						status = self.check_status()
						kodi_utils.sleep(1000)
						interval_start_time = time.time()
					if status == 'cancelled':
						f.close()
						return self.finish_download(status)
					if percent != last_reported_percent:
						self.set_percent_property(percent)
						last_reported_percent = percent
				f.close()
				return self.finish_download('success')
			except (requests.exceptions.RequestException, Exception) as e:
				errors += 1
				sleep_time = 10
				max_resumes = 500 if self.resumable else 50
				if resume >= max_resumes or errors >= 10:
					f.close()
					return self.finish_download('failed')
				kodi_utils.sleep(sleep_time * 1000)
				resume += 1
				errors = 0
				interval_start_time = time.time()
				interval_bytes = 0
				if self.resumable:
					self.resp = self.get_response(total)
				else:
					f.seek(0)
					f.truncate()
					total = 0
					self.resp = self.get_response(0)

	def set_image_property(self):
		kodi_utils.set_property('fen.%s.image' % self.final_name, self.image)

	def set_percent_property(self, percent):
		kodi_utils.set_property('fen.%s.percent' % self.final_name, str(percent))

	def set_speed_property(self, speed_string):
		kodi_utils.set_property('fen.%s.speed' % self.final_name, str(speed_string))

	def set_eta_property(self, eta_string):
		kodi_utils.set_property('fen.%s.eta' % self.final_name, str(eta_string))

	def format_speed(self, bps):
		bits_per_second = bps * 8
		mbps = bits_per_second / 1_000_000
		return '%.2f Mbps' % mbps

	def format_eta(self, bytes_left, speed_bps):
		if speed_bps <= 0: return 'Unknown'
		seconds_left = bytes_left / speed_bps
		hours, minutes, seconds = int(seconds_left // 3600), int((seconds_left % 3600) // 60), int(seconds_left % 60)
		if hours > 0: return '%sh %sm left' % (hours, minutes)
		if minutes > 0: return '%sm %ss left' % (minutes, seconds)
		return '%ss left' % seconds

	def start_download_image(self):
		try:
			resp = requests.get(self.url, headers=self.headers, timeout=10, stream=True)
			if resp.status_code == 200:
				with open(self.final_destination, 'wb') as f:
					for chunk in resp.iter_content(chunk_size=8192):
						if chunk: f.write(chunk)
				status = 'success'
			else: status = 'failed'
		except: status = 'failed'
		kodi_utils.hide_busy_dialog()
		self.finish_download(status)
		return True

	def finish_download(self, status):
		if self.action == 'image':
			if self.media_type == 'image_url': return kodi_utils.notification(status.upper(), 2500, self.final_destination)
			else: return
		if not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
			kodi_utils.notification('[B]%s[/B] %s' % (status.upper(), self.final_name.replace('.', ' ').replace('_', ' ')), 2500, self.image)
		self.remove_active_download()

	def check_available_space(self):
		no_space_detected = False
		available_space = get_available_space(self.down_folder)
		size_string = str(round(float(self.content) / 1073741824, 2))
		try: space_string = str(round(float(available_space) / 1073741824, 2))
		except: space_string = None
		if available_space is None or space_string is None:
			text = '[B]Unable to determine available space for download.[/B][CR][CR]Please check storage for [B]%sGB[/B] free[CR][CR]You can Continue or Cancel.' % size_string
		elif int(self.content) >= int(available_space):
			no_space_detected = True
			text = ('[B][COLOR red]!!!DANGER!!![/COLOR][/B][CR]There is insufficient space for this download.[CR]'
					'Available Space: [B]%sGB[/B][CR]'
					'Download Size: [B]%sGB[/B][CR][CR]'
					'[B]DO NOT CONTINUE WITH THIS DOWNLOAD!!![/B]') % (space_string, size_string)
		else: text = 'Complete file is [B]%sGB[/B][CR]Continue with download?' % size_string
		proceed = kodi_utils.confirm_dialog(heading=self.final_name, text=text, ok_label='Continue', cancel_label='Cancel', default_control=11)
		if proceed and no_space_detected:
			text = ('[B][COLOR red]FINAL WARNING: HIGH RISK[/COLOR][/B][CR][CR]Continuing may cause severe file corruption and system instability.[CR][CR]'
						'Select Continue to force the download anyway.')
			proceed = kodi_utils.confirm_dialog(heading=self.final_name, text=text, ok_label='Continue', cancel_label='Cancel', default_control=11)
		return proceed

	def confirm_download(self):
		if self.action in ('image', 'meta.pack'): return True
		return self.check_available_space()

	def return_notification(self, _notification=None, _ok_dialog=None):
		kodi_utils.hide_busy_dialog()
		if _notification: kodi_utils.notification(_notification, 2500)
		elif _ok_dialog: kodi_utils.ok_dialog(text=_ok_dialog)
		else: return

def viewer(params):
	def _process():
		for info in results:
			try:
				path = info[0]
				url = os.path.join(folder_path, path)
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(clean_file_name(normalize(path)))
				listitem.setArt({'fanart': fanart})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot(' ')
				yield (url, listitem, info[1])
			except: pass
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	folder_path = download_directory(params['folder_type'])
	dirs, files = kodi_utils.list_dirs(folder_path)
	results = [(i, True) for i in dirs] + [(i, False) for i in files]
	item_list = list(_process())
	kodi_utils.add_items(handle, item_list)
	kodi_utils.set_sort_method(handle, 'files')
	kodi_utils.set_content(handle, '')
	kodi_utils.set_category(handle, params.get('name'))
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main', '')

def manager(foo=None):
	from windows.base_window import open_window
	kwargs = {}
	return open_window(('windows.downloads_manager', 'DownloadsManager'), 'downloads_manager.xml', **kwargs)
