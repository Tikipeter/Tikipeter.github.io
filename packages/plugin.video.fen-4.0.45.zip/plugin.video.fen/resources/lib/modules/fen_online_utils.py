# -*- coding: utf-8 -*-
import functools
import threading
from apis import fen_online_api
from caches.base_cache import force_timestamp_update
from modules.settings import fen_online_user_active
from modules.kodi_utils import logger

# Help from AI for understanding functools usage

def single_sync(db_name, table_names):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			result = func(*args, **kwargs)
			logger('result', result)
			if not fen_online_user_active(): return result
			if result is not None:
				try:
					timestamp = force_timestamp_update(db_name)
					threading.Thread(target=fen_online_api.push_single, args=(db_name, table_names), kwargs={'timestamp': timestamp}).start()
				except Exception as e: logger('error single_sync decorator', str(e))
			return result
		return wrapper
	return decorator
