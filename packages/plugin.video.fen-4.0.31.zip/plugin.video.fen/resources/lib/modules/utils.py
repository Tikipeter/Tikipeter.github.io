# -*- coding: utf-8 -*-
import re
import sys
import time
import random
import inspect
import unicodedata
from html import unescape
from queue import SimpleQueue
from contextlib import nullcontext
from importlib import import_module
from threading import Thread, activeCount
from datetime import datetime, timedelta, date
from caches.base_cache import open_db
from modules.settings import max_threads
from modules.kodi_utils import sleep, logger

class TaskPool:
	def __init__(self):
		self._queue = SimpleQueue()
		self._max_threads = max_threads()

	def _thread_target(self, queue, target, db_name):
		sig = inspect.signature(target)
		uses_db = 'dbcon' in sig.parameters
		context = open_db(db_name) if (uses_db and db_name) else nullcontext(None)
		with context as dbcon:
			while not queue.empty():
				try:
					args = queue.get()
					if uses_db: target(*args, dbcon=dbcon)
					else: target(*args)
				except Exception as e: logger('thread queue error', str(e))

	def tasks(self, _target, _list, db_name=None):
		if not _list: return []
		if not isinstance(_list[0], tuple): _list = [(i,) for i in _list]
		[self._queue.put(tag) for tag in _list]
		threads = [Thread(target=self._thread_target, args=(self._queue, _target, db_name)) for _ in range(self._max_threads)]
		[i.start() for i in threads]
		return threads

	def tasks_enumerate(self, _target, _list, db_name=None):
		[self._queue.put((p, tag)) for p, tag in enumerate(_list, 1)]
		threads = [Thread(target=self._thread_target, args=(self._queue, _target, db_name)) for _ in range(self._max_threads)]
		[i.start() for i in threads]
		return threads

def make_thread_list(_target, _list):
	_max_threads = max_threads()
	for item in _list:
		while activeCount() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(item,))
		threaded_object.start()
		yield threaded_object

def make_thread_list_enumerate(_target, _list):
	_max_threads = max_threads()
	for count, item in enumerate(_list):
		while activeCount() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(count, item))
		threaded_object.start()
		yield threaded_object

def append_module_to_syspath(location):
	from modules.kodi_utils import translate_path
	sys.path.append(translate_path(location))

def manual_function_import(location, function_name):
	return getattr(import_module(location), function_name)

def reload_module(location):
	from importlib import reload as rel_module
	return rel_module(manual_module_import(location))

def manual_module_import(location):
	return import_module(location)

def chunks(item_list, limit):
	"""
	Yield successive limit-sized chunks from item_list.
	"""
	for i in range(0, len(item_list), limit): yield item_list[i:i + limit]

def string_to_float(string, default_return):
	"""
	Remove all alpha from string and return a float.
	Returns float of "default_return" upon ValueError or TypeError.
	"""
	if not string:return float(default_return)		
	try:
		cleaned = str(string).replace(' ', '').replace(',', '')
		return float(cleaned)
	except ValueError:
		try: return float(''.join(c for c in cleaned if c.isdigit() or c in '.-'))
		except (ValueError, TypeError): return float(default_return)
	except TypeError: return float(default_return)


def string_alphanum_to_num(string):
	"""
	Remove all alpha from string and return remaining string.
	Returns original string upon ValueError.
	"""
	try: return ''.join(c for c in string if c.isdigit())
	except ValueError: return string

def extract_ints(text):
	"""
	Finds all integers inside a string and returns them as a tuple.
	"""
	numbers = re.findall(r'\d+', text)
	return tuple(int(num) for num in numbers)

def jsondate_to_datetime(jsondate, resformat, remove_time=False):
	if not jsondate: return None		
	try:
		dt = datetime(*time.strptime(jsondate, resformat)[:6])
		return dt.date() if remove_time else dt
	except: return None

def get_datetime(string=False, dt=False):
	d = datetime.now()
	if dt: return d
	if string: return d.strftime('%Y-%m-%d')
	return datetime.date(d)

def get_current_timestamp():
	return int(time.time())
	
def adjust_premiered_date(orig_date, adjust_hours):
	if not orig_date: return None, None
	try:
		t_struct = time.strptime(orig_date.split(' ')[0], '%Y-%m-%d')
		datetime_object = datetime(t_struct.tm_year, t_struct.tm_mon, t_struct.tm_mday, 20)
		adjusted_datetime = datetime_object + timedelta(hours=adjust_hours)
		adjusted_string = '%04d-%02d-%02d' % (adjusted_datetime.year, adjusted_datetime.month, adjusted_datetime.day)
		return adjusted_datetime.date(), adjusted_string
	except: return None, None

def make_day(today, date, date_format='%Y-%m-%d', use_words=True):
	if use_words:
		day_diff = (date - today).days
		relative_days = {-1: 'YESTERDAY', 0: 'TODAY', 1: 'TOMORROW'}
		if day_diff in relative_days: return relative_days[day_diff]
		if 1 < day_diff < 7: return date.strftime('%A').upper()
	try: return date.strftime(date_format)
	except ValueError: return date.strftime('%Y-%m-%d')

def subtract_dates(date1, date2):
	try:
		d1 = date1.date() if hasattr(date1, 'hour') else date1
		d2 = date2.date() if hasattr(date2, 'hour') else date2
		return (d1 - d2).days
	except: return 0


def datetime_workaround(data, str_format):
	try: return datetime.strptime(data, str_format)
	except Exception: return datetime(*time.strptime(data, str_format)[:6])

def date_difference(current_date, compare_date, difference_tolerance, allow_postive_difference=False):
	try:
		difference = subtract_dates(current_date, compare_date)
		if not allow_postive_difference and difference > 0: return False
		else: difference = abs(difference)
		if difference > difference_tolerance: return False
		return True
	except: return True
def date_difference(current_date, compare_date, difference_tolerance, allow_positive_difference=False):
	try:
		difference = subtract_dates(current_date, compare_date)
		if not allow_positive_difference and difference > 0: return False
		if abs(difference) > difference_tolerance: return False
		return True
	except: return True

def calculate_age(born, str_format, died=None):
	""" born and died are str objects e.g. '1972-05-28' """
	try:
		b_struct = time.strptime(born, str_format)
		if died:
			d_struct = time.strptime(died, str_format)
			today_year, today_month, today_day = d_struct.tm_year, d_struct.tm_mon, d_struct.tm_mday
		else:
			today = date.today()
			today_year, today_month, today_day = today.year, today.month, today.day
		has_not_had_birthday = (today_month, today_day) < (b_struct.tm_mon, b_struct.tm_mday)
		return today_year - b_struct.tm_year - has_not_had_birthday
		
	except: return 0

def clean_file_name(s, use_encoding=False, use_blanks=True):
	if not s: return ''
	try:
		s = str(s)
		s = html.unescape(s)
		extra_hex_replacements = {"%2E": ".", "&frac12;": "%BD", "&#xBD;": "%BD", "&#xB3;": "%B3", "&#xB0;": "%B0", "&#xB7;": ".", "\xe2\x80\x99": ""}
		for k, v in extra_hex_replacements.items():
			if k in s: s = s.replace(k, v)
		mapping = {}
		if use_encoding: mapping.update({'"': '%22', '*': '%2A', '/': '%2F', ':': ',', '<': '%3C', '>': '%3E', '?': '%3F', '\\': '%5C', '|': '%7C'})
		if use_blanks: mapping.update({'"': ' ', '/': ' ', ':': '', '<': ' ', '>': ' ', '?': ' ', '\\': ' ', '|': ' ', '%BD;': ' ', '%B3;': ' ', '%B0;': ' ',
										"'": "", ' - ': ' ', '.': ' ', '!': '', ';': '', ',': ''})
		for original, replacement in mapping.items():
			if original in s: s = s.replace(original, replacement)
		return s.strip()
	except: return s

def normalize(txt):
	if not txt: return ''
	return ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn')

def clean_text_markup(text):
	if not text: return ''
	if '<br' in text: text = text.replace('<br/><br/>', '\n').replace('<br/>', '\n').replace('<br>', '\n')
	text = replace_html_codes(text)
	if '<' in text and '>' in text:
		chunks = text.split('<')
		text = chunks[0] + ''.join(chunk.split('>', 1)[-1] for chunk in chunks[1:] if '>' in chunk)
	return normalize(text).strip()

def replace_html_codes(txt):
	if not txt: return ''
	txt = unescape(txt)
	replacements = {"<ul>": "\n", "</ul>": "\n", "<li>": "\n* ", "</li>": "", "<br/><br/>": "\n", "&quot;": '"', "&amp;": "&", "[spoiler]": "", "[/spoiler]": ""}
	for original, replacement in replacements.items():
		if original in txt: txt = txt.replace(original, replacement)
	return txt

def gen_md5(value):
	import hashlib
	try:
		md5_hash = hashlib.md5()
		md5_hash.update(str(value).encode('utf-8'))
		return md5_hash.hexdigest()
	except: return None

def gen_file_hash(file):
	import hashlib
	try:
		md5_hash = hashlib.md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except: pass

def extract_json_object(raw_text):
	import json
	try:
		start = raw_text.find("{")
		end = raw_text.rfind("}")
		if start == -1 or end == -1 or end <= start: return {}
		json_str = raw_text[start:end + 1]
		return json.loads(json_str)
	except: return {}

def sec2time(sec, n_msec=3):
	""" Convert seconds to 'D days, HH:MM:SS.FFF' """
	if isinstance(sec, (list, tuple)): return [sec2time(s, n_msec) for s in sec]
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	d, h = divmod(h, 24)
	if n_msec > 0: time_str = ('%02d:%02d:%0' + str(n_msec + 3) + '.' + str(n_msec) + 'f') % (h, m, s)
	else: time_str = "%02d:%02d:%02d" % (h, m, int(s))
	if d == 0: return time_str
	return '%d days, %s' % (d, time_str)

def released_key(item):
	return item.get('released') or item.get('first_aired') or '2050-01-01'

def title_key(title):
	if not title: return ''
	for article in ['the ', 'a ', 'an ']:
		if title.lower().startswith(article): return title[len(article):]
	return title

def sort_for_article(_list, _key):
	try: _list.sort(key=lambda k: title_key(k.get(_key)))
	except: pass
	return _list

def paginate_list(item_list, page, limit=20, paginate_start=0):
	if not item_list: return [], 0
	if paginate_start: item_list = item_list[paginate_start:]
	total_pages = -(-len(item_list) // limit)
	if page < 1 or page > total_pages: return [], total_pages
	start_idx = (page - 1) * limit
	end_idx = start_idx + limit
	return item_list[start_idx:end_idx], total_pages

def unzip(zip_location, destination_location, destination_check, show_busy=True):
	from zipfile import ZipFile
	from modules.kodi_utils import show_busy_dialog, hide_busy_dialog, path_exists
	if show_busy: show_busy_dialog()
	try:
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): status = True
		else: status = False
	except: status = False
	if show_busy: hide_busy_dialog()
	return status

def make_qrcode(url):
	if url == None: return
	import segno
	from os import path
	from modules.kodi_utils import addon_profile
	try:
		art_path = path.join(addon_profile(), 'qr.png')
		qrcode = segno.make(url, micro=False)
		qrcode.save(art_path, scale=20)
	except: return
	return art_path

def make_tinyurl(url):
	import requests
	short_url = ''
	try:
		tiny_url = 'http://tinyurl.com/api-create.php'
		response = requests.get(tiny_url, params={'url': url})
		status = response.status_code
		if status == 200:
			short_url = response.text
		else: pass
	except: pass
	return short_url

def copy2clip(txt):
	if sys.platform == 'win32':
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.replace('&', '^&').strip() + '|clip'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == 'darwin':
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.strip() + '|pbcopy'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == 'linux':
		try:
			from subprocess import Popen, PIPE
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except: return
