# -*- coding: utf-8 -*-
import json
import uuid
from caches.base_cache import connect_database, get_timestamp
from modules.fen_online_utils import personal_lists_sync
from modules.settings import fen_online_user_active
# from modules.kodi_utils import logger

class PersonalListsCache:
	@personal_lists_sync('personal_lists_create')
	def make_list(self, list_name, sort_order):
		try:
			time_stamp = get_timestamp()
			list_id = str(uuid.uuid4())
			contents = json.dumps([])
			total = 0
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('INSERT OR REPLACE INTO personal_lists (id, name, contents, total, created, sort_order, updated) VALUES (?, ?, ?, ?, ?, ?, ?)',
						(list_id, list_name, contents, total, time_stamp, sort_order, time_stamp))
			return {'list_id': list_id, 'name': list_name, 'contents': contents, 'total': total, 'created': time_stamp, 'sort_order': sort_order, 'updated_time': time_stamp}
		except: return {}

	@personal_lists_sync('personal_lists_delete')
	def delete_list(self, list_id):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('DELETE FROM personal_lists WHERE id=?', (list_id,))
			dbcon.execute('VACUUM')
			return (list_id,)
		except: return False

	@personal_lists_sync('personal_list_clear_contents')
	def delete_list_contents(self, list_id):
		try:
			updated_time = get_timestamp()
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET contents=?, total=? WHERE id=?', (json.dumps([]), '0', list_id))
			return (list_id, updated_time)
		except: return False

	@personal_lists_sync('personal_lists_update_single_detail')
	def update_single_detail(self, set_prop, new_value, list_id):
		try:
			updated_time = get_timestamp()
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET %s=?, updated=? WHERE id=?' % set_prop, (new_value, updated_time, list_id))
			return (list_id, set_prop, new_value, updated_time)
		except: return False

	@personal_lists_sync('personal_lists_add_remove_item')
	def add_remove_list_item(self, list_id, action, new_contents):
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_id, dbcon=dbcon)
			updated_time = get_timestamp()
			if action == 'add':
				if [str(i['media_id']) for i in contents if str(new_contents['media_id']) == str(i['media_id'])]: return 'Item Already in List'
				contents.append(new_contents)
			else:
				if not [str(i['media_id']) for i in contents if str(new_contents) == str(i['media_id'])]: return 'Item Not in List'
				contents = [i for i in contents if not str(i['media_id']) == str(new_contents)]
			
			total = len(contents)
			contents = json.dumps(contents)
			command = 'UPDATE personal_lists SET contents=?, total=?, updated=? WHERE id=?'
			dbcon.execute(command, (contents, total, updated_time, list_id))
			return (list_id, contents, total, updated_time)
		except: return 'Error'

	def get_lists(self):
		try:
			dbcon = connect_database('personal_lists_db')
			all_lists = dbcon.execute('SELECT id, name, total, created, sort_order, updated FROM personal_lists').fetchall()
			return [{'list_id': str(i[0]), 'name': str(i[1]), 'total': i[2], 'created_at': i[3], 'sort_order': i[4], 'updated': i[5]} for i in all_lists]
		except: return []

	def get_list(self, list_id, dbcon=None):
		content = []
		try:
			if not dbcon: dbcon = connect_database('personal_lists_db')
			content = json.loads(dbcon.execute('SELECT contents FROM personal_lists WHERE id=?', (list_id,)).fetchone()[0])
		except: pass
		return content

personal_lists_cache = PersonalListsCache()
