# -*- coding: utf-8 -*-
import json
import random
import string
# import requests
from caches.base_cache import get_timestamp
from caches.settings_cache import get_setting, set_setting
from modules.utils import chunks
from modules import kodi_utils
# logger = kodi_utils.logger

fen_online_url = 'https://fen-history-default-rtdb.firebaseio.com/'
key_test = (None, 'empty_setting', '')

def make_call(method, url, session=None, data=None, timeout=10, show_busy=False):
	if show_busy: kodi_utils.show_busy_dialog()
	if not session:
		session = kodi_utils.make_session()
		close_session = True
	else: close_session = False
	try: response = session.request(method=method.upper(), url=url, json=data, timeout=timeout)
	except Exception as e:
		kodi_utils.logger('make_call Error', str(e))
		response = None
	if close_session: session.close()
	if show_busy: kodi_utils.hide_busy_dialog()
	return response

def personal_lists_update_info(list_id, user_code, status, updated_time, session=None):
	if not session:
		session = kodi_utils.make_session()
		close_session = True
	else: close_session = False
	try:
		payload = {list_id: {'status': status, 'updated': updated_time}}
		url = '%s/users/%s/personal_lists/updated_info.json' % (fen_online_url, user_code)
		response = make_call('PATCH', url, session=session, data=payload)
	except Exception as e:
		response = None
		kodi_utils.logger('error personal_lists_update_info', str(e))
	if close_session: session.close()
	return response.status_code == 200 if response else False

def build_key(media_type, media_id, season, episode):
	media_id = str(media_id).replace('.', '_').replace('/', '_')
	if media_type == 'movie': return '%s_%s' % (media_type, media_id)
	else: return '%s_%s_%s_%s' % (media_type, media_id, season, episode)

def access_user_key():
	import time
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return kodi_utils.ok_dialog('Fen Online Sync', 'No User Code is Available')
	expires_in = 20
	start, time_passed = time.time(), 0
	content = 'Current User Code:[CR][B]%s[/B]' % user_code
	progressDialog = kodi_utils.progress_dialog('Fen Online Sync', kodi_utils.get_icon('firebase'))
	progressDialog.update(content, 100)
	while not progressDialog.iscanceled() and time_passed < expires_in:
		time_passed = time.time() - start
		progress = int(100 * (expires_in - time_passed) / float(expires_in))
		progress = max(0, min(100, progress))
		progressDialog.update(content, progress)
		kodi_utils.sleep(1000)
	try: progressDialog.close()
	except: pass
	return

def create_profile():
	max_attempts = 3
	assign_own_key = kodi_utils.confirm_dialog(heading='Fen Online Sync',
									text='You need a 6-character User Key[CR]Do you want to assign it yourself or allow Fen to assign a random string?',
									ok_label='Assign', cancel_label='Random', default_control=11)
	if assign_own_key is None: return
	if assign_own_key:
		for attempts in range(1, max_attempts + 1):
			remaining = max_attempts - attempts
			user_code = kodi_utils.kodi_dialog().input('Enter your 6-character User Code')
			if user_code in (None, ''): return False
			user_code = user_code.upper()
			if len(user_code) != 6 or not user_code.isalnum():
				if remaining == 0: return
				if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
										'Use exactly 6 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
										ok_label='Retry', cancel_label='Cancel', default_control=10): return
			else: break
	else: user_code = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
	write_key = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(24))
	session = kodi_utils.make_session()
	try:
		response = make_call('GET', '%s/users/%s.json' % (fen_online_url, user_code), session=session, show_busy=True)
		if response.status_code == 200:
			if response.json() is None:
				response = make_call('PUT', '%s/users/%s.json' % (fen_online_url, user_code), session=session, data={'write_key': write_key}, show_busy=True)
				if response.status_code == 200:
					set_setting('fen_online.user_code', user_code)
					set_setting('fen_online.write_key', write_key)
					set_setting('fen_online.last_sync', str(get_timestamp()))
					set_setting('watched_indicators', '1')
					kodi_utils.hide_busy_dialog()
					kodi_utils.ok_dialog('Sync Key Generation', ('Success![CR]Your new User Code is [B]%s[/B]'
									'[CR]You need this key for access, so keep it safe[CR]This key cannot be recovered if lost' % user_code))
					watched_full_push_sync()
					personal_lists_full_push()
			elif assign_own_key:
				if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text='[B]%s[/B] key is already taken[CR][CR]Try a different key?' % user_code): return
	except: pass
	session.close()

def connect_device():
	if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text=('Connecting Fen to a current Fen Online Account will mean that your local data for Personal Lists '
		'will be overwritten with the data from the Fen Online account. This includes if there is no Personal List data currently online. Consider this before continuing'),
		ok_label='Continue', cancel_label='Cancel', default_control=11): return
	user_code = kodi_utils.kodi_dialog().input('Enter your 6-character User Code')
	if user_code in (None, ''): return
	user_code = user_code.upper()
	if len(user_code) != 6 or not user_code.isalnum():
		if not kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Please enter your 6-character key', ok_label='Retry', cancel_label='Cancel', default_control=10): return
		return connect_device()
	try:
		response = make_call('GET', '%s/users/%s.json' % (fen_online_url, user_code), show_busy=True)
		if response.status_code == 200:
			data = response.json()
			if 'write_key' in data:
				set_setting('fen_online.user_code', user_code)
				set_setting('fen_online.write_key', data['write_key'])
				set_setting('fen_online.last_sync', str(get_timestamp()))
				set_setting('watched_indicators', '1')
				sync_success = watched_full_pull_sync()
				sync_success = personal_lists_full_pull()
				if sync_success: kodi_utils.ok_dialog('Fen Online Sync', 'Success![CR]This device is connected to User Code [B]%s[/B]' % user_code)
				else: kodi_utils.ok_dialog('Fen Online Sync', 'Invalid code or profile does not exist')
		return True
	except Exception as e:
		kodi_utils.ok_dialog('Fen Online Sync', 'Error Connecting Device:[CR][CR]%s' % str(e))
		kodi_utils.logger('error connect_device', str(e))
	return False

def revoke_account():
	if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Remove Authorization for this Device?', ok_label='Yes', cancel_label='No', default_control=10):
		set_setting('fen_online.user_code', 'empty_setting')
		set_setting('fen_online.write_key', 'empty_setting')
		set_setting('fen_online.last_sync', '0')
		set_setting('watched_indicators', '0')

def delete_account():
	user_code, write_key = get_setting('fen.fen_online.user_code'), get_setting('fen.fen_online.write_key')
	if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='Delete this account: [B]%s[/B][CR]and all data?' % user_code, ok_label='Yes', cancel_label='No', default_control=11):
		if kodi_utils.confirm_dialog(heading='Fen Online Sync', text='[COLOR red][B]CAUTION!![/B][/COLOR][CR][CR]Are you sure?[CR][CR]All online data will be forever deleted',
						ok_label='Yes', cancel_label='No', default_control=11):
			if user_code in key_test or write_key in key_test: return kodi_utils.ok_dialog('Fen Online Sync', 'There was an error removing account[CR][CR]Please contact dev directly')
			text = ''
			try:
				response = make_call('DELETE', '%s/users/%s.json' % (fen_online_url, user_code), show_busy=True)
				if response.status_code == 200:
					text = 'Successfully deleted account and all associated sync data'
					set_setting('fen_online.user_code', 'empty_setting')
					set_setting('fen_online.write_key', 'empty_setting')
					set_setting('fen_online.last_sync', '0')
					set_setting('watched_indicators', '0')
				else: text = 'Deletion failed: %s: %s' % (response.status_code, response.text)
			except Exception as e: text = 'Deletion failed: %s' % str(e)
			if text: kodi_utils.ok_dialog('Fen Online Sync', text)

def watched_status_mark(media_type, media_id, action, title, last_played, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	item_key = build_key(media_type, media_id, season, episode)
	payload = {'media_type': media_type, 'media_id': media_id, 'last_updated': last_updated}
	if action == 'mark_as_watched': payload.update({'title': title, 'last_played': last_played})
	else: payload['deleted'] = True
	if media_type == 'episode': payload.update({'season': season, 'episode': episode})
	try:
		response = make_call('PUT', '%s/users/%s/watched/%s.json' % (fen_online_url, user_code, item_key), data=payload)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error watched_status_mark', str(e))
	return False

def set_bookmark(media_type, media_id, resume_point, curr_time, last_played, title, last_updated, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	item_key = build_key(media_type, media_id, season, episode)
	payload = {'media_type': media_type, 'media_id': media_id, 'season': season, 'episode': episode, 'title': title, 'resume_point': resume_point,
				'curr_time': curr_time, 'last_played': last_played, 'last_updated': last_updated}
	try:
		response = make_call('PUT', '%s/users/%s/progress/%s.json' % (fen_online_url, user_code, item_key), data=payload)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error set_bookmark', str(e))
	return False

def erase_bookmark(media_type, media_id, season='', episode=''):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	item_key = build_key(media_type, media_id, season, episode)
	payload = {'media_type': media_type, 'media_id': media_id, 'deleted': True, 'last_updated': last_updated}
	if media_type == 'episode': payload.update({'season': season, 'episode': episode})
	try:
		response = make_call('PUT', '%s/users/%s/progress/%s.json' % (fen_online_url, user_code, item_key), data=payload)
		if response.status_code == 200: return True
	except Exception as e: kodi_utils.logger('error erase_bookmark', str(e))
	return False

def watched_sync_many(table_name, action, media_to_sync, chunk_limit=100):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	last_updated = get_timestamp()
	success = True
	try:
		for chunk in chunks(media_to_sync, chunk_limit):
			payload = {}
			for ep in chunk:
				media_type, media_id, season, episode = ep[0], ep[1], ep[2], ep[3]
				item_key = build_key(media_type, media_id, season, episode)
				payload[item_key] = {'media_type': media_type, 'media_id': media_id, 'season': season, 'episode': episode}
				if action in ('mark_as_watched', 'add'): payload[item_key].update({'last_played': ep[4], 'title': ep[5], 'last_updated': ep[6]})
				else: payload[item_key].update({'deleted': True, 'last_updated': last_updated})
			try:
				response = make_call('PATCH', '%s/users/%s/%s.json' % (fen_online_url, user_code, table_name), data=payload, timeout=20)
				if response.status_code != 200: success = False
			except: success = False
	except Exception as e: kodi_utils.logger('error watched_sync_many', str(e))
	return success

def watched_full_pull_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	try:
		response = make_call('GET', '%s/users/%s.json' % (fen_online_url, user_code), timeout=20)
		if response.status_code != 200: return None
		data = response.json()
	except: return None
	if not data: data = {}
	try:
		dbcon = watched_status.get_database()
		dbcon.execute('DELETE FROM progress')
		dbcon.execute('DELETE FROM watched')
		dbcon.execute('VACUUM')
	except: return kodi_utils.notification('Error resetting local sync storage')
	progress = data.get('progress', {})
	progress_deletes = []
	for _, item in progress.items():
		if not isinstance(item, dict): continue
		tmdb_id = item.get('media_id') or item.get('tmdb_id')
		if item.get('deleted') in (True, 'True', 'true'): progress_deletes.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', '')))
		else: watched_status.set_bookmark(item, no_sync=True)
	if progress_deletes: watched_status.batch_erase_bookmark(progress_deletes, action='clear', no_sync=True)
	watched = data.get('watched', {})
	watched_inserts, watched_deletes = [], []
	for _, item in watched.items():
		if not isinstance(item, dict): continue
		tmdb_id = item.get('media_id') or item.get('tmdb_id')
		if item.get('deleted') in (True, 'True', 'true'): watched_deletes.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', '')))
		else: watched_inserts.append((item.get('media_type'), tmdb_id, item.get('season', ''), item.get('episode', ''),
									item.get('last_played') or watched_status.get_last_played_value(), item.get('title', 'Unknown'),
									item.get('last_updated') or get_timestamp()))
	if watched_inserts: watched_status.batch_watched_status_mark(watched_inserts, action='mark_as_watched', no_sync=True)
	if watched_deletes: watched_status.batch_watched_status_mark(watched_deletes, action='mark_as_unwatched', no_sync=True)
	return True

def watched_full_push_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	dbcon = watched_status.get_database()
	progress_payload, watched_payload = {}, {}
	try:
		cursor = dbcon.execute('SELECT db_type, media_id, season, episode, resume_point, curr_time, last_played, title, last_updated FROM progress')
		for row in cursor.fetchall():
			_key = build_key(row[0], row[1], row[2], row[3])
			progress_payload[_key] = {'media_type': row[0], 'media_id': row[1], 'season': row[2] or '', 'episode': row[3] or '',
										'resume_point': float(row[4]) if row[4] else 0.0, 'curr_time': float(row[5]) if row[5] else 0.0,
										'last_played': row[6] or '', 'title': row[7] or 'Unknown', 'last_updated': int(row[8]) if row[8] else 0}
		cursor = dbcon.execute('SELECT db_type, media_id, season, episode, last_played, title, last_updated FROM watched')
		for row in cursor.fetchall():
			_key = build_key(row[0], row[1], row[2], row[3])
			watched_payload[_key] = {'media_type': row[0], 'media_id': row[1], 'season': row[2] or '', 'episode': row[3] or '',
									'last_played': row[4] or '', 'title': row[5] or 'Unknown', 'last_updated': int(row[6]) if row[6] else 0}
		if not any([watched_payload, progress_payload]): return
	except Exception as e: return kodi_utils.logger('error watched_full_push_sync extraction', str(e))
	try: response = make_call('PATCH', '%s/users/%s.json' % (fen_online_url, user_code), data={'progress': progress_payload, 'watched': watched_payload}, timeout=20)
	except Exception as e: kodi_utils.logger('error watched_full_push_sync network', str(e))

def watched_regular_sync():
	from modules import watched_status
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return 'Skipping Sync No User Code'
	try: last_sync_time = int(get_setting('fen.fen_online.last_sync', '0'))
	except: last_sync_time = 0
	current_sync_time = get_timestamp()
	has_changes = False
	try:
		for table_name in ['progress', 'watched']:
			try:
				response = make_call('GET', '%s/users/%s/%s.json?orderBy="last_updated"&startAt=%s' % (fen_online_url, user_code, table_name, last_sync_time + 1), timeout=20)
				if response.status_code != 200: continue
				data = response.json()
			except Exception as e:
				kodi_utils.logger('error watched_regular_sync network %s' % table_name, str(e))
				continue
			if not data: continue
			has_changes, inserts, deletes = True, [], []
			for _, item in data.items():
				if not isinstance(item, dict): continue
				media_type = item.get('media_type')
				tmdb_id = item.get('media_id') or item.get('tmdb_id')
				season = item.get('season', '')
				episode = item.get('episode', '')
				if item.get('deleted') in (True, 'True', 'true'): deletes.append((media_type, tmdb_id, season, episode))
				else:
					if table_name == 'progress': watched_status.set_bookmark(item, no_sync=True)
					else: inserts.append((media_type, tmdb_id, season, episode, item.get('last_played') or watched_status.get_last_played_value(),
											item.get('title', 'Unknown'),item.get('last_updated') or current_sync_time))
			if table_name == 'progress' and deletes: watched_status.batch_erase_bookmark(deletes, action='clear', no_sync=True)
			elif table_name == 'watched':
				if inserts: watched_status.batch_watched_status_mark(inserts, action='mark_as_watched', no_sync=True)
				if deletes: watched_status.batch_watched_status_mark(deletes, action='mark_as_unwatched', no_sync=True)
	except Exception as e: return 'Failed!! Error: %s' % str(e)
	return 'Success! Watched History Synced' if has_changes else 'Success! No Watched History Sync Needed'

def watched_purge_old_entries(max_hours=168):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	cutoff_timestamp = get_timestamp(offset=-max_hours)
	session = kodi_utils.make_session()
	for table_name in ['watched', 'progress']:
		try:
			response = make_call('GET', '%s/users/%s/%s.json?orderBy="last_updated"&endAt=%s' % (fen_online_url, user_code, table_name, cutoff_timestamp), session=session, timeout=20)
			if response.status_code != 200: continue
			data = response.json()
			if not isinstance(data, dict): continue
			payload = {key: None for key, val in data.items() if isinstance(val, dict) and val.get('deleted') is True}
			if not payload: continue
			patch_url = '%s/users/%s/%s.json' % (fen_online_url, user_code, table_name)
			response = make_call('PATCH', patch_url, session=session, data=payload, timeout=20)
		except: pass
	session.close()

def personal_lists_full_pull():
	from caches.base_cache import connect_database
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	response = make_call('GET', '%s/users/%s/personal_lists.json' % (fen_online_url, user_code))
	if response.status_code != 200: return None
	data = response.json()
	if not data: data = {}
	try:
		dbcon = connect_database('personal_lists_db')
		dbcon.execute('DELETE FROM personal_lists')
		dbcon.execute('VACUUM')
	except: return kodi_utils.notification('Error resetting personal lists storage')
	lists_inserts = []
	for _, item in data.items():
		if 'contents' in item:
			lists_inserts.append((item['id'], item['name'], item['contents'], item['total'], item['created'], item['sort_order'], item['updated']))
	if lists_inserts: dbcon.executemany('INSERT OR REPLACE INTO personal_lists (id, name, contents, total, created, sort_order, updated) VALUES (?, ?, ?, ?, ?, ?, ?)', lists_inserts)
	return True

def personal_lists_full_push():
	import sqlite3
	from caches.base_cache import connect_database
	dbcon = connect_database('personal_lists_db')
	dbcon.row_factory = sqlite3.Row
	all_lists = dbcon.execute('SELECT id, name, contents, total, created, sort_order, updated FROM personal_lists').fetchall()
	all_lists = [dict(row) for row in all_lists]
	updated_info, payload = {}, {}
	for _list in all_lists:
		list_id, updated = _list['id'], _list['updated']
		payload[list_id] = _list
		updated_info[list_id] = {'status': 'active', 'updated': updated}
	payload['updated_info'] = updated_info
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return 'Skipping Sync No User Code'
	try: response = make_call('PATCH', '%s/users/%s.json' % (fen_online_url, user_code), data={'personal_lists': payload})
	except Exception as e: kodi_utils.logger('error personal_lists_full_push network', str(e))

def personal_lists_create(list_id, name, contents, total, created, sort_order, updated_time):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	session = kodi_utils.make_session()
	try:
		payload = {'list_id': list_id, 'name': name, 'contents': contents, 'total': total, 'created': created, 'sort_order': sort_order, 'updated': updated_time}
		response = make_call('PUT', '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session, data=payload)
		if response.status_code != 200: return None
		personal_lists_update_info(list_id, user_code, 'active', updated_time, session=session)
	except Exception as e: kodi_utils.logger('error personal_lists_create', str(e))
	session.close()
	return True

def personal_lists_delete(list_id):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	session = kodi_utils.make_session()
	try:
		response = make_call('DELETE', '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session)
		if response.status_code != 200: return None
		personal_lists_update_info(list_id, user_code, 'deleted', get_timestamp(), session=session)
	except Exception as e: kodi_utils.logger('error personal_lists_delete', str(e))

def personal_list_clear_contents(list_id, updated_time):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	session = kodi_utils.make_session()
	try:
		payload = {'contents': '[]', 'total': 0, 'updated': updated_time}
		response = make_call('PATCH', '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session, data=payload)
		if response.status_code != 200: return None
		personal_lists_update_info(list_id, user_code, 'active', updated_time, session=session)
	except Exception as e: kodi_utils.logger('error personal_list_clear_contents', str(e))
	session.close()
	return True

def personal_lists_update_single_detail(list_id, set_prop, new_value, updated_time):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	session = kodi_utils.make_session()
	try:
		payload = {set_prop: new_value, 'updated': updated_time}
		response = make_call('PATCH', '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session, data=payload)
		if response.status_code != 200: return None
		personal_lists_update_info(list_id, user_code, 'active', updated_time, session=session)
	except Exception as e: kodi_utils.logger('error personal_lists_update_detail', str(e))
	session.close()
	return True

def personal_lists_add_remove_item(list_id, contents, total, updated_time):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return False
	session = kodi_utils.make_session()
	try:
		payload = {'contents': contents, 'total': total, 'updated': updated_time}
		response = make_call('PATCH', '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session, data=payload)
		if response.status_code != 200: return None
		personal_lists_update_info(list_id, user_code, 'active', updated_time, session=session)
	except Exception as e: kodi_utils.logger('error personal_list_items_update', str(e))
	session.close()

def personal_lists_regular_sync():
	import sqlite3
	from caches.base_cache import connect_database
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return
	session = kodi_utils.make_session()
	response = make_call('GET', '%s/users/%s/personal_lists/updated_info.json' % (fen_online_url, user_code), session=session)
	if response.status_code != 200 or not response.json():
		session.close()
		return
	updated_info = response.json()
	dbcon = connect_database('personal_lists_db')
	dbcon.row_factory = sqlite3.Row
	local_rows = dbcon.execute('SELECT id, name, contents, total, created, sort_order, updated FROM personal_lists').fetchall()
	local_lists = {row['id']: dict(row) for row in local_rows}
	modified_lists = []
	try:
		for list_id, data in updated_info.items():
			status = data.get('status', 'active')
			updated = int(data.get('updated', 0))
			local_list = local_lists.get(list_id)
			local_updated = int(local_list['updated']) if local_list else 0
			if updated >= local_updated:
				if status == 'deleted':
					if local_list: 
						dbcon.execute('DELETE FROM personal_lists WHERE id=?', (list_id,))
						modified_lists.append(list_id)
				elif status == 'active' and updated > local_updated:
					response = make_call('GET',  '%s/users/%s/personal_lists/%s.json' % (fen_online_url, user_code, list_id), session=session)
					if response.status_code == 200 and response.json():
						data = response.json()
						dbcon.execute('INSERT OR REPLACE INTO personal_lists (id, name, contents, total, created, sort_order, updated) VALUES (?, ?, ?, ?, ?, ?, ?)',
							(list_id, data['name'], data['contents'], data['total'], data['created'], data['sort_order'], data['updated']))
						modified_lists.append(list_id)
			elif local_updated > updated and status == 'active':
				personal_lists_create(list_id, local_list['name'], local_list['contents'], local_list['total'], local_list['created'], local_list['sort_order'], local_list['updated'])
				modified_lists.append(list_id)
		for list_id in local_lists.keys():
			if list_id not in updated_info: 
				dbcon.execute('DELETE FROM personal_lists WHERE id=?', (list_id,))
				modified_lists.append(list_id)
		text = 'Success! Personal Lists Synced' if modified_lists else 'Success! No Personal Lists Sync Needed'
	except Exception as e: text = 'Failed!! Error: %s' % str(e)
	dbcon.execute('VACUUM')
	session.close()
	return text

def personal_lists_purge_old_entries(max_hours=168):
	user_code = get_setting('fen.fen_online.user_code')
	if user_code in key_test: return
	session = kodi_utils.make_session()
	cutoff_timestamp = get_timestamp(offset=-max_hours)
	response = make_call('GET', '%s/users/%s/personal_lists/updated_info.json' % (fen_online_url, user_code), session=session)
	if response.status_code != 200 or not response.json():
		session.close()
		return
	updated_info = response.json()
	payload = {}
	for list_id, data in updated_info.items():
		if data.get('status') == 'deleted':
			if int(data.get('updated', 0)) < cutoff_timestamp: payload[list_id] = None
	if payload: make_call('PATCH', '%s/users/%s/personal_lists/updated_info.json' % (fen_online_url, user_code), session=session, data=payload)
	session.close()
