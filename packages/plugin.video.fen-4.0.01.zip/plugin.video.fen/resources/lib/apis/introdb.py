# -*- coding: utf-8 -*-
from caches.introdb_cache import episode_intros_cache_object
from modules.kodi_utils import make_session
# from modules.kodi_utils import logger

session = make_session('https://api.introdb.app/')
get_url = 'https://api.introdb.app/segments?imdb_id=%s&season=%s&episode=%s'

class IntroDB:
	def get_data(self, imdb_id, season, episode):
		return episode_intros_cache_object(self._get, get_url % (imdb_id, season, episode))

	def _get(self, url):
		return session.get(url, timeout=5)

episode_intros = IntroDB()

# {"imdb_id":"tt3148266",
# "season":1,
# "episode":2,
# "intro":
# 	{"start_sec":39
# 	"end_sec":54
# 	"start_ms":39000
# 	"end_ms":54000
# 	"confidence":1
# 	"submission_count":1
# 	"updated_at":"2026-04-08T19:31:13.022Z"},
# "recap":
# 	{"start_sec":0,
# 	"end_sec":38,
# 	"start_ms":0,
# 	"end_ms":38000,
# 	"confidence":1,
# 	"submission_count":1,
# 	"updated_at":"2026-04-08T19:31:15.285Z"},
# "outro":
# 	{"start_sec":2568,
# 	"end_sec":2591,
# 	"start_ms":2568000,
# 	"end_ms":2591000,
# 	"confidence":1,
# 	"submission_count":1,
# 	"updated_at":"2026-04-08T19:31:17.782Z"}
# }

# call = 
	# from apis.introdb import episode_intros
	# result = episode_intros.get_data('tt0903747', 1, 2)
