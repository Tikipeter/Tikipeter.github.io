# -*- coding: utf-8 -*-

def get_years(start_year):
	from datetime import datetime
	current_year = datetime.now().year
	return [{'name': str(year), 'id': year} for year in range(current_year, start_year - 1, -1)]

def get_decades(start_decade):
	from datetime import datetime
	current_year = datetime.now().year
	current_decade = (current_year // 10) * 10
	return [{'name': '%ss' % decade, 'id': decade} for decade in range(current_decade, start_decade - 1, -10)]

def years_movies():
	return get_years(1900)

def years_tvshows():
	return get_years(1944)

def decades_movies():
	return get_decades(1900)

def decades_tvshows():
	return get_decades(1940)

def movie_certifications():
	return [
{'name': 'G', 'id': 'G'}, {'name': 'PG', 'id': 'PG'}, {'name': 'PG-13', 'id': 'PG-13'},
{'name': 'R', 'id': 'R'}, {'name': 'NC-17', 'id': 'NC-17'}, {'name': 'NR', 'id': 'NR'}
	]

def languages():
	return [
{'name': 'Arabic', 'id': 'ar'}, {'name': 'Bosnian', 'id': 'bs'}, {'name': 'Bulgarian', 'id': 'bg'}, {'name': 'Chinese', 'id': 'zh'}, {'name': 'Croatian', 'id': 'hr'},
{'name': 'Dutch', 'id': 'nl'}, {'name': 'English', 'id': 'en'}, {'name': 'Finnish', 'id': 'fi'}, {'name': 'French', 'id': 'fr'}, {'name': 'German', 'id': 'de'},
{'name': 'Greek', 'id': 'el'}, {'name': 'Hebrew', 'id': 'he'}, {'name': 'Hindi', 'id': 'hi'}, {'name': 'Hungarian', 'id': 'hu'}, {'name': 'Icelandic', 'id': 'is'},
{'name': 'Italian', 'id': 'it'}, {'name': 'Japanese', 'id': 'ja'}, {'name': 'Korean', 'id': 'ko'}, {'name': 'Macedonian', 'id': 'mk'}, {'name': 'Norwegian', 'id': 'no'},
{'name': 'Persian', 'id': 'fa'}, {'name': 'Polish', 'id': 'pl'}, {'name': 'Portuguese', 'id': 'pt'}, {'name': 'Punjabi', 'id': 'pa'}, {'name': 'Romanian', 'id': 'ro'},
{'name': 'Russian', 'id': 'ru'}, {'name': 'Serbian', 'id': 'sr'}, {'name': 'Slovenian', 'id': 'sl'}, {'name': 'Spanish', 'id': 'es'}, {'name': 'Swedish', 'id': 'sv'},
{'name': 'Turkish', 'id': 'tr'}, {'name': 'Ukrainian', 'id': 'uk'}, {'name': 'Vietnamese', 'id': 'vi'}
	]

def language_choices():
	return {
'None': 'None',              'Afrikaans': 'afr',            'Albanian': 'alb',             'Arabic': 'ara',
'Armenian': 'arm',           'Basque': 'baq',               'Bengali': 'ben',              'Bosnian': 'bos',
'Breton': 'bre',             'Bulgarian': 'bul',            'Burmese': 'bur',              'Catalan': 'cat',
'Chinese': 'chi',            'Croatian': 'hrv',             'Czech': 'cze',                'Danish': 'dan',
'Dutch': 'dut',              'English': 'eng',              'Esperanto': 'epo',            'Estonian': 'est',
'Finnish': 'fin',            'French': 'fre',               'Galician': 'glg',             'Georgian': 'geo',
'German': 'ger',             'Greek': 'ell',                'Hebrew': 'heb',               'Hindi': 'hin',
'Hungarian': 'hun',          'Icelandic': 'ice',            'Indonesian': 'ind',           'Italian': 'ita',
'Japanese': 'jpn',           'Kazakh': 'kaz',               'Khmer': 'khm',                'Korean': 'kor',
'Latvian': 'lav',            'Lithuanian': 'lit',           'Luxembourgish': 'ltz',        'Macedonian': 'mac',
'Malay': 'may',              'Malayalam': 'mal',            'Manipuri': 'mni',             'Mongolian': 'mon',
'Montenegrin': 'mne',        'Norwegian': 'nor',            'Occitan': 'oci',              'Persian': 'per',
'Polish': 'pol',             'Portuguese': 'por',           'Portuguese(Brazil)': 'pob',   'Romanian': 'rum',
'Russian': 'rus',            'Serbian': 'scc',              'Sinhalese': 'sin',            'Slovak': 'slo',
'Slovenian': 'slv',          'Spanish': 'spa',              'Swahili': 'swa',              'Swedish': 'swe',
'Syriac': 'syr',             'Tagalog': 'tgl',              'Tamil': 'tam',                'Telugu': 'tel',
'Thai': 'tha',               'Turkish': 'tur',              'Ukrainian': 'ukr',            'Urdu': 'urd',
'Vietnamese': 'vie'
	}

def movie_genres():
	return [
{'name': 'Action', 'id': '28', 'icon': 'genre_action'}, {'name': 'Adventure', 'id': '12', 'icon': 'genre_adventure'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Fantasy', 'id': '14', 'icon': 'genre_fantasy'},
{'name': 'History', 'id': '36', 'icon': 'genre_history'}, {'name': 'Horror', 'id': '27', 'icon': 'genre_horror'}, {'name': 'Music', 'id': '10402', 'icon': 'genre_music'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'Romance', 'id': '10749', 'icon': 'genre_romance'},
{'name': 'Science Fiction', 'id': '878', 'icon': 'genre_scifi'}, {'name': 'TV Movie', 'id': '10770', 'icon': 'genre_soap'}, {'name': 'Thriller', 'id': '53', 'icon': 'genre_thriller'},
{'name': 'War', 'id': '10752', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def tvshow_genres():
	return [
{'name': 'Action & Adventure', 'id': '10759', 'icon': 'genre_action'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Kids', 'id': '10762', 'icon': 'genre_kids'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'News', 'id': '10763', 'icon': 'genre_news'}, {'name': 'Reality', 'id': '10764', 'icon': 'genre_reality'},
{'name': 'Sci-Fi & Fantasy', 'id': '10765', 'icon': 'genre_scifi'}, {'name': 'Soap', 'id': '10766', 'icon': 'genre_soap'}, {'name': 'Talk', 'id': '10767', 'icon': 'genre_talk'},
{'name': 'War & Politics', 'id': '10768', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def movie_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'Release Date (asc)', 'id': '&sort_by=primary_release_date.asc'}, {'name': 'Release Date (desc)', 'id': '&sort_by=primary_release_date.desc'},
{'name': 'Total Revenue (asc)', 'id': '&sort_by=revenue.asc'}, {'name': 'Total Revenue (desc)', 'id': '&sort_by=revenue.desc'},
{'name': 'Title (asc)', 'id': '&sort_by=original_title.asc'}, {'name': 'Title (desc)', 'id': '&sort_by=original_title.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def tvshow_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'First Aired (asc)', 'id': '&sort_by=first_air_date.asc'}, {'name': 'First Aired (desc)', 'id': '&sort_by=first_air_date.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def discover_items():
	return {
'with_year_start': {'label': 'Year Start', 'key': 'with_year_start', 'display_key': 'with_year_start_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.gte=%s-01-01', 'url_insert_tvshow': '&first_air_date.gte=%s-01-01', 'name_value': ' | %s onwards', 'icon': 'calender'},
'with_year_end': {'label': 'Year End', 'key': 'with_year_end', 'display_key': 'with_year_end_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.lte=%s-12-31', 'url_insert_tvshow': '&first_air_date.lte=%s-12-31', 'name_value': ' | up to %s', 'icon': 'calender'},
'with_genres': {'label': 'With Genres', 'key': 'with_genres', 'display_key': 'with_genres_display', 'action': 'genres',
'url_insert': '&with_genres=%s', 'name_value': ' | %s', 'icon': 'genres'},
'without_genres': {'label': 'Without Genres', 'key': 'without_genres', 'display_key': 'without_genres_display', 'action': 'genres',
'url_insert': '&without_genres=%s', 'name_value': ' | exclude %s', 'icon': 'genres'},
'with_certification': {'label': 'Certification', 'key': 'with_certification', 'display_key': 'with_certification_display', 'action': 'certifications',
'url_insert': '&certification_country=US&certification=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_certification_and_lower': {'label': 'Certification (& lower)', 'key': 'with_certification_and_lower', 'display_key': 'with_certification_and_lower_display',
'action': 'certification_and_lowers', 'url_insert': '&certification_country=US&certification.lte=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_language': {'label': 'Language', 'key': 'with_language', 'display_key': 'with_language_display', 'action': 'languages',
'url_insert': '&with_original_language=%s', 'name_value': ' | %s', 'icon': 'languages'},	
'with_keywords': {'label': 'With Keywords', 'key': 'with_keywords', 'display_key': 'with_keywords_display', 'action': 'keywords',
'url_insert': '&with_keywords=%s', 'name_value': ' | Keywords: %s', 'icon': 'fantasy'},
'with_rating': {'label': 'Minimum Rating', 'key': 'with_rating', 'display_key': 'with_rating_display', 'action': 'ratings',
'url_insert': '&vote_average.gte=%s', 'name_value': ' | %s+', 'icon': 'most_watched'},
'with_rating_votes': {'label': 'Minimum Number of Votes', 'key': 'with_rating_votes', 'display_key': 'with_rating_votes_display', 'action': 'votes',
'url_insert': '&vote_count.gte=%s', 'name_value': ' | %s votes', 'icon': 'most_voted'},
'with_cast': {'label': 'Include Cast', 'key': 'with_cast', 'display_key': 'with_cast_display', 'action': 'casts',
'url_insert': '&with_cast=%s', 'name_value': ' | with %s', 'limited': 'movie', 'icon': 'people'},
'with_sort': {'label': 'Sort By', 'key': 'with_sort', 'display_key': 'with_sort_display', 'action': 'sort',
'url_insert': '%s', 'name_value': ' | %s', 'icon': 'lists'},
'with_released': {'label': 'Released Only', 'key': 'with_released', 'display_key': 'with_released_display', 'action': 'released',
'url_insert_movie': '&primary_release_date.lte=%s', 'url_insert_tvshow': '&include_null_first_air_dates=false&first_air_date.lte=%s', 'name_value': ' | Released Only', 'icon': 'dvd'},
'with_adult': {'label': 'Include Adult', 'key': 'with_adult', 'display_key': 'with_adult_display', 'action': 'adult',
'url_insert': '&include_adult=%s', 'name_value': ' | Include Adult', 'limited': 'movie', 'icon': 'romance'},
	}

def color_palette():
	return [
'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4', 'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC',
'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF', 'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3', 'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6',
'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC', 'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB', 'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC',
'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3', 'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4', 'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF',
'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF', 'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899', 'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF',
'FFD699FF', 'FFC299FF', 'FFAE99FF', 'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3', 'FF99FFAC', 'FF99FF99', 'FFADFF99',
'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681', 'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF', 'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81',
'FF99FF80', 'FFB3FF80', 'FFCCFF80', 'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685', 'FFFF66A4', 'FFFF66C1', 'FFFF66E0',
'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE', 'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E', 'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7',
'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF', 'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF', 'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95',
'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D', 'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE', 'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD',
'FF33FF84', 'FF32FF5C', 'FF34FF33', 'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A', 'FFFF4719', 'FFFF1919', 'FFFF1947',
'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF', 'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B', 'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000',
'FFFE0032', 'FFFF0066', 'FFFF0198', 'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF', 'FF0097FE', 'FF00CCFF', 'FF00FFFF',
'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00', 'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5', 'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6',
'FF00E6E6', 'FF00E6B7', 'FF00E78B', 'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00', 'FFCDA301', 'FFCA7B02', 'FFCC5200',
'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3', 'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00', 'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00',
'FFB34700', 'FFB32501', 'FFB30101', 'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2', 'FF0000B2', 'FF0025B4', 'FF0047B3',
'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346', 'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099', 'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99',
'FF003D98', 'FF005C99', 'FF007A99', 'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900', 'FF7A9900', 'FF2E2E2E', 'FF7F8000',
'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019', 'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B', 'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424',
'FF656600', 'FF675201', 'FF653D00', 'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069', 'FF3D0067', 'FF290066', 'FF150067',
'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766', 'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F', 'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C',
'FF0E004B', 'FF01004C', 'FF000E4B', 'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01', 'FF0F4C00', 'FF204C01', 'FF2D4C00',
'FF3E4C01', 'FF000000'
	]

def recommendations_list():
	return {
	'Current Mood & Energy': {
		'Cozy & Comforting': {
			'description': 'You want a warm blanket for the soul—low stakes, gentle humor, and maximum comfort.',
			'thematic_anchors': ['low stakes plots', 'slow-paced living', 'gentle humor', 'heartwarming slice-of-life'],
			'tonal_profile': ['cozy', 'wholesome', 'peaceful', 'charming', 'soothing'],
			'cinematic_benchmarks': ['Paddington 2 (2017)', 'Amélie (2001)', 'Ted Lasso (2020)']},
		'Tense & Thrilling': {
			'description': 'Match your internal jitteriness with a nail-biting ticking clock and high-stakes survival scenarios.',
			'thematic_anchors': ['ticking-clock scenarios', 'trapped characters', 'hostage situations', 'high suspense'],
			'tonal_profile': ['suspenseful', 'claustrophobic', 'frantic', 'anxiety-inducing'],
			'cinematic_benchmarks': ['Uncut Gems (2019)', 'Captain Phillips (2013)', 'Prisoners (2013)']},
		'Deep & Mind-Bending': {
			'description': 'Explore deeply psychological, complex, and intricate mysteries that challenge your mind.',
			'thematic_anchors': ['unreliable narrators', 'reality distortion', 'memory loss', 'philosophical puzzles'],
			'tonal_profile': ['cerebral', 'mysterious', 'complex', 'thought-provoking', 'surreal'],
			'cinematic_benchmarks': ['Inception (2010)', 'Memento (2000)', 'Dark (2017)']},
		'Dark & Gritty': {
			'description': 'Immerse yourself in a mature, visceral, crime-ridden world driven by flawed, complex characters.',
			'thematic_anchors': ['moral ambiguity', 'criminal underworlds', 'corrupt systems', 'atmospheric detective work'],
			'tonal_profile': ['gritty', 'bleak', 'visceral', 'mature', 'atmospheric'],
			'cinematic_benchmarks': ['The Batman (2022)', 'True Detective (Season 1)', 'Sicario (2015)']},
		'High-Octane Action': {
			'description': 'You want a frantic heart rate, non-stop physical stunts, and massive cinematic momentum.',
			'thematic_anchors': ['car chases', 'high-speed racing', 'massive explosions', 'stunt-heavy set pieces'],
			'tonal_profile': ['adrenaline-fueled', 'fast-paced', 'spectacular', 'relentless'],
			'cinematic_benchmarks': ['Mad Max: Fury Road (2015)', 'Mission: Impossible - Fallout (2018)', 'John Wick (2014)']}
	},
	'Genre & Atmosphere': {
		'Epic Action-Adventure': {
			'description': 'Embark on legendary, grand quests across perilous landscapes filled with high-stakes heroism.',
			'thematic_anchors': ['grand expeditions', 'lost civilizations', 'survival combat', 'heroic journeys'],
			'tonal_profile': ['epic', 'adventurous', 'thrilling', 'wondrous'],
			'cinematic_benchmarks': ['The Lord of the Rings (2001)', 'Gladiator (2000)', 'Indiana Jones (1981)']},
		'Sci-Fi & Cyberpunk': {
			'description': 'Dive into high-tech worlds, heavy futuristic world-building, and profound space opera concepts.',
			'thematic_anchors': ['interstellar travel', 'artificial intelligence', 'dystopian cities', 'neon aesthetics'],
			'tonal_profile': ['futuristic', 'visionary', 'speculative', 'neon-soaked'],
			'cinematic_benchmarks': ['Blade Runner 2049 (2017)', 'Interstellar (2014)', 'The Matrix (1999)']},
		'Mystery & Horror': {
			'description': 'Face spooky supernatural occurrences, chilling psychological terror, or slow-burning gothic mysteries.',
			'thematic_anchors': ['haunted spaces', 'unexplained phenomena', 'investigative sleuthing', 'dread-building'],
			'tonal_profile': ['spooky', 'unsettling', 'creepy', 'gothic', 'tense'],
			'cinematic_benchmarks': ['The Conjuring (2013)', 'Hereditary (2018)', 'The Invisible Man (2020)']},
		'Comedy & Satire': {
			'description': 'Switch off and laugh at brilliantly written workplace antics, sharp satires, or dark humor.',
			'thematic_anchors': ['witty banter', 'absurd situations', 'social commentary', 'eccentric ensembles'],
			'tonal_profile': ['hilarious', 'witty', 'satirical', 'playful', 'sharp'],
			'cinematic_benchmarks': ['Knives Out (2019)', 'The Wolf of Wall Street (2013)', 'Tropic Thunder (2008)']},
		'Prestige Drama': {
			'description': 'Experience emotionally resonant character studies, heavy conflicts, and powerful human relationships.',
			'thematic_anchors': ['family conflict', 'emotional trials', 'historical struggles', 'deep interpersonal dialogue'],
			'tonal_profile': ['profound', 'moving', 'dramatic', 'melancholic', 'earnest'],
			'cinematic_benchmarks': ['Succession (2018)', 'The Godfather (1972)', 'The Whale (2022)']}
	},
	'Themes & Tropes': {
	'Clever Heists & Outlaws': {
		'description': 'Intricate planning, high-stakes robberies, and slick anti-heroes executing the perfect crime.',
		'thematic_anchors': ['bank robberies', 'elaborate schemes', 'getaway drivers', 'criminal networks'],
		'tonal_profile': ['slick', 'clever', 'rebellious', 'fast-moving', 'stylish'],
		'cinematic_benchmarks': ['Baby Driver (2017)', 'Ocean\'s Eleven (2001)', 'Money Heist (2017)']},
	'Survival & Apocalypse': {
		'description': 'Characters pushed to their limits trying to endure harsh terrain, deadly viruses, or societal collapse.',
		'thematic_anchors': ['dystopian wastelands', 'viral outbreaks', 'resource scarcity', 'isolation challenges'],
		'tonal_profile': ['desperate', 'gritty', 'raw', 'suspenseful', 'visceral'],
		'cinematic_benchmarks': ['The Revenant (2015)', 'A Quiet Place (2018)', 'The Last of Us (2023)']},
	'Nostalgia & Coming of Age': {
		'description': 'The bittersweet journey of growing up, childhood friendships, and vintage settings.',
		'thematic_anchors': ['retro eras', 'youthful adventures', 'small-town bonds', 'sentimental milestones'],
		'tonal_profile': ['nostalgic', 'sentimental', 'warm', 'bittersweet', 'innocent'],
		'cinematic_benchmarks': ['Stand by Me (1986)', 'The Way Way Back (2013)', 'Stranger Things (2016)']},
	'Revenge & Retribution': {
		'description': 'Ruthless and calculated quests to settle old scores and exact vigilante justice against all odds.',
		'thematic_anchors': ['vendettas', 'lone vigilantes', 'score-settling', 'retribution runs'],
		'tonal_profile': ['ruthless', 'satisfying', 'cold', 'calculated', 'grim'],
		'cinematic_benchmarks': ['Kill Bill: Vol. 1 (2003)', 'The Punisher (2017)', 'Blue Eye Samurai (2023)']},
	'Underdogs & Triumphs': {
		'description': 'Deeply inspiring stories of individuals or teams overcoming immense odds to achieve greatness.',
		'thematic_anchors': ['sports tournaments', 'bitter rivalries', 'underdog victories', 'pursuing dreams'],
		'tonal_profile': ['motivational', 'triumphant', 'inspiring', 'passionate', 'empowering'],
		'cinematic_benchmarks': ['Whiplash (2014)', 'Warrior (2011)', 'Rocky (1976)']}
	},
'Setting & Backdrop': {
	'Deep Space Exploration': {
		'description': 'Set strictly beyond earth, exploring alien environments or navigating the loneliness of the cosmos.',
		'thematic_anchors': ['spaceships', 'alien landscapes', 'cosmic anomalies', 'astronaut survival'],
		'tonal_profile': ['vast', 'isolated', 'futuristic', 'wondrous', 'cerebral'],
		'cinematic_benchmarks': ['Interstellar (2014)', 'The Martian (2015)', 'The Expanse (2015)']},
	'Historical & Period Pieces': {
		'description': 'Step back in time through meticulously recreated historical eras, ancient empires, or wartime sagas.',
		'thematic_anchors': ['ancient battlefield tactics', 'monarchies', 'mid-century styling', 'wartime conflicts'],
		'tonal_profile': ['meticulous', 'epic', 'authentic', 'dramatic', 'grand'],
		'cinematic_benchmarks': ['Gladiator (2000)', 'Oppenheimer (2023)', 'Chernobyl (2019)']},
	'Small Town Secrets': {
		'description': 'Confined to isolated, tight-knit communities harboring hidden drama or eerie supernatural events.',
		'thematic_anchors': ['local conspiracies', 'suburban facades', 'unravelling mysteries', 'eccentric locals'],
		'tonal_profile': ['eerie', 'intimate', 'atmospheric', 'mysterious', 'insular'],
		'cinematic_benchmarks': ['Hot Fuzz (2007)', 'Super 8 (2011)', 'Twin Peaks (1990)']},
	'Neon Urban Landscapes': {
		'description': 'Sprawling, high-tech, or gritty cities drenched in neon lights, rain-slicked streets, or futuristic grit.',
		'thematic_anchors': ['cyberpunk architecture', 'megacorporations', 'urban street life', 'futuristic technology'],
		'tonal_profile': ['vibrant', 'stylized', 'neon-soaked', 'futuristic', 'gritty'],
		'cinematic_benchmarks': ['Blade Runner 2049 (2017)', 'Altered Carbon (2018)', 'Mr. Robot (2015)']},
	'Harsh Wilderness Isolation': {
		'description': 'Remote destinations like dense woods, deserts, frozen tundras, or islands where nature is the primary threat.',
		'thematic_anchors': ['remote cabins', 'extreme weather conditions', 'lost in nature', 'unyielding frontiers'],
		'tonal_profile': ['desolate', 'harsh', 'isolated', 'visceral', 'atmospheric'],
		'cinematic_benchmarks': ['127 Hours (2010)', 'Cast Away (2000)', 'Yellowjackets (2021)']}
	},
'Time Period & Era': {
	'Brand New Releases': {
		'description': 'Fresh out of the studio—released within the last 24 months with cutting-edge modern production values.',
		'thematic_anchors': ['contemporary topics', 'modern technology', 'cutting-edge visual effects'],
		'tonal_profile': ['fresh', 'relevant', 'modern', 'polished'],
		'cinematic_benchmarks': ['Dune: Part Two (2024)', 'The Bear (2022)', 'Shōgun (2024)']},
	'Modern Prestige (2010-2022)': {
		'description': 'The explosion of streaming blockbusters, elevated high-budget genres, and cinematic television masterpieces.',
		'thematic_anchors': ['complex story structures', 'cinematic scales', 'elevated genres'],
		'tonal_profile': ['polished', 'prestige', 'impactful', 'celebrated'],
		'cinematic_benchmarks': ['Parasite (2019)', 'Inception (2010)', 'Succession (2018)']},
	'Turn of Millennium (2000-2009)': {
		'description': 'Gritty character-driven reboots, early digital visual effects, and classic golden cable television anti-heroes.',
		'thematic_anchors': ['early digital age aesthetics', 'gritty reimagining', 'anti-hero popularity'],
		'tonal_profile': ['grounded', 'bold', 'pioneering', 'iconic'],
		'cinematic_benchmarks': ['The Dark Knight (2008)', 'No Country for Old Men (2007)', 'The Wire (2002)']},
	'Retro Favorites (1980-1999)': {
		'description': 'Beloved practical effects, physical sets, legendary pop culture icons, and timeless blockbusters.',
		'thematic_anchors': ['practical effects', 'vintage soundscapes', 'iconic pop culture tropes'],
		'tonal_profile': ['iconic', 'nostalgic', 'charming', 'foundational'],
		'cinematic_benchmarks': ['Pulp Fiction (1994)', 'Back to the Future (1985)', 'Friends (1994)']},
	'Golden Age Classics (Pre-1980)': {
		'description': 'Foundational cinematic masterpieces, vintage directional choices, and black-and-white hallmarks.',
		'thematic_anchors': ['classical score arrangements', 'vintage filmmaking techniques', 'foundational film tropes'],
		'tonal_profile': ['timeless', 'artistic', 'foundational', 'vintage'],
		'cinematic_benchmarks': ['The Godfather (1972)', 'Alien (1979)', 'The Twilight Zone (1959)']}
	},
	'Surprise Me!': {
		'Complete Wildcard': {
			'description': 'Surprise me with a chaotic, unpredictable mix of excellent titles across completely random genres.',
			'thematic_anchors': ['genre-fluid setups', 'unexpected narratives', 'unpredictable selections'],
			'tonal_profile': ['unpredictable', 'surprising', 'diverse', 'chaotic'],
			'cinematic_benchmarks': ['Parasite (2019)', 'Pulp Fiction (1994)', 'Fight Club (1999)']},
		'High-Scoring Hidden Gems': {
			'description': 'Unearth overlooked, rare masterpieces with high review scores but little mainstream recognition.',
			'thematic_anchors': ['indie productions', 'underappreciated scripts', 'underrated cinematic achievements'],
			'tonal_profile': ['obscure', 'artistic', 'intimate', 'revelatory'],
			'cinematic_benchmarks': ['Coherence (2013)', 'Sing Street (2016)', 'The Florida Project (2017)']},
		'Mainstream Crowd Pleasers': {
			'description': 'Give me massive, universally recognized blockbuster hits that almost everyone loves.',
			'thematic_anchors': ['massive box office hits', 'pop culture icons', 'high audience approval scores'],
			'tonal_profile': ['spectacular', 'entertaining', 'satisfying', 'accessible'],
			'cinematic_benchmarks': ['Avatar (2009)', 'Top Gun: Maverick (2022)', 'The Avengers (2012)']},
		'Award Winners & Nominees': {
			'description': 'Stream critically praised titles that won or competed for major industry awards.',
			'thematic_anchors': ['academy award winners', 'prestige acting nominations', 'festival favorites'],
			'tonal_profile': ['acclaimed', 'polished', 'masterful', 'celebrated'],
			'cinematic_benchmarks': ['Oppenheimer (2023)', 'No Country for Old Men (2007)', 'Whiplash (2014)']},
		'Cult Classics & Unique Visions': {
			'description': 'Explore highly unique concepts, bold directorial signatures, or projects with obsessive cult following bases.',
			'thematic_anchors': ['highly original concepts', 'stylized directing', 'subculture icons', 'bizarre premises'],
			'tonal_profile': ['quirky', 'bold', 'unconventional', 'stylistic', 'passionate'],
			'cinematic_benchmarks': ['The Big Lebowski (1998)', 'Donnie Darko (2001)', 'Scott Pilgrim vs. The World (2010)']}
	}
}

def recommendations_refinement_modifiers():
	#0: Balanced, 1: Hidden Gems, 2: Blockbusters, 3: Fast Paced, 4: Slow Burn
	return {
	0: '',
	1: ' CRITICAL PREFERENCE: Actively prioritize obscure, lesser-known indie projects, hidden gems, and overlooked titles. Explicitly avoid major mainstream blockbusters.',
	2: ' CRITICAL PREFERENCE: Actively prioritize massive, globally recognized blockbuster hits, box-office successes, and major cultural pop culture phenomena.',
	3: ' CRITICAL PREFERENCE: Actively prioritize fast-moving plots, high momentum, and immediate narrative progression. Explicitly avoid slow-burning or lingering pacing.',
	4: ' CRITICAL PREFERENCE: Actively prioritize slow-burning narratives, heavy atmosphere, and gradual tension-building. Explicitly avoid frantic or rushed plots.'
}

def recommendation_invalid_critical():
	return {
	'High-Octane Action': [4],
	'Tense & Thrilling': [4],
	'Cozy & Comforting': [3],
	'Golden Age Classics (Pre-1980)': [3, 2],
	'Mainstream Crowd Pleasers': [1],
	'High-Scoring Hidden Gems': [2],
	'Epic Action-Adventure': [1],
	'Sci-Fi & Cyberpunk': [1],
	'Award Winners & Nominees': [1]
}