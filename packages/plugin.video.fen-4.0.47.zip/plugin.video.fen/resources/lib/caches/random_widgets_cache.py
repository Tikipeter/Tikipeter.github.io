# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, open_db, get_timestamp
# from modules.kodi_utils import logger

class RandomWidgets(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'random_widgets_db', 'random_widgets')

	def clean_database(self):
		try:
			with open_db('random_widgets_db') as dbcon:
				dbcon.execute('DELETE from data WHERE expires <= ?', (get_timestamp(),))
				dbcon.execute('VACUUM')
			return True
		except: return False

random_widgets_cache = RandomWidgets()