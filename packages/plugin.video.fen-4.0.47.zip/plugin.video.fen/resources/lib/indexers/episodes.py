# -*- coding: utf-8 -*-
import sys
from modules.meta_lists import context_menu_defaults, episode_status
from modules import kodi_utils, settings, watched_status as ws
from modules.metadata import tvshow_meta, episodes_meta
from modules.utils import adjust_premiered_date, get_datetime, get_current_timestamp, title_key, TaskPool, paginate_list
# logger = kodi_utils.logger

def build_episode_list(params):
	def _process():
		for item in episodes_data:
			try:
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				if season_special: playcount, progress = 0, None
				else:
					playcount = ws.get_watched_status_episode(watched_info, (season, episode))
					if total_seasons: progress = ws.get_progress_status_all_episode(bookmarks, season, episode)
					else: progress = ws.get_progress_status_episode(bookmarks, episode)
				thumb, plot, duration = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot, item_get('duration')
				try: year = premiered.split('-')[0]
				except: year = show_year or '2050'
				if episode_type:
					status_label, status_highlight = episode_status_dict[episode_type]
					plot = '[COLOR %s]%s[/COLOR][CR]%s' % (status_highlight, status_label, plot)
				if not duration:
					duration = show_duration
					item['duration'] = duration
				if not episode_date or current_date < episode_date:
					display, unaired = '[COLOR red][I]%s[/I][/COLOR]' % ep_name, True
					item['title'] = display
				else: display, unaired = ep_name, False
				url = build_main_url({'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
										'episode_id': episode_id}, is_external)
				cm = [
				['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode'}))],
				['more_info', ('[B]More Info[/B]', 'RunPlugin(%s)' % build_url({'mode': 'media_info_choice', 'media_type': 'episode', 'tmdb_id': tmdb_id,
					'season': season, 'episode': episode}))],
				['options', ('[B]Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster,
					'season': season, 'episode': episode}))],
				['browse_more', ('[B]Browse More[/B]', 'RunPlugin(%s)' % build_url({'mode': 'browse_more_choice',
					'media_type': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster}))]]
				if not unaired and not season_special:
					if playcount:
						cm.append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'season': season, 'episode': episode,  'title': title}))])
					else: cm.append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'season': season, 'episode': episode,  'title': title}))])
					if progress: cm.append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode',
													'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if cm_ordered_items: cm = [i for x in cm_ordered_items for n, i in cm if x == n]
				else: cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag()
				info_tag.setMediaType('episode')
				info_tag.setTitle(display)
				info_tag.setOriginalTitle(orig_title)
				info_tag.setTvShowTitle(title)
				info_tag.setGenres(genre)
				info_tag.setPlaycount(playcount)
				info_tag.setSeason(season)
				info_tag.setEpisode(episode)
				info_tag.setPlot(plot)
				info_tag.setDuration(duration)
				info_tag.setIMDBNumber(imdb_id)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
				info_tag.setFirstAired(premiered)
				info_tag.setTvShowStatus(show_status)
				info_tag.setCountries(country)
				info_tag.setTrailer(auto_trailer)
				info_tag.setDirectors(item_get('director'))
				info_tag.setYear(int(year))
				info_tag.setRating(item_get('rating'))
				info_tag.setVotes(item_get('votes'))
				info_tag.setMpaa(mpaa)
				info_tag.setStudios(studio)
				info_tag.setWriters(item_get('writer'))
				full_cast = cast + item_get('guest_stars', [])
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
				if progress and not unaired:
					info_tag.setResumePoint(ws.get_resume_seconds(progress, duration))
					set_properties({'WatchedProgress': progress})
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
								'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo})
				set_properties({'episode_type': episode_type})
				yield (url, listitem, False)
			except: pass
	kodi_actor, make_listitem = kodi_utils.kodi_actor(), kodi_utils.make_listitem
	build_url, build_main_url = kodi_utils.build_url, kodi_utils.build_main_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	item_list = []
	append = item_list.append
	episode_status_dict = episode_status()
	adjust_hours = settings.date_offset()
	current_date = get_datetime()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	context_menu_enabled = settings.context_menu_enabled()
	context_menu_order = [i for i in settings.context_menu_order() if i in context_menu_enabled]
	cm_ordered_items = context_menu_order if context_menu_order != context_menu_defaults().split(',') else None
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), current_date)
	meta_get = meta.get
	tmdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	title, show_year, rootname, show_duration, show_status = meta_get('title'), meta_get('year') or '2050', meta_get('rootname'), meta_get('duration'), meta_get('status')
	mpaa, genre, studio, country = meta_get('mpaa'), meta_get('genre'), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	auto_trailer = meta_get('auto_trailer') or 'plugin://plugin.video.fen/?mode=default_trailer_choice&media_type=tvshow&tmdb_id=%s&imdb_id=%s' % (tmdb_id, imdb_id)
	season = params['season']
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or ''
	watched_db = ws.get_database()
	watched_info = ws.watched_info_episode(tmdb_id, watched_db)
	total_seasons = None
	episodes_data = episodes_meta(season, meta)
	bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
	try:
		season_data = meta_get('season_data')
		poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
		season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
	except: season_poster = show_poster
	category_name = 'Season %s' % season
	kodi_utils.add_items(handle, list(_process()))
	kodi_utils.set_sort_method(handle, 'episodes')
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, category_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.episodes', 'episodes', is_external)

def build_single_episode(params):
	def _get_category_name():
		try:
			cat_name = {'progress': 'In Progress Episodes','next': 'Next Episodes'}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _paginate_list(data, page_no, paginate_start):
		if paginate_enabled:
			limit = settings.page_limit_single_episodes()
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_external: paginate_start = limit
		else: total_pages = 1
		return data, total_pages, paginate_start
	def _process(_position, item):
		try:
			item_get = item.get
			meta = tvshow_meta('tmdb_id', item_get('media_id'), api_key, current_date, current_time)
			if not meta: return
			meta_get = meta.get
			cm = []
			listitem = make_listitem()
			set_properties = listitem.setProperties
			orig_season, orig_episode = item_get('season'), item_get('episode')
			unwatched = item_get('unwatched', False)
			_position = item_get('custom_order', _position)
			tmdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
			season_data = meta_get('season_data')
			episodes_data = episodes_meta(orig_season, meta)
			if not episodes_data: return
			item = {ep['episode']: ep for ep in episodes_data}.get(orig_episode)
			if not item: return
			item_get = item.get
			episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			if not episode_date or current_date < episode_date: unaired = True
			else: unaired = False
			season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			orig_title, rootname, genre = meta_get('original_title'), meta_get('rootname'), meta_get('genre')
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			try: year = premiered.split('-')[0]
			except: year = show_year or '2050'
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if rpdb_api_key:
				try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
				except: show_poster = meta_get('poster') or poster_empty
			else: show_poster = meta_get('poster') or poster_empty
			show_fanart = meta_get('fanart') or fanart_empty
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or ''
			try:
				poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
				season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
			except: season_poster = show_poster
			str_season_zfill2, str_episode_zfill2 = str(season).zfill(2), str(episode).zfill(2)
			if display_format == 0: title_str = '%s: ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s - ' % (str_season_zfill2, str_episode_zfill2)
			else: seas_ep = ''
			playcount = 0
			if list_type == 'next':
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				display = '%s%s%s%s%s' % (title_str, highlight_start, seas_ep, ep_name, highlight_end)
			else: display = '%s%s%s' % (title_str, seas_ep, ep_name)
			thumb, plot, duration = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot, item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			if episode_type:
				status_label, status_highlight = episode_status_dict[episode_type]
				plot = '[COLOR %s]%s[/COLOR][CR]%s' % (status_highlight, status_label, plot)
			bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
			progress = ws.get_progress_status_episode(bookmarks, episode)
			url = build_main_url({'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
									'episode_id': episode_id}, is_external)
			cm = [
			['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode'}))],
			['more_info', ('[B]More Info[/B]', 'RunPlugin(%s)' % build_url({'mode': 'media_info_choice', 'media_type': 'episode', 'tmdb_id': tmdb_id,
				'season': season, 'episode': episode}))],
			['options', ('[B]Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster,
				'season': season, 'episode': episode}))],
			['browse_more', ('[B]Browse More[/B]', 'RunPlugin(%s)' % build_url({'mode': 'browse_more_choice', 'media_type': 'single_episode', 'tmdb_id': tmdb_id,
				'season': season, 'poster': show_poster}))]]
			if not unaired:
				if playcount:
					cm.append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'season': season, 'episode': episode,  'title': title}))])
				else: cm.append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'season': season, 'episode': episode,  'title': title}))])
				if progress:
					cm.append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
											'season': season, 'episode': episode, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if cm_ordered_items: cm = [i for x in cm_ordered_items for n, i in cm if x == n]
			else: cm = [i[1] for i in cm]
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('episode')
			info_tag.setOriginalTitle(orig_title)
			info_tag.setTvShowTitle(title)
			info_tag.setTitle(display)
			info_tag.setGenres(genre)
			info_tag.setPlaycount(playcount)
			info_tag.setSeason(season)
			info_tag.setEpisode(episode)
			info_tag.setPlot(plot)
			info_tag.setFirstAired(premiered)
			info_tag.setDuration(duration)
			info_tag.setIMDBNumber(imdb_id)
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
			info_tag.setCountries(meta_get('country', []))
			info_tag.setTrailer(meta_get('auto_trailer') or trailer_url % (tmdb_id, imdb_id))
			info_tag.setTvShowStatus(show_status)
			info_tag.setStudios(studio)
			info_tag.setWriters(item_get('writer'))
			info_tag.setDirectors(item_get('director'))
			info_tag.setYear(int(year))
			info_tag.setRating(item_get('rating'))
			info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
			full_cast = cast + item_get('guest_stars', [])
			info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
			if progress and not unaired:
				info_tag.setResumePoint(ws.get_resume_seconds(progress, duration))
				set_properties({'WatchedProgress': progress})
			listitem.setLabel(display)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
							'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo})
			set_properties({'episode_type': episode_type})
			item_list_append({'list_items': (url, listitem, False), 'sort_order': _position})
		except: pass
	kodi_actor, make_listitem = kodi_utils.kodi_actor(), kodi_utils.make_listitem
	build_url, build_main_url = kodi_utils.build_url, kodi_utils.build_main_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	item_list = []
	item_list_append = item_list.append
	episode_status_dict = episode_status()
	display_format = settings.single_ep_display_format(is_external)
	current_date, current_time, adjust_hours = get_datetime(), get_current_timestamp(), settings.date_offset()
	api_key = settings.tmdb_api_key()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	context_menu_enabled = settings.context_menu_enabled()
	context_menu_order = [i for i in settings.context_menu_order() if i in context_menu_enabled]
	cm_ordered_items = context_menu_order if context_menu_order != context_menu_defaults().split(',') else None
	watched_db = ws.get_database()
	trailer_url = 'plugin://plugin.video.fen/?mode=default_trailer_choice&media_type=tvshow&tmdb_id=%s&imdb_id=%s'
	list_type = params.get('list_type')
	if list_type == 'next':
		include_favorites = settings.nextep_include_favorites()
		data = ws.active_next_episodes_information()
		if include_favorites:
			from caches.favorites_cache import favorites_cache
			try:
				unwatched = [{'media_id': int(i['tmdb_id']), 'season': 1, 'episode': 1, 'unwatched': True, 'title': i['title']} \
							for i in favorites_cache.get_favorites('tvshow') if not int(i['tmdb_id']) in [x['media_id'] for x in data]]
				unwatched = sorted(unwatched, key=lambda i: title_key(i['title']))
				data += unwatched
			except: pass
	elif list_type == 'progress': data = ws.get_in_progress_episodes()
	else:
		data = sorted(params, key=lambda i: i['custom_order'])
		threads = TaskPool().tasks_enumerate(_process, data)
		for i in threads: i.join()
		return [(i['list_items'], i['sort_order']) for i in item_list]
	paginate_enabled = settings.paginate_single_episodes()
	page_no, paginate_start = int(params.get('new_page', '1')), int(params.get('paginate_start', '0'))
	hide_next_page = is_external and settings.widget_hide_next_page()
	new_params = {'mode': 'build_single_episode', 'list_type': list_type, 'paginate_start': paginate_start}
	if page_no == 1 and not is_external: kodi_utils.set_property('fen.exit_params', kodi_utils.folder_path())
	process_list, total_pages, paginate_start = _paginate_list(data, page_no, paginate_start)
	threads = TaskPool().tasks_enumerate(_process, process_list)
	for i in threads: i.join()
	item_list.sort(key=lambda i: i['sort_order'])
	kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
	if total_pages > page_no and not hide_next_page:
		new_page = str(page_no + 1)
		new_params['new_page'] = new_page
		kodi_utils.add_dir(handle, new_params, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, _get_category_name())
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external)

