# -*- coding: utf-8 -*-
import json
from caches.settings_cache import get_setting, set_setting, default_setting_values, settings_cache
from modules.fen_online_utils import single_sync
from modules import kodi_utils, settings, meta_lists
# logger = kodi_utils.logger

def trailer_service_choice(params):
	default_items = [{'name': 'Youtube', 'icon': kodi_utils.get_icon('youtube')}, {'name': 'IMDb', 'icon': kodi_utils.get_icon('imdb')}]
	current_order = settings.trailers_service_order()
	all_items = sorted(default_items, key=lambda k: current_order.index(k['name']))
	kwargs = {'heading': 'Manage Trailer Playback Services', 'all_items': all_items, 'mode': 'move'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	if all_items == choice: return
	new_order = sorted(choice, key=lambda k: k.get('position') or 0)
	new_order = [i['name'] for i in new_order]
	set_setting('trailers.service_order', ', '.join(new_order))

def default_trailer_choice(params):
	trailers, video_url, listitem = None, None, None
	media_type, tmdb_id, imdb_id = params['media_type'], params['tmdb_id'], params['imdb_id']
	return_values = params.get('return_values', False)
	use_default = params.get('use_default', True)
	trailer_order = settings.trailers_service_order()
	if not use_default: 
		default_items = [{'name': 'Youtube', 'icon': kodi_utils.get_icon('youtube')}, {'name': 'IMDb', 'icon': kodi_utils.get_icon('imdb')}]
		all_items = sorted(default_items, key=lambda k: trailer_order.index(k['name']))
		kwargs = {'heading': 'Choose Trailer Service', 'all_items': all_items, 'mode': 'select'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return
		trailer_order = [choice['name']]
	while trailer_order and not video_url:
		chosen_provider = trailer_order.pop(0)
		if chosen_provider == 'IMDb':
			from apis.imdb_api import imdb_extras, imdb_video_info
			if imdb_id:
				imdb_videos = imdb_extras(imdb_id)['videos']
				if imdb_videos:
					all_trailers = [i for i in imdb_videos if i['content'] == 'Trailer']
					official_trailers = [i for i in all_trailers if 'official trailer' in i['name'].lower()]
					other_trailers = [i for i in all_trailers if 'trailer' in i['name'].lower() and not i in official_trailers]
					trailers = official_trailers + other_trailers
					if trailers:
						try:
							trailer_info = trailers[0]
							trailer_id, trailer_thumb = trailer_info['id'], trailer_info['thumb']
							video_info = imdb_video_info(trailer_id)[0]
							video_name, video_url, video_thumb = video_info['name'], video_info['url'], trailer_thumb
							listitem = kodi_utils.make_listitem()
							listitem.setLabel(video_name)
							listitem.setArt({'poster': video_thumb, 'icon': video_thumb})
						except: video_url = None
		else:#Youtube
			if kodi_utils.addon_enabled('plugin.video.youtube'):
				from modules.utils import get_datetime
				from modules import metadata
				try:
					function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
					meta = function('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), get_datetime())
					video_url = meta.get('trailer')
				except: video_url = None
	if video_url:
		if return_values: return {'mode': 'play_video', 'url': video_url, 'listitem': listitem}
		kodi_utils.sleep(100)
		kodi_utils.close_all_dialog()
		kodi_utils.sleep(100)
		player = kodi_utils.kodi_player()
		player.play(video_url, listitem)
	return None

def media_info_choice(params):
	from windows.base_window import open_window
	from modules.utils import get_datetime
	from modules import metadata
	media_type = params['media_type']
	function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
	meta = function('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), get_datetime())
	if media_type == 'episode': meta.update({'season': params['season'], 'episode': params['episode']})
	open_window(('windows.media_info', 'MediaInfo'), 'media_info.xml', meta=meta, media_type=media_type, is_functional=params.get('is_functional', True))

def extras_images_choice(params):
	choices, service, use_default, poster = params['choices'], params['service'], params['use_default'], params['poster']
	if use_default:
		default = get_setting('fen.%s.image_provider_default' % service)
		if default != 'none': return default
	choice_names = {'tmdb':  'Media Images (TMDb)', 'imdb': 'Photo Images (IMDb)', 'easynews': 'More Images (Easynews)'}
	all_items = [{'line1': choice_names[i], 'icon': poster, 'value': i} for i in choices]
	kwargs = {'heading': 'Choose Image Type to Browse', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	return choice['value']

def browse_more_choice(params):
	media_type, tmdb_id, imdb_id, season = params.get('media_type'), params.get('tmdb_id'), params.get('imdb_id'), params.get('season')
	title, poster = params.get('title'), params.get('poster')
	movieset_id, movieset_name = params.get('movieset_id', None), params.get('movieset_name', None)
	mode = 'build_movie_list' if media_type == 'movie' else 'build_tvshow_list'
	action_insert = 'movies' if media_type == 'movie' else 'tv'
	window_command = 'ActivateWindow(Videos,%s,return)' if kodi_utils.external() else 'Container.Update(%s)'
	choices = [('Recommended', 'recommended')]
	if not settings.trakt_client() in (None, 'empty_setting', ''): choices.append(('Related', 'related'))
	choices.append(('More Like This', 'more_like_this'))
	if media_type == 'single_episode': choices.extend([('Browse Seasons', 'seasons'), ('Browse Episodes', 'episodes')])
	if movieset_id not in ('', 'None', None): choices.append(('Movie Set', 'movie_set'))
	all_items = [{'line1': i[0], 'icon': poster, 'value': i[1]} for i in choices]
	kwargs = {'heading': 'Choose Browsing Option', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	params = {
		'recommended': {'mode': mode, 'action': 'tmdb_%s_recommendations' % action_insert, 'key_id': tmdb_id, 'name': 'Recommended based on %s' % title},
		'related': {'mode': mode, 'action': 'trakt_%s_related' % action_insert, 'key_id': imdb_id,'name': 'Related to %s' % title},
		'more_like_this': {'mode': 'imdb.list.build_more_like_this', 'key_id': imdb_id, 'title': title},
		'movie_set': {'mode': mode, 'action': 'movie_set', 'key_id': movieset_id, 'name': movieset_name},
		'seasons': {'mode': 'build_season_list', 'tmdb_id': tmdb_id},
		'episodes': {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season}
				}[choice['value']]
	return kodi_utils.execute_builtin(window_command % kodi_utils.build_url(params))

def window_theme_choice(params):
	if params['type'] == 'theme':
		all_items = meta_lists.window_themes()
		kwargs = {'heading': 'Assign a Theme', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return
		window_theme, window_theme_contrast, window_theme_name = choice['value'][0][2:], choice['value'][1], choice['name']
		window_theme_opacity = get_setting('fen.window_theme_opacity', 'CC')
		set_setting('window_theme_name', window_theme_name)
	else:
		all_items = meta_lists.window_themes_opacity()
		kwargs = {'heading': 'Assign an Opacity Level', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return
		window_theme_opacity, window_theme_opacity_name = choice['value'], choice['name']
		window_theme = get_setting('fen.window_theme', 'FF1F2020')[2:]
		window_theme_contrast = get_setting('fen.window_theme_contrast', 'FF4a4347')
		set_setting('window_theme_opacity', window_theme_opacity)
		set_setting('window_theme_opacity_name', window_theme_opacity_name)
	set_setting('window_theme', window_theme_opacity + window_theme)
	set_setting('window_theme_contrast', window_theme_contrast)

def rpdb_poster_format_choice(params):
	all_items = [{'name': 'default', 'value': ''}, {'name': 'blocks', 'value': '&theme=blocks'}, {'name': 'rounded', 'value': '&theme=rounded-blocks'}]
	kwargs = {'heading': 'Choose Poster Format', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	set_setting('rpdb_format', choice['value'])
	set_setting('rpdb_format_name', choice['name'])

def language_invoker_choice(params):
	from xml.dom.minidom import parse as mdParse
	kodi_utils.close_all_dialog()
	addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.fen/addon.xml')
	root = mdParse(addon_xml)
	invoker_instance = root.getElementsByTagName('reuselanguageinvoker')[0].firstChild
	current_invoker_setting = invoker_instance.data
	new_value = {'true': 'false', 'false': 'true'}[current_invoker_setting]
	if not kodi_utils.confirm_dialog(text='Turn [B]Reuse Langauage Invoker[/B] %s?' % ('On' if new_value == 'true' else 'Off')): return
	invoker_instance.data = new_value
	new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
	with open(addon_xml, 'w') as f: f.write(new_xml)
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()

def personallists_manager_choice(params):
	from indexers.personal_lists import get_all_personal_lists, make_new_personal_list
	from modules.utils import get_current_timestamp
	icon = params.get('icon', None) or kodi_utils.get_icon('lists')
	all_lists = get_all_personal_lists()
	choices = []
	if not all_lists: action = 'add_new'
	else:
		all_items = [{'line1': 'Add To Personal List...', 'icon': icon, 'value': 'add'}, {'line1': 'Remove From Personal List...', 'icon': icon, 'value': 'remove'},
		{'line1': 'Add To [B]NEW[/B] Personal List...', 'icon': icon, 'value': 'add_new'}]
		kwargs = {'heading': 'Personal Lists Manager', 'all_items': all_items, 'mode': 'select'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return
		action = choice['value']
	if action == 'add_new':
		list_id, list_name = make_new_personal_list({'external_creation': 'true'})
		if not list_id: return kodi_utils.notification('Error Creating List', 3000)
		action = 'add'
	else:
		choices = [('%s [I](x%02d)[/I]' % (i['name'], i['total']), (i['list_id'], i['name'])) for i in all_lists]
		all_items = [{**d, 'line1': '%s [I](x%02d)[/I]' % (d['name'], d['total'])} for d in all_lists]
		kwargs = {'heading': 'Personal Lists Manager', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return
		list_id, list_name = choice['list_id'], choice['name']
	if action == 'add': new_contents = {'media_id': params['tmdb_id'], 'title': params['title'], 'type': params['media_type'],
										'release_date': params['premiered'], 'date_added': get_current_timestamp()}
	else: new_contents = params['tmdb_id']
	from caches.personal_lists_cache import PersonalListsCache
	personal_lists_cache = PersonalListsCache()
	result = personal_lists_cache.add_remove_list_item(list_id, action, new_contents)
	if result is None: text = personal_lists_cache.last_sync_message or 'Error'
	else: text = 'Success!!!'
	kodi_utils.notification(text, 3000)
	if action == 'remove' and any([kodi_utils.path_check(list_name) or kodi_utils.external()]): kodi_utils.kodi_refresh()

def favorites_manager_choice(params):
	from caches.favorites_cache import favorites_cache
	media_type, tmdb_id, title = params.get('media_type'), params.get('tmdb_id'), params.get('title')
	current_favorites = favorites_cache.get_favorites(media_type)
	people_favorite = media_type == 'people'
	current_favorite = any(i['tmdb_id'] == tmdb_id for i in current_favorites)
	if current_favorite:
		function, text = favorites_cache.delete_favorite, 'Remove From Favorites?'
		param_refresh = params.get('refresh', None)
		if param_refresh == None: refresh = any(i in kodi_utils.folder_path() for i in ('action=favorites_movies', 'action=favorites_tvshows'))
		else: refresh = param_refresh == 'true'
	else: function, text, refresh = favorites_cache.set_favorite, 'Add To Favorites?', False
	heading = title.split('|')[0] if people_favorite else title
	if not kodi_utils.confirm_dialog(heading=heading, text=text): return
	success = function(media_type, tmdb_id, title)
	if success:
		if refresh: kodi_utils.kodi_refresh()
		kodi_utils.notification('Success', 3500)
	else: kodi_utils.notification('Error', 3500)
	if people_favorite and success: return text

def playback_filters_choice(params):
	icon = kodi_utils.get_icon('tools')
	enabled_items = settings.filters_included()
	all_items = meta_lists.filters_items()
	all_items = [{**d, 'enabled': d['value'] in enabled_items, 'icon': icon} for d in all_items]
	kwargs = {'heading': 'Manage Filters', 'all_items': all_items, 'mode': 'enable', 'buttons': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [i['value'] for i in all_items if i['enabled']]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(s) for s in enabled_items]
	set_setting('filters.included', ','.join(enabled_items))
	set_setting('filters.included_name', ','.join(enabled_name))

def context_menu_manage_choice(params):
	from windows.base_window import open_window
	enabled_items = settings.context_menu_enabled()
	current_order = settings.context_menu_order()
	all_items = meta_lists.context_menu_items()
	missing_items = [i for i in all_items if not i['value'] in current_order]
	extra_items = [i for i in current_order if not i in [x['value'] for x in all_items]]
	if missing_items:
		for item in missing_items: current_order.insert(all_items.index(item), item['value'])
		set_setting('context_menu.order', ','.join([str(i) for i in current_order]))
	if extra_items:
		current_order = [i for i in current_order if not i in extra_items]
		set_setting('context_menu.order', ','.join([str(i) for i in current_order]))
	all_items = sorted(all_items, key=lambda k: current_order.index(k['value']))
	all_items = [{**d, 'enabled': d['value'] in enabled_items} for d in all_items]
	kwargs = {'heading': 'Manage Context Menu', 'all_items': all_items, 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [str(i['value']) for i in all_items if i['enabled']]
	current_order = [str(i['value']) for i in all_items]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(s) for s in enabled_items]
	set_setting('context_menu.enabled', ','.join(enabled_items))
	set_setting('context_menu.order', ','.join(current_order))
	set_setting('context_menu.enabled_name', ','.join(enabled_name))

def rescrape_manage_choice(params):
	enabled_items = settings.rescrape_enabled()
	current_order = settings.rescrape_order()
	all_items = meta_lists.rescrape_items()
	missing_items = [i for i in all_items if not i['value'] in current_order]
	extra_items = [i for i in current_order if not i in [x['value'] for x in all_items]]
	if missing_items:
		for item in missing_items: current_order.insert(all_items.index(item), item['value'])
		set_setting('results.rescrape_order', ','.join([str(i) for i in current_order]))
	if extra_items:
		current_order = [i for i in current_order if not i in extra_items]
		set_setting('results.rescrape_order', ','.join([str(i) for i in current_order]))
	all_items = sorted(all_items, key=lambda k: current_order.index(k['value']))
	all_items = [{**d, 'enabled': d['value'] in enabled_items} for d in all_items]
	kwargs = {'heading': 'Manage Rescrape Options', 'all_items': all_items, 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [str(i['value']) for i in all_items if i['enabled']]
	current_order = [str(i['value']) for i in all_items]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(s) for s in enabled_items]
	set_setting('results.rescrape_enabled', ','.join(enabled_items))
	set_setting('results.rescrape_order', ','.join(current_order))
	set_setting('results.rescrape_enabled_name', ','.join(enabled_name))

def extras_manage_choice(params):
	enabled_items = settings.extras_enabled()
	current_order = settings.extras_order()
	all_items = meta_lists.extras_items()
	missing_items = [i for i in all_items if not i['value'] in current_order]
	extra_items = [i for i in current_order if not i in [x['value'] for x in all_items]]
	if missing_items:
		for item in missing_items: current_order.insert(all_items.index(item), item['value'])
		set_setting('extras.order', ','.join([str(i) for i in current_order]))
	if extra_items:
		current_order = [i for i in current_order if not i in extra_items]
		set_setting('extras.order', ','.join([str(i) for i in current_order]))
	all_items = sorted(all_items, key=lambda k: current_order.index(k['value']))
	all_items = [{**d, 'enabled': d['value'] in enabled_items} for d in all_items]
	kwargs = {'heading': 'Manage Extras Lists', 'all_items': all_items, 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	from windows.base_window import ExtrasUtils
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [str(i['value']) for i in all_items if i['enabled']]
	current_order = [str(i['value']) for i in all_items]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(int(s)) for s in enabled_items]
	set_setting('extras.enabled', ','.join(enabled_items))
	set_setting('extras.order', ','.join(current_order))
	set_setting('extras.enabled_name', ','.join(enabled_name))
	ExtrasUtils().run()

def filter_manage_choice(params):
	enabled_items = settings.filters_enabled()
	current_order = settings.filters_order()
	all_items = meta_lists.filters_items()
	missing_items = [i for i in all_items if not i['value'] in current_order]
	extra_items = [i for i in current_order if not i in [x['value'] for x in all_items]]
	if missing_items:
		for item in missing_items: current_order.insert(all_items.index(item), item['value'])
		set_setting('filters.order', ','.join([str(i) for i in current_order]))
	if extra_items:
		current_order = [i for i in current_order if not i in extra_items]
		set_setting('filters.order', ','.join([str(i) for i in current_order]))
	all_items = sorted(all_items, key=lambda k: current_order.index(k['value']))
	all_items = [{**d, 'enabled': d['value'] in enabled_items} for d in all_items]
	kwargs = {'heading': 'Manage Sort To Top Filters', 'all_items': all_items, 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [i['value'] for i in all_items if i['enabled']]
	current_order = [i['value'] for i in all_items]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(s) for s in enabled_items]
	set_setting('filters.enabled', ','.join(enabled_items))
	set_setting('filters.order', ','.join(current_order))
	set_setting('filters.enabled_name', ','.join(enabled_name))

def extras_buttons_choice(params):
	media_type = params.get('media_type')
	base_setting_id = 'extras_buttons_%s.%%s' % media_type
	enabled_items = settings.extras_buttons_enabled(media_type)
	current_order = settings.extras_buttons_order(media_type)
	all_items = meta_lists.extras_buttons_items(media_type)
	missing_items = [i for i in all_items if not i['value'] in current_order]
	extra_items = [i for i in current_order if not i in [x['value'] for x in all_items]]
	if missing_items:
		for item in missing_items: current_order.insert(all_items.index(item), item['value'])
		set_setting('extras_buttons_%s.order' % media_type , ','.join([str(i) for i in current_order]))
	if extra_items:
		current_order = [i for i in current_order if not i in extra_items]
		set_setting('extras_buttons_%s.order' % media_type , ','.join([str(i) for i in current_order]))
	all_items = sorted(all_items, key=lambda k: current_order.index(k['value']))
	kwargs = {'heading': 'Manage Extras Buttons', 'all_items': all_items,  'mode': 'move', 'enumerate': 'true', 'active_enabled': 8,
			'listitem_preface': '[B]BUTTON[/B] | ', 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [i['value'] for i in all_items if i['enabled']]
	current_order = [i['value'] for i in all_items]
	enabled_name = [(lookup := {d['value']: d['name'] for d in all_items}).get(s) for s in enabled_items]
	set_setting(base_setting_id% 'enabled', ','.join(enabled_items))
	set_setting(base_setting_id% 'order', ','.join(current_order))
	set_setting(base_setting_id% 'enabled_name', ','.join(enabled_name))

def tmdb_api_check_choice(params):
	from apis.tmdb_api import movie_details
	data = movie_details('299534', settings.tmdb_api_key())
	if not data.get('success', True): text = 'There is an issue with your API Key.[CR][B]"Error: %s"[/B]' % data.get('status_message', '')
	else: text = 'Your TMDb API Key is enabled and working'
	return kodi_utils.ok_dialog(text=text)

def widget_refresh_timer_choice(params):
	all_items = [{'name': 'OFF', 'value': '0'}]
	all_items.extend([{'name': 'Every %s Minutes' % i, 'value': str(i)} for i in range(5,25,5)])
	all_items.extend([{'name': 'Every %s Minutes' % i, 'value': str(i)} for i in range(30,65,10)])
	all_items.extend([{'name': 'Every %s Hours' % (float(i)/60), 'value': str(i)} for i in range(90,720,30)])
	kwargs = {'heading': 'Choose Refresh Frequency', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	set_setting('widget_refresh_timer', choice['value'])
	set_setting('widget_refresh_timer_name', choice['name'])

def external_scraper_choice(params):
	from modules.utils import append_module_to_syspath, manual_function_import
	try:
		results = kodi_utils.jsonrpc_get_addons('xbmc.python.module')
		results = [i for i in results if kodi_utils.addon_enabled(i['addonid'])]
	except: return
	all_items = [{**d, 'line1': d['name'], 'icon': d['thumbnail'], 'module_id': d['addonid']} for d in results]
	kwargs = {'heading': 'Assign an External Scraper', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	module_id, module_name = choice['module_id'], choice['line1']
	success = False
	try:
		append_module_to_syspath('special://home/addons/%s/lib' % module_id)
		main_folder_name = module_id.split('.')[-1]
		sourceDict = manual_function_import(main_folder_name, 'sources')(specified_folders=['torrents'])
		success = True
	except: pass
	if success:
		try:
			set_setting('external_scraper.module', module_id)
			set_setting('external_scraper.name', module_name)
			set_setting('provider.external', 'true')
			kodi_utils.ok_dialog(text='Success.[CR][B]%s[/B] set as External Scraper' % module_name)
		except: kodi_utils.ok_dialog(text='Error')
	else:
		kodi_utils.ok_dialog(text='The [B]%s[/B] Module is not compatible.[CR]Please choose a different Module...' % module_name.upper())
		return external_scraper_choice(params)

def genres_choice(params):
	genres_list, genres, poster = params['genres_list'], params['genres'], params['poster']
	genre_list = [i for i in genres_list if i['name'] in genres]
	if not genre_list:
		kodi_utils.notification('No Results', 2500)
		return None
	all_items = [{'line1': i['name'], 'icon': poster, 'value': i} for i in genre_list]
	kwargs = {'heading': 'Choose Genre', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice: choice = choice['value']
	return choice

def keywords_choice(params):
	media_type, meta = params['media_type'], params['meta']
	keywords, tmdb_id, poster = meta.get('keywords', []), meta['tmdb_id'], meta['poster']
	if keywords: keywords = keywords.get('keywords') or keywords.get('results')
	else:
		kodi_utils.show_busy_dialog()
		from apis.tmdb_api import tmdb_movie_keywords, tmdb_tv_keywords
		if media_type == 'movie': function, key = tmdb_movie_keywords, 'keywords'
		else: function, key = tmdb_tv_keywords, 'results'
		try: keywords = function(tmdb_id)[key]
		except: keywords = []
		kodi_utils.hide_busy_dialog()
	if not keywords:
		kodi_utils.notification('No Results', 2500)
		return None
	all_items = [{'line1': i['name'], 'icon': poster, 'value': i} for i in keywords]
	kwargs = {'heading': 'Choose Keyword', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice: choice = choice['value']
	return choice

def random_choice(params):
	meta, poster, return_choice = params.get('meta'), params.get('poster'), params.get('return_choice', 'false')
	meta = params.get('meta', None)	
	all_items = [{'line1': 'Single Random Play', 'icon': poster, 'value': 'play_random'}, {'line1': 'Continual Random Play', 'icon': poster, 'value': 'play_random_continual'}]
	kwargs = {'heading': 'Choose Random Play', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice: choice = choice['value']
	if return_choice == 'true': return choice
	if choice == None: return
	from modules.episode_tools import EpisodeTools
	exec('EpisodeTools(meta).%s()' % choice)

def episode_groups_choice(params):
	from modules.metadata import episode_groups
	episode_group_types = {1: 'Original Air Date', 2: 'Absolute', 3: 'DVD', 4: 'Digital', 5: 'Story Arc', 6: 'Production', 7: 'TV'}
	meta = params.get('meta')
	poster = params.get('poster') or kodi_utils.get_icon('box_office')
	groups = episode_groups(meta['tmdb_id'])
	if not groups:
		kodi_utils.notification('No Episode Groups to choose from.')
		return None
	all_items = [{'line1': '%s | %s Order | %d Groups | %02d Episodes' % (item['name'], episode_group_types[item['type']], item['group_count'], item['episode_count']),
					'line2': item['description'], 'icon': poster, 'value': item['id']} for item in groups]
	kwargs = {'heading': 'Choose Episode Group', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice: choice = choice['value']
	return choice

def assign_episode_group_choice(params):
	from caches.episode_groups_cache import episode_groups_cache
	from modules import metadata
	tmdb_id = params['meta']['tmdb_id']
	current_group = episode_groups_cache.get(tmdb_id)
	if current_group:
		action = kodi_utils.confirm_dialog(text='Set new Group or Clear Current Group?', ok_label='Set New', cancel_label='Clear', default_control=10)
		if action == None: return
		if not action:
			episode_groups_cache.delete(tmdb_id)
			return kodi_utils.notification('Success', 2000)
	choice = episode_groups_choice(params)
	if choice == None: return
	group_details = metadata.group_details(choice)
	group_data = {'name': group_details['name'], 'id': group_details['id']}
	episode_groups_cache.set(tmdb_id, group_data)
	kodi_utils.notification('Success', 2000)

def playback_choice(params):
	from modules.utils import get_datetime
	from modules.source_utils import get_aliases_titles, make_alias_dict
	from modules import metadata
	media_type, season, episode, episode_id = params.get('media_type'), params.get('season', ''), params.get('episode', ''), params.get('episode_id', None)
	poster = params.get('poster', None)
	playcount = params.get('playcount', '0')
	play_mode = 'playback.media'
	meta = params.get('meta')
	try: meta = json.loads(meta)
	except: pass
	if not isinstance(meta, dict):
		function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', meta, settings.tmdb_api_key(), get_datetime())
	aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
	default_title, default_year = meta['title'], str(meta['year'])
	all_items = [{'line1': 'Select Source', 'value': 'scrape', 'icon': poster},
			{'line1': 'Rescrape & Select Source', 'value': 'clear_and_rescrape', 'icon': poster}]
	all_items.extend([{'line1': 'Clear Debrid Cache & Show Results', 'value': 'clear_debrid_cache_and_show', 'icon': poster},
				{'line1': 'Scrape with ALL External Scrapers', 'value': 'scrape_with_disabled', 'icon': poster},
				{'line1': 'Scrape With All Filters Ignored', 'value': 'scrape_with_filters_ignored', 'icon': poster}])
	if media_type == 'episode': all_items.append({'line1': 'Scrape with Custom Episode Groups Value', 'value': 'scrape_with_episode_group', 'icon': poster})
	if aliases: all_items.append({'line1': 'Scrape with an Alias', 'value': 'scrape_with_aliases', 'icon': poster})
	all_items.append({'line1': 'Scrape with Custom Values', 'value': 'scrape_with_custom_values', 'icon': poster})
	kwargs = {'heading': 'Playback Options', 'all_items': all_items, 'mode': 'select'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return kodi_utils.notification('Cancelled', 2500)
	choice = choice['value']
	if choice in ('clear_and_rescrape', 'scrape_with_custom_values'):
		kodi_utils.show_busy_dialog()
		from caches.base_cache import clear_cache
		from caches.external_cache import ExternalCache
		clear_cache('internal_scrapers', silent=True)
		ExternalCache().delete_cache_single(media_type, str(meta['tmdb_id']))
		kodi_utils.hide_busy_dialog()
	if choice == 'scrape':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'clear_and_rescrape':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'rescrape_external_cache_check_off':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'external_cache_check': 'false', 'prescrape': 'false'}
		else:
			play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode,
							'external_cache_check': 'false', 'prescrape': 'false'}
	elif choice == 'clear_debrid_cache_and_show':
		from caches.debrid_cache import debrid_cache
		debrid_cache.clear_cache()	
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'scrape_with_disabled':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'disabled_ext_ignored': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season,
							'episode': episode, 'disabled_ext_ignored': 'true', 'prescrape': 'false', 'autoplay': 'false'}
	elif choice == 'scrape_with_filters_ignored':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season,
							'episode': episode, 'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		kodi_utils.set_property('fs_filterless_search', 'true')
	elif choice == 'scrape_with_episode_group':
		choice = episode_groups_choice({'meta': meta, 'poster': poster})
		if choice == None: return playback_choice(params)
		episode_details = metadata.group_episode_data(metadata.group_details(choice), episode_id, season, episode)
		if not episode_details:
			kodi_utils.notification('No matching episode')
			return playback_choice(params)
		play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode, 'prescrape': 'false',
		'custom_season': episode_details['season'], 'custom_episode': episode_details['episode']}
	elif choice == 'scrape_with_aliases':
		if len(aliases) == 1: custom_title = aliases[0]
		else:
			all_items = [{'line1': i, 'icon': poster, 'value': i} for i in aliases]
			kwargs = {'heading': 'Choose Episode Group', 'all_items': all_items, 'mode': 'select'}
			choice = kodi_utils.list_dialog(**kwargs)
			if choice == None: return kodi_utils.notification('Cancelled', 2500)
			custom_title = choice['value']
		custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=custom_title)
		if not custom_title: return kodi_utils.notification('Cancelled', 2500)
		if media_type in ('movie', 'movies'): play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
						'custom_title': custom_title, 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode,
							'custom_title': custom_title, 'prescrape': 'false'}
	elif choice == 'scrape_with_custom_values':
		if media_type in ('movie', 'movies'): play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode, 'prescrape': 'false'}
		if aliases:
			if len(aliases) == 1: alias_title = aliases[0]
			all_items = [{'line1': i, 'icon': poster, 'value': i} for i in aliases]
			kwargs = {'heading': 'Choose Episode Group', 'all_items': all_items, 'mode': 'select'}
			choice = kodi_utils.list_dialog(**kwargs)
			if choice: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=choice['value'])
			else: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=default_title)
		else: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=default_title)
		if not custom_title: return kodi_utils.notification('Cancelled', 2500)
		def _process_params(default_value, custom_value, param_value):
			if custom_value and custom_value != default_value: play_params[param_value] = custom_value
		_process_params(default_title, custom_title, 'custom_title')
		custom_year = kodi_utils.kodi_dialog().input('Year', type=1, defaultt=default_year)
		_process_params(default_year, custom_year, 'custom_year')
		if media_type == 'episode':
			custom_season = kodi_utils.kodi_dialog().input('Season', type=1, defaultt=season)
			_process_params(season, custom_season, 'custom_season')
			custom_episode = kodi_utils.kodi_dialog().input('Episode', type=1, defaultt=episode)
			_process_params(episode, custom_episode, 'custom_episode')
			if any(i in play_params for i in ('custom_season', 'custom_episode')):
				if settings.autoplay_next_episode(): _process_params('', 'true', 'disable_autoplay_next_episode')
		all_choice = kodi_utils.confirm_dialog(heading=meta.get('rootname', ''), text='Scrape with ALL External Scrapers?', ok_label='Yes', cancel_label='No')
		if all_choice == None: return kodi_utils.notification('Cancelled', 2500)
		if all_choice: _process_params('', 'true', 'disabled_ext_ignored')
		disable_filters_choice = kodi_utils.confirm_dialog(heading=meta.get('rootname', ''), text='Disable All Filters for Search?', ok_label='Yes', cancel_label='No')
		if disable_filters_choice == None: return kodi_utils.notification('Cancelled', 2500)
		if disable_filters_choice:
			_process_params('', 'true', 'ignore_scrape_filters')
			kodi_utils.set_property('fs_filterless_search', 'true')
	else: episodes_data = metadata.episodes_meta(orig_season, meta)
	if media_type == 'episode': play_params['playcount'] = playcount
	from modules.sources import Sources
	Sources().playback_prep(play_params)

def set_quality_choice(params):
	quality_setting = params.get('setting_id')
	icon = params.get('icon') or kodi_utils.get_icon('tools')
	enabled_items = get_setting('fen.%s' % quality_setting).split(', ')
	all_items = [{'name': 'Include 4K', 'value': '4K'}, {'name': 'Include 1080p', 'value': '1080p'}, {'name': 'Include 720p', 'value': '720p'}, {'name': 'Include SD', 'value': 'SD'}]
	all_items = [{**d, 'enabled': d['value'] in enabled_items, 'icon': icon} for d in all_items]
	kwargs = {'heading': 'Choose Result Qualities', 'all_items': all_items, 'mode': 'enable', 'buttons': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [i['value'] for i in all_items if i['enabled']]
	if enabled_items == []:
		kodi_utils.ok_dialog(text='You must select at least 1 Quality')
		return set_quality_choice(params)
	set_setting(quality_setting, ', '.join(enabled_items))

def enable_scrapers_choice(params):
	icon = params.get('icon') or kodi_utils.get_icon('tools')
	scrapers = ['external', 'easynews', 'pm_cloud', 'oc_cloud', 'tb_cloud', 'folders']
	cloud_scrapers = {'pm_cloud': 'pm.enabled', 'oc_cloud': 'oc.enabled', 'tb_cloud': 'tb.enabled'}
	enabled_items = settings.active_internal_scrapers()
	all_items = [{'name': 'External Scrapers', 'value': 'external'}, {'name': 'Easynews', 'value': 'easynews'}, {'name': 'PM Cloud', 'value': 'pm_cloud'},
				{'name': 'OC Cloud', 'value': 'oc_cloud'}, {'name': 'TB Cloud', 'value': 'tb_cloud'}, {'name': 'FOLDERS 1-5', 'value': 'folders'}]
	all_items = [{**d, 'enabled': d['value'] in enabled_items, 'icon': icon} for d in all_items]
	kwargs = {'heading': 'Choose Scraper Status', 'all_items': all_items, 'mode': 'enable', 'buttons': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if all_items == choice: return
	all_items = sorted(choice, key=lambda k: k.get('position') or 0)
	enabled_items = [i['value'] for i in all_items if i['enabled']]
	if enabled_items == []:
		kodi_utils.ok_dialog(text='You must select at least 1 Scraper')
		return enable_scrapers_choice(params)
	for i in scrapers:
		set_setting('provider.%s' % i, ('true' if i in enabled_items else 'false'))
		if i in cloud_scrapers and i in enabled_items: set_setting(cloud_scrapers[i], 'true')

def sources_folders_choice(params):
	from windows.base_window import open_window
	return open_window(('windows.settings_manager', 'SettingsManagerFolders'), 'settings_manager_folders.xml')

def clear_favorites_choice(params):
	all_items = [{'line1': 'Clear Movies Favorites', 'value': 'movie'}, {'line1': 'Clear TV Show Favorites', 'value': 'tvshow'},
				{'line1': 'Clear People Favorites', 'value': 'people'}]
	kwargs = {'heading': 'Choose Favorites to Clear', 'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
	choice = kodi_utils.list_dialog(**kwargs)
	if choice == None: return
	choice = choice['value']
	if not kodi_utils.confirm_dialog(): return
	from caches.favorites_cache import favorites_cache
	favorites_cache.clear_favorites(choice)
	kodi_utils.notification('Success', 3000)

def scraper_color_choice(params):
	setting = params.get('setting_id')
	current_setting, original_highlight = get_setting('fen.%s' % setting), default_setting_values(setting)['setting_default']
	if current_setting != original_highlight:
		action = kodi_utils.confirm_dialog(text='Set new Highlight or Restore Default Highlight?', ok_label='Set New', cancel_label='Restore Default', default_control=10)
		if action == None: return
		if not action: return set_setting(setting, original_highlight)
	chosen_color = color_choice({'current_setting': current_setting})
	if chosen_color: set_setting(setting, chosen_color)

def color_choice(params):
	from windows.base_window import open_window
	return open_window(('windows.color', 'SelectColor'), 'color.xml', current_setting=params.get('current_setting', None))

@single_sync('settings_db', 'settings')
def options_menu_choice(params, meta=None):
	from caches.base_cache import refresh_cached_data
	from caches.episode_groups_cache import episode_groups_cache
	from modules.source_utils import clear_scrapers_cache
	from modules.utils import get_datetime, get_current_timestamp
	from modules.downloader import manager
	from modules import metadata
	params_get = params.get
	start_settings = settings_cache.get_all(return_dict=False)
	tmdb_id, content, poster = params_get('tmdb_id'), params_get('content'), params_get('poster')
	from_extras, season, episode = params_get('from_extras', 'false') == 'true', params_get('season', ''), params_get('episode', '')
	single_ep_list = ('progress', 'next')
	content = content or kodi_utils.container_content()[:-1]
	if not meta:
		function = metadata.movie_meta if content == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	rootname, title, premiered = meta.get('rootname'), meta.get('title'), meta.get('premiered')
	window_function = kodi_utils.activate_window if kodi_utils.external() else kodi_utils.container_update
	while True:
		is_autoplay = settings.auto_play(content)
		quality_setting = '%s_quality_%s' % ('autoplay' if is_autoplay else 'results', content)
		menus = [
		('Playback Options', 'Scrapers Options', content in ('movie', 'episode'), 'playback_choice'),
		('Personal Lists Manager', '', from_extras, 'personallists_manager_choice'),
		('TMDb Lists Manager', '', from_extras, 'tmdblists_manager_choice'),
		('Favorites Manager', '', from_extras, 'favorites_manager_choice'),
		('Play Random', 'Based On %s' % rootname, content == 'tvshow', 'random'),
		('Assign an Episode Group to %s' % rootname, 'Currently %s' % episode_groups_cache.get(tmdb_id).get('name', 'None'), content in ('tvshow', 'season'), 'episode_group'),
		('Auto Play (%s)' % content, 'Currently: [B]%s[/B]' % ('On' if is_autoplay else 'Off'), content in ('movie', 'episode') or content in single_ep_list, 'toggle_autoplay'),
		('Autoplay Next Episode', 'Currently: [B]%s[/B]' % ('On' if settings.autoplay_next_episode() else 'Off'),
			(content == 'episode' or content in single_ep_list) and is_autoplay, 'toggle_autoplay_next'),
		('Quality Limit (%s)' % content, 'Currently: [B]%s[/B]' % ', '.join(settings.quality_filter(quality_setting)),
			content in ('movie', 'episode') or content in single_ep_list, 'set_quality'),
		('Enable Scrapers', 'Currently: [B]%s[/B]' % ', '.join([i.replace('_', '') for i in settings.active_internal_scrapers()]) or 'N/A',
			content in ('movie', 'episode') or content in single_ep_list, 'enable_scrapers'),
		('Assign an Episode Group to %s' % rootname, 'Currently %s' % episode_groups_cache.get(tmdb_id).get('name', 'None'),
			content == 'episode' or content in single_ep_list, 'episode_group'),
		('Re-Cache %s Info' % ('Movies' if content == 'movie' else 'TV Shows'), 'Clear %s Cache' % rootname, not from_extras and content in ('movie', 'tvshow'), 'clear_media_cache'),
		('Clear Scrapers Cache', '', not from_extras and (content in ('movie', 'episode') or content in single_ep_list), 'clear_scrapers_cache'),
		('TV Shows Progress Manager', '', not from_extras and content in ('tvshow', 'season', 'episode'), 'nextep_manager'),
		('Open Download Manager', '', not from_extras, 'open_download_manager'),
		('Open Tools', '', not from_extras, 'open_tools'),
		('Open External Scraper Settings', '', not from_extras and (content in ('movie', 'episode') or content in single_ep_list), 'open_external_scraper_settings'),
		('Open Settings', '', not from_extras, 'open_settings')]
		listing = [i for i in menus if i[2]]
		all_items = [{'name': i[0], 'name2': i[1] or i[0], 'value': i[3], 'icon': poster} for i in listing]
		kwargs = {'heading': rootname or 'Options...', 'all_items': all_items, 'mode': 'select'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice is None: return True if start_settings != settings_cache.get_all(return_dict=False) else None
		choice = choice['value']
		if choice == 'toggle_autoplay': set_setting('auto_play_%s' % content, 'false' if is_autoplay else 'true'); continue
		elif choice == 'toggle_autoplay_next': set_setting('autoplay_next_episode', 'false' if settings.autoplay_next_episode() else 'true'); continue
		elif choice == 'set_quality': set_quality_choice({'setting_id': quality_setting, 'icon': poster}); continue
		elif choice == 'enable_scrapers': enable_scrapers_choice({'icon': poster}); continue
		elif choice == 'episode_group': assign_episode_group_choice({'meta': meta, 'poster': poster}); continue
		actions = {
		'clear_media_cache': lambda: refresh_cached_data(meta),
		'clear_scrapers_cache': clear_scrapers_cache,
		'open_download_manager': manager,
		'open_tools': lambda: window_function({'mode': 'navigator.tools'}),
		'open_settings': kodi_utils.open_settings,
		'open_external_scraper_settings': kodi_utils.external_scraper_settings,
		'playback_choice': lambda: playback_choice({'media_type': content, 'poster': poster, 'meta': meta, 'season': season, 'episode': episode}),
		'nextep_manager': lambda: window_function({'mode': 'build_next_episode_manager'}),
		'random': lambda: random_choice({'meta': meta, 'poster': poster}),
		'personallists_manager_choice': lambda: personallists_manager_choice({'media_type': content, 'tmdb_id': tmdb_id, 'title': title, 'premiered': meta.get('premiered'),
																			'current_time': get_current_timestamp(), 'icon': poster}),
		'favorites_manager_choice': lambda: favorites_manager_choice({'media_type': 'tvshow' if content not in ('movie', 'tvshow') else content, 'tmdb_id': tmdb_id, 'title': title}),
		'tmdblists_manager_choice': lambda: tmdblists_manager_choice({'media_type': 'tv' if content not in ('movie', 'movies') else content, 'tmdb_id': tmdb_id, 'icon': poster})}
		return actions[choice]()

def extras_menu_choice(params):
	from windows.base_window import open_window
	from modules.utils import get_datetime
	from modules import metadata
	stacked = params.get('stacked', 'false') == 'true'
	if not stacked: kodi_utils.show_busy_dialog()
	media_type = params['media_type']
	function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
	meta = function('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), get_datetime())
	if not stacked: kodi_utils.hide_busy_dialog()
	open_window(('windows.extras', 'Extras'), 'extras.xml', meta=meta, options_media_type=media_type, starting_position=params.get('starting_position', None))

def person_menu_choice(params):
	from urllib.parse import unquote
	from windows.base_window import open_window
	if 'key_id' in params: params['key_id'] = unquote(params.get('key_id'))
	elif 'query' in params: params['key_id'] = unquote(params.get('query'))
	else: params['key_id'] = None
	open_window(('windows.people', 'People'), 'people.xml', **params)

def open_movieset_choice(params):
	kodi_utils.hide_busy_dialog()
	window_function = kodi_utils.activate_window if kodi_utils.external() else kodi_utils.container_update
	return window_function({'mode': 'build_movie_list', 'action': 'movies_sets', 'key_id': params['key_id'], 'name': params['name']})

def media_extra_info_choice(params):
	from modules.utils import adjust_premiered_date
	from modules.source_utils import get_aliases_titles, make_alias_dict
	media_type, tmdb_id = params.get('media_type'), params.get('tmdb_id')
	if tmdb_id:
		from modules import metadata
		from modules.utils import get_datetime
		function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	else: meta = params.get('meta')
	extra_info, listings = meta.get('extra_info', None), []
	append = listings.append
	try:
		if media_type == 'movie':
			if meta['tagline']: append('[B]Tagline:[/B] %s' % meta['tagline'])
			aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
			if aliases: append('[B]Aliases:[/B] %s' % ', '.join(aliases))
			append('[B]Status:[/B] %s' % extra_info['status'])
			append('[B]Premiered:[/B] %s' % meta['premiered'])
			append('[B]Classification:[/B] %s' % meta['mpaa'])
			append('[B]Rating:[/B] %s (%s Votes)' % (str(round(meta['rating'], 1)), meta['votes']))
			append('[B]Runtime:[/B] %s mins' % int(float(meta['duration'])/60))
			append('[B]Genre/s:[/B] %s' % ', '.join(meta['genre']))
			append('[B]Budget:[/B] %s' % extra_info['budget'])
			append('[B]Revenue:[/B] %s' % extra_info['revenue'])
			append('[B]Director:[/B] %s' % ', '.join(meta['director']))
			append('[B]Writer/s:[/B] %s' % ', '.join(meta['writer']) or 'N/A')
			append('[B]Studio:[/B] %s' % ', '.join(meta['studio']) or 'N/A')
			if extra_info['collection_name']: append('[B]Collection:[/B] %s' % extra_info['collection_name'])
			append('[B]Homepage:[/B] %s' % extra_info['homepage'])
		else:
			append('[B]Type:[/B] %s' % extra_info['type'])
			if meta['tagline']: append('[B]Tagline:[/B] %s' % meta['tagline'])
			aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
			if aliases: append('[B]Aliases:[/B] %s' % ', '.join(aliases))
			append('[B]Status:[/B] %s' % extra_info['status'])
			append('[B]Premiered:[/B] %s' % meta['premiered'])
			append('[B]Classification:[/B] %s' % meta['mpaa'])
			append('[B]Rating:[/B] %s (%s Votes)' % (str(round(meta['rating'], 1)), meta['votes']))
			append('[B]Runtime:[/B] %d mins' % int(float(meta['duration'])/60))
			append('[B]Genre/s:[/B] %s' % ', '.join(meta['genre']))
			append('[B]Networks:[/B] %s' % ', '.join(meta['studio']))
			append('[B]Created By:[/B] %s' % extra_info['created_by'])
			try:
				last_ep = extra_info['last_episode_to_air']
				append('[B]Last Aired:[/B] %s - [B]S%.2dE%.2d[/B] - %s' \
					% (adjust_premiered_date(last_ep['air_date'], settings.date_offset())[0].strftime('%d %B %Y'),
						last_ep['season_number'], last_ep['episode_number'], last_ep['name']))
			except: pass
			try:
				next_ep = extra_info['next_episode_to_air']
				append('[B]Next Aired:[/B] %s - [B]S%.2dE%.2d[/B] - %s' \
					% (adjust_premiered_date(next_ep['air_date'], settings.date_offset())[0].strftime('%d %B %Y'),
						next_ep['season_number'], next_ep['episode_number'], next_ep['name']))
			except: pass
			append('[B]Seasons:[/B] %s' % meta['total_seasons'])
			append('[B]Episodes:[/B] %s' % meta['total_aired_eps'])
			append('[B]Homepage:[/B] %s' % extra_info['homepage'])
	except: return kodi_utils.notification('Error', 2000)
	text = '[CR][CR]'.join(listings)
	if tmdb_id:
		from windows.base_window import open_window
		return open_window(('windows.extras', 'ShowTextMedia'), 'textviewer_media.xml', text=text, poster=meta['poster'] or kodi_utils.get_icon('box_office'))
	else: return text

def discover_choice(params):
	from windows.base_window import open_window
	open_window(('windows.discover', 'Discover'), 'discover.xml', media_type=params['media_type'])
