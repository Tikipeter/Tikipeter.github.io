# -*- coding: utf-8 -*-
import functools
from apis import watched_sync_api
from modules.settings import watched_no_sync
# from modules.kodi_utils import logger

def sync_single_item(method_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			setting_no_sync = watched_no_sync()
			no_sync = kwargs.pop('no_sync', False)
			sync_data = func(*args, **kwargs)
			if any([no_sync, setting_no_sync]): return sync_data
			if sync_data:
				_method = getattr(watched_sync_api, method_name)
				if isinstance(sync_data, dict): _method(**sync_data)
				elif isinstance(sync_data, (tuple, list)): _method(*sync_data)
			return sync_data
		return wrapper
	return decorator

def sync_batch_items(table_name):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			setting_no_sync = watched_no_sync()
			no_sync = kwargs.pop('no_sync', False)
			action = kwargs.get('action') or (args[1] if len(args) > 1 else None)
			action = 'remove' if action in ('mark_as_unwatched', 'remove') else action
			sync_data = func(*args, **kwargs)
			if any([no_sync, setting_no_sync]): return sync_data
			if sync_data: 
				watched_sync_api.sync_many(table_name, action, sync_data)
			return sync_data
		return wrapper
	return decorator
